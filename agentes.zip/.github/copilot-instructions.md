---
applyTo: "**"
---

# Copilot Instructions

This document provides comprehensive guidelines for AI agents contributing effectively to this codebase.

---

## Project Overview

...

### Directory Structure

| Path | Purpose |
|------|---------|


### Configuration Files

| File | Purpose |
|------|---------|


> Note: Ignore files or directories not explicitly mentioned above.

---

## Development Tools

### Makefile Commands

The project includes a `Makefile` to automate common tasks:

| Command | Description |
|--------|-------------|


---

## Language Requirements

- All responses, explanations and suggestions MUST be written in Portuguese (PT-BR).
- Translate any referenced English documentation or error messages.
- Well-known technical terms (repository, dependency injection, async/await, middleware) may remain in English when appropriate.
- Any response originally generated in English must be rewritten into Portuguese before submission.

---

## File Operations Guidelines

### Critical Rules

* **NEVER use heredoc (`cat << EOF`, `cat > file.txt << EOF`, etc.) to create or modify files.** This method is unreliable and causes errors. Always use the appropriate VSCode tools.

* **For editing existing files**: Use ONLY `replace_string_in_file` or `multi_replace_string_in_file` tools.

* **For creating new files**: Use ONLY `create_file` tool.

* **For terminal operations**: Use `run_in_terminal` only for commands like `git`, `make`, `pytest`, `rg`, etc. NEVER for file manipulation with `cat`, `echo >`, or similar.

### Search and Reference Guidelines

* When you need to look up references, definitions, or code snippets, don't try to read the file tree. Run the `rg` command with the context argument to see the surrounding lines. Ex: `rg "test_change_password_code_not_found_enus" -n -C 3` to see 3 lines of context around the match. If `rg` is not installed, ask user to install it instead.

* Don't dump huge files into the chat. List the structure first with `tree -L 2` and read only what's necessary. If `tree` is not installed, ask user to install it instead.

---

## Code Review for Pull Requests

When reviewing pull requests, evaluate the following aspects:

### Review Checklist

| Aspect | What to check |
|--------|----------------|
| **Functionality** | Code meets the specified requirements and behaves as expected |
| **Code Quality** | Readable, maintainable, follows coding standards |
| **Tests** | Appropriate tests included with good coverage |
| **Documentation** | Necessary documentation updated or added |
| **Performance** | No obvious bottlenecks or inefficiencies |
| **Security** | No vulnerabilities or anti-patterns |
| **Best Practices** | Follows FastAPI and Python conventions |
| **i18n** | User-facing strings are properly internationalized |

### Standard Comment Format

Use this structure for review comments:

```
**Problem:** [Clear description of the issue]

**Impact:** [Why this matters]

**Suggestion:** [Actionable recommendation with code example if applicable]
```

**Example:**

> **Problem:** Business logic mixed directly with Firestore access code.
>
> **Impact:** Reduces testability and reusability.
>
> **Suggestion:** Extract this logic into a service layer.

### What to Avoid in Reviews

- Vague comments like "this could be improved"
- Repeating rules already covered by linters or formatters
- Requesting optimizations without measurable impact
- Nitpicking style issues that don't affect functionality
- Suggesting changes without explaining why

### Review Philosophy

- PRs should be easy to understand
- Code should be secure by default
- Favor long-term maintainability over short-term shortcuts
- Solutions should align with FastAPI and Firestore best practices
- Comments should add real value to the review
- Provide code examples or references to support suggestions
- Prioritize clarity and simplicity in communication
