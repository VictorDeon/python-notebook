---
name: requirement-analysis
description: This skill provides a structured methodology for analyzing feature and adjustment requirements, identifying ambiguities, extracting implicit technical requirements, and transforming them into implementable specifications. It should ALWAYS be used before planning development to ensure clarity, completeness, and feasibility of requirements. This skill is CRITICAL to the project as it prevents rework, ensures quality, and aligns development with user needs and project standards.
---

# Requirement Analysis Skill

## 🎯 Purpose

This skill provides a structured methodology for analyzing feature and adjustment requirements, identifying ambiguities, extracting implicit technical requirements, and transforming them into implementable specifications.

---

## 📋 Analysis Methodology

### Phase 1: Initial Understanding

#### 1.1 Identify Requirement Type

| Type | Description | Examples |
|------|-----------|----------|
| **New Feature** | Completely new functionality | "Add push notification system" |
| **New Module** | Entire module with multiple operations | "Create gamification module" |
| **Adjustment/Enhancement** | Modification of existing functionality | "Add date filter to campaigns" |
| **Bug Fix** | Correction of incorrect behavior | "CPF being accepted with invalid format" |
| **Refactoring** | Code improvement without functional changes | "Split controller into smaller functions" |
| **Integration** | Connect with external service | "Integrate with SMS API" |

#### 1.2 Identify Scope

- [ ] **Simple** (1 file, < 100 lines, < 2h)
- [ ] **Medium** (2-5 files, 100-500 lines, 2-8h)
- [ ] **Complex** (> 5 files, > 500 lines, > 8h)
- [ ] **Complete Module** (entire structure, > 1000 lines, > 16h)

---

### Phase 2: Requirement Extraction

#### 2.1 Explicit Functional Requirements

Extract EXACTLY what the user requested:

```markdown
**What should be implemented:**

- [ ] Functional requirement 1
- [ ] Functional requirement 2
- [ ] Functional requirement 3
```

#### 2.2 Mandatory Implicit Requirements

Identify requirements NOT mentioned but MANDATORY in the project:

| Category | Implicit Requirements |
|-----------|----------------------|
| **Authentication** | - Does endpoint require authentication?<br>- Permission verification needed?<br>- Rate limiting applicable? |
| **Validation** | - Which fields are required?<br>- What format/size validations?<br>- Business validations needed? |
| **Persistence** | - Which Firestore collection?<br>- Document structure?<br>- Indexes needed? |
| **Security** | - Sensitive data involved?<br>- Input sanitization necessary?<br>- Appropriate CORS/headers? |
| **I18n** | - Messages for end users?<br>- pt_BR and en_US support mandatory |
| **Logging** | - Structured logs at key points<br>- Sensitive data must not be logged |
| **Tests** | - 100% coverage mandatory<br>- Mocks of external services<br>- Error case tests |
| **Documentation** | - Complete OpenAPI (summary, responses)<br>- Docstrings in functions/classes |

#### 2.3 Clarifying Questions

If the requirement is ambiguous or incomplete, ask questions BEFORE planning:

**Question Template:**

```markdown
## 🤔 Questions for Clarification

I identified some ambiguities in the requirement. I need clarification:

### 1. [Category]

**Question:** [specific question]

**Context:** [why you need to know]

**Options:**

- A) [option 1]
- B) [option 2]

**Suggestion:** [your recommendation based on best practices]

### 2. [Category]
...
```

**Common Ambiguity Categories:**

- **Scope:** What is included/excluded?
- **Business Rules:** How to handle case X?
- **Permissions:** Who can access/modify?
- **Validations:** Which constraints to apply?
- **Error Behavior:** What to do when X fails?
- **Performance:** Are there latency/volume requirements?

---

### Phase 3: Impact Analysis

#### 3.1 Identify Affected Files

```markdown
## 📂 Impact Analysis

### Files to Create
- `path/to/new_file.py` - [purpose]

### Files to Modify
- `path/to/existing.py` - [what changes]
- `api/main.py` - [register new router]

### Test Files
- `path/to/test_new.py` - [new test]
- `path/to/test_existing.py` - [add cases]
```

#### 3.2 Identify Dependencies

```markdown
## 🔗 Dependencies

### Internal Modules
- `api/module_x` - [how it will be used]
- `engines/service_y` - [integration needed]

### External Services
- Firestore - [operations: read/write/query]
- Stripe - [if payment involved]
- GCS - [if upload involved]
- Cloud Tasks - [if async jobs involved]

### Python Libraries
- `pydantic` - [for validation]
- `python-multipart` - [for file upload]
```

#### 3.3 Identify Risks

```markdown
## ⚠️ Identified Risks

| Risk | Probability | Impact | Mitigation |
|-------|---------------|---------|-----------|
| [Description] | High/Medium/Low | High/Medium/Low | [How to mitigate] |
```

---

### Phase 4: Technical Specification

#### 4.1 Define Data Flow

```markdown
## 🔄 Data Flow

1. **Input:** Client sends POST /api/v1/endpoint
   - Headers: Authorization, Accept-Language
   - Body: { field1, field2 }

2. **Validation:** Pydantic validates RequestDTO
   - field1: string, min 1, max 100
   - field2: enum [A, B, C]

3. **Authentication:** get_current_user verifies token
   - Extracts user_id
   - Validates permissions

4. **Controller:** Executes business logic
   - Validates rule X
   - Queries Firestore to validate Y
   - Prepares data for persistence

5. **Persistence:** Saves to Firestore
   - Collection: collection_name
   - Document: { fields }

6. **Response:** Returns ResponseDTO
   - Status 201 Created
   - Body: { id, message }
```

#### 4.2 Define Data Structure

```markdown
## 📊 Data Structure

### Request DTO
```python
class OperationRequest(BaseModel):
    field1: str = Field(..., description="...", min_length=1)
    field2: Optional[int] = Field(None, description="...")
```

### Response DTO
```python
class OperationResponse(BaseModel):
    id: str = Field(..., description="...")
    status: Status = Field(..., description="...")
```

### Firestore Document
```json
{
  "field1": "value",
  "field2": 123,
  "user_id": "user123",
  "created_at": "2024-01-01T00:00:00Z"
}
```

#### 4.3 Define Test Cases

```markdown
## 🧪 Required Test Cases

### Success Cases
- [ ] Operation with valid data returns 201
- [ ] Data is persisted correctly in Firestore
- [ ] Success message is translated (pt_BR and en_US)

### Error Cases
- [ ] Request without authentication returns 401
- [ ] Invalid data returns 422 with details
- [ ] Insufficient permission returns 403
- [ ] Firestore failure returns 500

### Edge Cases
- [ ] Missing optional field is handled correctly
- [ ] Boundary values (min/max) are accepted
- [ ] Out-of-bounds values are rejected
```

---

## 🛠️ Complete Analysis Template

Use [this template](./template.md) when analyzing a requirement:

---

## 📚 Practical Examples

### Example 1: Ambiguous Requirement

**User Input:**
> "Add date filter to campaigns"

**Analysis:**

```markdown
## 🤔 Questions for Clarification

I identified ambiguities that need to be clarified:

### 1. Filter Type
**Question:** Should the filter be by specific date or date range?
**Context:** This affects the DTO structure and Firestore query
**Options:**
- A) Specific date: `date=2024-01-01`
- B) Range: `start_date=2024-01-01&end_date=2024-01-31`
**Suggestion:** Range is more flexible and common for date filters

### 2. Date Field
**Question:** Filter by `created_at`, `updated_at` or allow choosing?
**Context:** Determines controller logic and necessary indexes
**Options:**
- A) Only created_at
- B) Only updated_at
- C) Parameterizable: `date_field=created_at&start_date=...`
**Suggestion:** Start with created_at (most common) and expand if needed

### 3. Behavior with Existing Filters
**Question:** Does date filter combine with existing filters (AND) or replace?
**Context:** Affects Firestore query and user experience
**Suggestion:** Combine (AND) is the expected behavior for filters

### 4. Pagination
**Question:** Does existing pagination continue working with the filter?
**Context:** Ensure performance is not affected
**Suggestion:** Yes, maintain limit/offset or cursor-based pagination
```

### Example 2: Clear Requirement

**User Input:**
> "Create endpoint for user to update their avatar"

**Analysis:**

```markdown
# 📋 Requirement Analysis: User Avatar Upload

## 1️⃣ Initial Understanding

**Type:** New Feature
**Scope:** Medium
**Estimate:** 4-6 hours

## 2️⃣ Requirements

### Explicit Functional Requirements
- [ ] Endpoint for avatar image upload
- [ ] Update user profile with avatar URL
- [ ] Return public image URL

### Implicit Non-Functional Requirements
- [ ] Authentication: Yes - only authenticated user can update own avatar
- [ ] Permissions: User can only update own avatar
- [ ] Validations:
  - Format: JPEG, PNG
  - Max size: 5MB
  - Recommended dimensions: 200x200 to 1000x1000
- [ ] Storage: Configured GCS bucket
- [ ] I18n: Error/success messages in pt_BR and en_US
- [ ] Logging: Upload started, success, failure
- [ ] Tests: 100% coverage including GCS mock

### ❓ Identified Ambiguities
_None - requirement is clear_

## 3️⃣ Impact Analysis

### Affected Files

**Create:**
- `api/authentication/dtos/update_avatar.py` - Request/Response DTOs
- `api/authentication/controllers/update_avatar.py` - Upload logic
- `api/authentication/routes/update_avatar.py` - FastAPI endpoint
- `api/authentication/tests/test_update_avatar.py` - Tests

**Modify:**
- `api/models.py` - Add `avatar_url` field to User
- `api/main.py` - Register new router

### Dependencies

**Internal:**
- `api/models.py` - User
- `engines/storage.py` - GCS upload
- `engines/security.py` - get_current_user

**External:**
- Google Cloud Storage - file upload
- Firestore - update user document

**Libraries:**
- `python-multipart` - to receive file upload
- `Pillow` - to validate image dimensions

### Risks

| Risk | Prob | Impact | Mitigation |
|-------|------|---------|-----------|
| Malicious file upload | Medium | High | Validate MIME type, sanitize name |
| File too large | High | Medium | 5MB limit, validate before upload |
| GCS failure | Low | High | Error handling, retry logic |

## 4️⃣ Technical Specification

### Data Flow

1. **Input:** POST /api/v1/users/avatar
   - Headers: Authorization, Content-Type: multipart/form-data
   - Body: file (image)

2. **Validation:** Pydantic + custom validators
   - Type: image/jpeg or image/png
   - Size: < 5MB
   - Dimensions: 200x200 to 1000x1000

3. **Authentication:** get_current_user
   - Extracts user_id from token

4. **Controller:** UpdateAvatarController
   - Generates unique filename
   - Upload to GCS: `avatars/{user_id}/{filename}`
   - Updates Firestore users/{user_id}: `avatar_url`

5. **Response:** UpdateAvatarResponse
   - Status 200 OK
   - Body: { avatar_url, message }

### Data Structure

```python
# DTO
class UpdateAvatarRequest(BaseModel):
    # FastAPI automatically injects via UploadFile
    pass

class UpdateAvatarResponse(BaseModel):
    avatar_url: str = Field(..., description="Public avatar URL")
    message: str = Field(..., description="Confirmation message")

# Firestore Update
{
  "avatar_url": "https://storage.googleapis.com/bucket/avatars/user123/avatar.jpg",
  "updated_at": "2024-01-15T10:30:00Z"
}
```

### Test Cases

**Success:**
- [ ] Valid JPEG upload returns 200 with URL
- [ ] Valid PNG upload returns 200 with URL
- [ ] Previous avatar is replaced correctly
- [ ] Firestore is updated with new URL
- [ ] Message is translated in pt_BR and en_US

**Error:**
- [ ] No authentication returns 401
- [ ] Non-image file returns 422
- [ ] File > 5MB returns 413
- [ ] Invalid dimensions return 422
- [ ] GCS failure returns 500

**Edge:**
- [ ] First upload (no previous avatar) works
---

## ✅ Analysis Checklist

When analyzing a requirement, verify:

### Understanding
- [ ] Requirement type identified
- [ ] Scope estimated
- [ ] Time estimated (optional)

### Completeness
- [ ] Functional requirements listed
- [ ] Non-functional requirements identified
- [ ] Ambiguities registered or clarified

### Feasibility
- [ ] Dependencies identified
- [ ] Risks mapped with mitigations
- [ ] Impact on existing files analyzed

### Specification
- [ ] Data flow defined
- [ ] Data structure specified
- [ ] Test cases planned

### Security
- [ ] Required authentication identified
- [ ] Input validations defined
- [ ] Sensitive data identified

### Quality
- [ ] Relevant skills identified
- [ ] Design patterns to follow defined
- [ ] Clear acceptance criteria

---

## 🎯 When to Use This Skill

- **ALWAYS** before creating a development plan
- When user's requirement is ambiguous or incomplete
- When estimating complexity and implementation time
- When identifying risks and dependencies
- When preparing detailed technical specifications

**Importance:** 🔴 CRITICAL - Proper analysis prevents rework and ensures quality.

---

## 📚 Related Resources

- [Module Structure](../module-structure/SKILL.md) - For new modules
- [FastAPI Best Practices](../fastapi-best-practices/SKILL.md) - Endpoint patterns
- [Security Review](../security-review/SKILL.md) - Security considerations
- [Test Planning](../test-planning/SKILL.md) - Test planning

