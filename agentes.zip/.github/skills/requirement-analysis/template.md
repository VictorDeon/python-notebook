# 📋 Análise de Requisito: [Nome da Feature/Ajuste]

## 1️⃣ Compreensão Inicial

**Tipo:** [Nova Feature | Novo Módulo | Ajuste | Bug Fix | Refatoração | Integração]
**Escopo:** [Simples | Médio | Complexo | Módulo Completo]
**Estimativa:** [tempo estimado]

## 2️⃣ Requisitos

### Requisitos Funcionais Explícitos
- [ ] Requisito 1
- [ ] Requisito 2

### Requisitos Não-Funcionais Implícitos
- [ ] Autenticação: [sim/não] - [detalhes]
- [ ] Permissões: [quais roles podem acessar]
- [ ] Validações: [quais campos, constraints]
- [ ] I18n: [mensagens em pt_BR e en_US]
- [ ] Logging: [pontos de log estruturado]
- [ ] Testes: [cobertura 100%]

### ❓ Ambiguidades Identificadas
1. **[Categoria]:** [pergunta] - Sugestão: [recomendação]
2. **[Categoria]:** [pergunta] - Sugestão: [recomendação]

## 3️⃣ Análise de Impacto

### Arquivos Afetados
**Criar:**
- `path/to/file.py` - [propósito]

**Modificar:**
- `path/to/file.py` - [mudança]

### Dependências
**Internas:** [módulos]
**Externas:** [serviços]
**Bibliotecas:** [pacotes Python]

### Riscos
| Risco | Prob | Impacto | Mitigação |
|-------|------|---------|-----------|
| [X] | [Alta] | [Alto] | [Como] |

## 4️⃣ Especificação Técnica

### Fluxo de Dados
[descrição passo a passo]

### Estrutura de Dados
[DTOs, models, documentos Firestore]

### Casos de Teste
[lista de cenários]

## 5️⃣ Próximos Passos

- [ ] Esclarecer ambiguidades (se houver)
- [ ] Obter aprovação do plano
- [ ] Iniciar implementação
