# Response Body Data Types

Validation of data types in the response body.

## Principle

Always validate data types in addition to values to ensure the data structure is correct.

---

## ✅ Correct Pattern

```python
# Validate basic types
json_response = response.json()
assert isinstance(json_response["count"], int)
assert isinstance(json_response["items"], list)
assert isinstance(json_response["metadata"], dict)
assert isinstance(json_response["name"], str)
assert isinstance(json_response["price"], float)
assert json_response["active"] is True  # specific boolean
assert json_response["deleted"] is False

# Validate None explicitly
assert json_response["optional_field"] is None
```

---

## ❌ Anti-Pattern

```python
# BAD: Does not validate type
assert json_response["count"]  # could be anything
assert json_response["items"]  # does not validate if it is a list

# BAD: Vague boolean validation
assert json_response["active"]  # True could be any truthy value
```

**Problems:**
- Does not ensure the correct data type
- May accept unexpected types
- Tests may pass with poorly formatted data

---

## Usage in Tests

### Example 1: Basic Types

```python
async def test_get_product_validates_types(http_client: AsyncClient):
    """Tests that product data types are correct."""
    # Arrange
    mock_db = MagicMock()
    mock_db.retrieve.return_value = {
        "id": "prod123",
        "name": "Example Product",
        "price": 99.90,
        "stock": 10,
        "active": True,
        "tags": ["tag1", "tag2"]
    }
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.get("/products/prod123")

    # Assert - Data types
    json_response = response.json()
    assert isinstance(json_response["id"], str)
    assert isinstance(json_response["name"], str)
    assert isinstance(json_response["price"], float)
    assert isinstance(json_response["stock"], int)
    assert isinstance(json_response["tags"], list)
    assert json_response["active"] is True  # explicit boolean

    # Assert - Values as well
    assert json_response["price"] == 99.90
    assert json_response["stock"] == 10

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 2: Nested Types

```python
async def test_get_user_profile_validates_nested_types(http_client: AsyncClient):
    """Tests data types in nested objects."""
    # Arrange
    mock_db = MagicMock()
    mock_db.retrieve.return_value = {
        "id": "user123",
        "profile": {
            "bio": "Developer",
            "age": 30,
            "verified": True,
            "skills": ["Python", "FastAPI"]
        },
        "metadata": {
            "login_count": 42,
            "last_login": "2024-01-01T00:00:00Z"
        }
    }
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.get("/users/user123/profile")

    # Assert - Root level types
    json_response = response.json()
    assert isinstance(json_response["id"], str)
    assert isinstance(json_response["profile"], dict)
    assert isinstance(json_response["metadata"], dict)

    # Assert - Nested types in profile
    assert isinstance(json_response["profile"]["bio"], str)
    assert isinstance(json_response["profile"]["age"], int)
    assert json_response["profile"]["verified"] is True
    assert isinstance(json_response["profile"]["skills"], list)

    # Assert - Nested types in metadata
    assert isinstance(json_response["metadata"]["login_count"], int)
    assert isinstance(json_response["metadata"]["last_login"], str)

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 3: List of Objects

```python
async def test_list_items_validates_list_types(http_client: AsyncClient):
    """Tests types in a list of objects."""
    # Arrange
    mock_db = MagicMock()
    mock_db.query.return_value = [
        {"id": "item1", "count": 10, "active": True},
        {"id": "item2", "count": 20, "active": False}
    ]
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.get("/items")

    # Assert - List type
    json_response = response.json()
    assert isinstance(json_response["items"], list)
    assert len(json_response["items"]) == 2

    # Assert - Types of items
    for item in json_response["items"]:
        assert isinstance(item["id"], str)
        assert isinstance(item["count"], int)
        assert isinstance(item["active"], bool)

    # Assert - Specific values
    assert json_response["items"][0]["active"] is True
    assert json_response["items"][1]["active"] is False

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 4: None Values

```python
async def test_optional_field_can_be_none(http_client: AsyncClient):
    """Tests that optional field can be None."""
    # Arrange
    mock_db = MagicMock()
    mock_db.retrieve.return_value = {
        "id": "user123",
        "name": "John",
        "bio": None  # optional field not filled
    }
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.get("/users/user123")

    # Assert - Explicit None type
    json_response = response.json()
    assert json_response["bio"] is None
    assert isinstance(json_response["name"], str)

    # Cleanup
    app.dependency_overrides.clear()
```

---

## Common Types

| Python Type | Validation | Example |
|--------------|-----------|---------|
| `str` | `isinstance(value, str)` | `"John Doe"` |
| `int` | `isinstance(value, int)` | `42` |
| `float` | `isinstance(value, float)` | `99.90` |
| `bool` | `value is True/False` | `True`, `False` |
| `list` | `isinstance(value, list)` | `["a", "b"]` |
| `dict` | `isinstance(value, dict)` | `{"key": "value"}` |
| `None` | `value is None` | `None` |

---

## Checklist

When validating data types:

- [ ] ✅ Use `isinstance()` for basic types (str, int, float, list, dict)
- [ ] ✅ Use `is True/False` for booleans (not `==`)
- [ ] ✅ Use `is None` for None values (not `==`)
- [ ] ✅ Validate types in nested structures
- [ ] ✅ Validate types of all items in lists
- [ ] ✅ Combine type validation with value validation
