# Exception Handling

Guidance and patterns for testing exception handling in controllers and functions.

## Principle

Use `pytest.raises()` to capture and assert exceptions, especially `HTTPException` in FastAPI controllers.

---

## ✅ Correct Pattern

```python
# Capture and validate HTTPException
with pytest.raises(HTTPException) as exc_info:
    await controller_function()
assert exc_info.value.status_code == status.HTTP_404_NOT_FOUND
assert exc_info.value.detail == "User not found"

# Capture a generic exception
with pytest.raises(ValueError) as exc_info:
    process_data(invalid_input)
assert "invalid format" in str(exc_info.value)
```

---

## ❌ Anti-Pattern

```python
# BAD: Not capturing the exception
await controller_function()  # may raise an unhandled exception

# BAD: Catching but not validating
try:
    await controller_function()
except HTTPException:
    pass  # does not validate status or message
```

**Problems:**
- Test may fail with an unexpected error
- Does not assert the correct exception type was raised
- Does not validate exception details

---

## Usage in Tests

### Example 1: Basic HTTPException

```python
async def test_get_user_not_found_raises_exception():
    """Tests that the controller raises HTTPException when the user does not exist."""
    # Arrange
    from api.users.controllers.get_user import get_user

    mock_db = MagicMock()
    mock_db.retrieve.return_value = None

    # Act & Assert
    with pytest.raises(HTTPException) as exc_info:
        await get_user(user_id="nonexistent", db=mock_db)

    # Assert - Status code
    assert exc_info.value.status_code == status.HTTP_404_NOT_FOUND

    # Assert - Message
    assert exc_info.value.detail == "User not found"
```

### Example 2: Exceptions with Different Status Codes

```python
@pytest.mark.parametrize("scenario,status_code,message", [
    ("not_found", 404, "User not found"),
    ("forbidden", 403, "Access denied"),
    ("conflict", 409, "User already exists")
], ids=["not-found", "forbidden", "conflict"])
async def test_controller_exceptions(
    scenario: str,
    status_code: int,
    message: str
):
    """Tests different controller exceptions."""
    # Arrange
    from api.users.controllers.user_controller import process_user

    mock_db = MagicMock()

    if scenario == "not_found":
        mock_db.retrieve.return_value = None
    elif scenario == "forbidden":
        mock_db.retrieve.return_value = {"id": "user123", "role": "user"}
    elif scenario == "conflict":
        mock_db.retrieve.return_value = {"id": "existing"}

    # Act & Assert
    with pytest.raises(HTTPException) as exc_info:
        await process_user(scenario=scenario, db=mock_db)

    assert exc_info.value.status_code == status_code
    assert exc_info.value.detail == message
```

### Example 3: Custom Exception

```python
class InsufficientStockError(Exception):
    """Exception for insufficient stock."""
    pass


async def test_purchase_insufficient_stock_raises_custom_exception():
    """Tests that a purchase with insufficient stock raises a custom exception."""
    # Arrange
    from api.store.controllers.purchase import process_purchase

    mock_db = MagicMock()
    mock_db.retrieve.return_value = {
        "id": "prod123",
        "stock": 5
    }

    # Act & Assert
    with pytest.raises(InsufficientStockError) as exc_info:
        await process_purchase(
            product_id="prod123",
            quantity=10,  # greater than available stock
            db=mock_db
        )

    # Assert - Exception message
    assert "insufficient stock" in str(exc_info.value).lower()
```

### Example 4: Validation Exception

```python
async def test_validate_email_invalid_format_raises_exception():
    """Tests that invalid email validation raises an exception."""
    # Arrange
    from api.utils import validate_email

    invalid_email = "not-an-email"

    # Act & Assert
    with pytest.raises(ValueError) as exc_info:
        validate_email(invalid_email)

    # Assert - Message contains error information
    assert "invalid email format" in str(exc_info.value).lower()
    assert invalid_email in str(exc_info.value)
```

### Example 5: Exception with Payload

```python
async def test_controller_exception_includes_details():
    """Tests that an exception includes additional details."""
    # Arrange
    from api.payments.controllers.process_payment import process_payment

    mock_payment = MagicMock()
    mock_payment.charge.side_effect = Exception("Card declined")

    # Act & Assert
    with pytest.raises(HTTPException) as exc_info:
        await process_payment(
            amount=99.90,
            card="4242424242424242",
            payment_engine=mock_payment
        )

    # Assert - Status code
    assert exc_info.value.status_code == status.HTTP_400_BAD_REQUEST

    # Assert - Details include error information
    assert "payment failed" in exc_info.value.detail.lower()
```

### Example 6: No Exception Raised (Negative Scenario)

```python
async def test_valid_input_does_not_raise_exception():
    """Tests that valid input does not raise an exception."""
    # Arrange
    from api.users.controllers.create_user import create_user

    mock_db = MagicMock()
    mock_db.retrieve.return_value = None  # user does not exist
    mock_db.create.return_value = {"id": "user123"}

    valid_data = {
        "name": "John Doe",
        "email": "joao@example.com"
    }

    # Act - Should not raise an exception
    try:
        result = await create_user(data=valid_data, db=mock_db)

        # Assert - Operation successful
        assert result["id"] == "user123"
    except HTTPException:
        pytest.fail("Should not raise HTTPException with valid input")
```

### Example 7: Exception in Nested Call

```python
async def test_nested_call_propagates_exception():
    """Tests that an exception from a nested function is propagated."""
    # Arrange
    from api.orders.controllers.create_order import create_order

    mock_db = MagicMock()
    mock_db.retrieve.side_effect = Exception("Database connection error")

    # Act & Assert
    with pytest.raises(HTTPException) as exc_info:
        await create_order(
            customer_id="user123",
            items=[{"product_id": "prod1", "quantity": 1}],
            db=mock_db
        )

    # Assert - Propagated exception with context
    assert exc_info.value.status_code == status.HTTP_500_INTERNAL_SERVER_ERROR
    assert "internal error" in exc_info.value.detail.lower()
```

### Example 8: Multiple Possible Exceptions

```python
@pytest.mark.parametrize("error,expected_exception", [
    (ValueError("Invalid input"), HTTPException),
    (KeyError("missing_field"), HTTPException),
    (TypeError("wrong type"), HTTPException)
], ids=["value-error", "key-error", "type-error"])
async def test_controller_handles_different_exceptions(
    error: Exception,
    expected_exception: type
):
    """Tests that the controller handles different exception types."""
    # Arrange
    from api.generic.controllers.processor import process_data

    mock_db = MagicMock()
    mock_db.retrieve.side_effect = error

    # Act & Assert
    with pytest.raises(expected_exception) as exc_info:
        await process_data(data_id="123", db=mock_db)

    # Assert - Exception is of the expected type
    assert isinstance(exc_info.value, expected_exception)

    # Assert - Status 500 for internal errors
    if expected_exception == HTTPException:
        assert exc_info.value.status_code == status.HTTP_500_INTERNAL_SERVER_ERROR
```

---

## Context Manager pytest.raises()

```python
with pytest.raises(ExceptionType) as exc_info:
    # code that should raise an exception
    function_that_raises()

# After the block, validate details
assert exc_info.value.attribute == expected_value
```

| Attribute | Description |
|----------|-----------|
| `exc_info.value` | Instance of the captured exception |
| `exc_info.type` | Exception type |
| `exc_info.typename` | Type name as a string |

---

## HTTPException Attributes

```python
# FastAPI HTTPException
exc_info.value.status_code  # HTTP status code
exc_info.value.detail       # error message
exc_info.value.headers      # optional headers
```

---

## Checklist

When testing exception handling:

- [ ] ✅ Use `pytest.raises()` to capture exceptions
- [ ] ✅ Assert the correct exception type
- [ ] ✅ Assert `status_code` for HTTPException
- [ ] ✅ Assert the exception message/detail
- [ ] ✅ Test that exceptions are raised at the right time
- [ ] ✅ Test that valid code does NOT raise exceptions
- [ ] ✅ Validate propagation of nested exceptions
- [ ] ✅ Test different exception types when applicable
