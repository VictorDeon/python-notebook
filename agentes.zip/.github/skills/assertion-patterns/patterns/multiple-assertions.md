# Multiple Assertions

Multiple related assertions for complete validation.

## Principle

Always use multiple related assertions to fully validate a response, not just a single validation.

---

## ✅ Correct Pattern

```python
# Multiple assertions relacionadas
json_response = response.json()
assert response.status_code == status.HTTP_201_CREATED
assert json_response["id"] is not None
assert json_response["name"] == "John"
# Multiple Assertions

Related multiple assertions for comprehensive validation.

## Principle

Always use related multiple assertions to fully validate a response, not just a single check.

---

## ✅ Correct Pattern

```python
# Related multiple assertions
json_response = response.json()
assert response.status_code == status.HTTP_201_CREATED
assert json_response["id"] is not None
assert json_response["name"] == "John"
assert json_response["email"] == "joao@example.com"
assert "created_at" in json_response
assert isinstance(json_response["id"], str)
```

---

## ❌ Anti-Pattern

```python
# BAD: Only a single assertion
assert response.status_code == 201
# does not validate the body

# BAD: Vague assertion
assert response.json()
# does not validate structure or values
```

**Problems:**
- Does not guarantee the full integrity of the response
- May pass with partially incorrect data
- Makes debugging harder when something is wrong

---

## Usage in Tests

### Example 1: Complete Create Validation

```python
async def test_create_user_complete_validation(http_client: AsyncClient):
    """Tests user creation with complete validation."""
    # Arrange
    mock_db = MagicMock()
    mock_db.create.return_value = {"id": "user123"}
    app.dependency_overrides[get_database] = lambda: mock_db

    payload = {
        "name": "John Doe",
        "email": "joao@example.com",
        "age": 30
    }

    # Act
    response = await http_client.post("/users", json=payload)

    # Assert - Status Code
    assert response.status_code == status.HTTP_201_CREATED

    # Assert - Response Structure
    json_response = response.json()
    assert "id" in json_response
    assert "name" in json_response
    assert "email" in json_response
    assert "age" in json_response
    assert "created_at" in json_response

    # Assert - Response Values
    assert json_response["id"] == "user123"
    assert json_response["name"] == "John Doe"
    assert json_response["email"] == "joao@example.com"
    assert json_response["age"] == 30

    # Assert - Response Types
    assert isinstance(json_response["id"], str)
    assert isinstance(json_response["name"], str)
    assert isinstance(json_response["email"], str)
    assert isinstance(json_response["age"], int)
    assert isinstance(json_response["created_at"], str)

    # Assert - Mock Calls
    from unittest.mock import ANY
    mock_db.create.assert_called_once_with("users", {
        "name": "John Doe",
        "email": "joao@example.com",
        "age": 30,
        "created_at": ANY
    })

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 2: Complete Error Validation

```python
async def test_get_user_not_found_complete_validation(
    http_client: AsyncClient
):
    """Tests user not found error with complete validation."""
    # Arrange
    mock_db = MagicMock()
    mock_db.retrieve.return_value = None
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.get("/users/nonexistent")

    # Assert - Status Code
    assert response.status_code == status.HTTP_404_NOT_FOUND

    # Assert - Response Structure
    json_response = response.json()
    assert "message" in json_response
    assert "error_code" in json_response

    # Assert - Response Values
    assert json_response["message"] == "User not found"
    assert json_response["error_code"] == "USER_NOT_FOUND"

    # Assert - Response Types
    assert isinstance(json_response["message"], str)
    assert isinstance(json_response["error_code"], str)

    # Assert - Mock Calls
    mock_db.retrieve.assert_called_once_with("users", "nonexistent")

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 3: Complete Listing Validation

```python
async def test_list_products_complete_validation(http_client: AsyncClient):
    """Tests listing products with complete validation."""
    # Arrange
    mock_db = MagicMock()
    mock_db.count.return_value = 25
    mock_db.query.return_value = [
        {"id": "prod1", "name": "Product A", "price": 99.90, "active": True},
        {"id": "prod2", "name": "Product B", "price": 149.90, "active": False}
    ]
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.get("/products?page=1&page_size=10")

    # Assert - Status Code
    assert response.status_code == status.HTTP_200_OK

    # Assert - Response Structure
    json_response = response.json()
    assert "items" in json_response
    assert "total" in json_response
    assert "page" in json_response
    assert "page_size" in json_response
    assert "has_next" in json_response
    assert "has_previous" in json_response

    # Assert - Pagination Metadata
    assert json_response["total"] == 25
    assert json_response["page"] == 1
    assert json_response["page_size"] == 10
    assert json_response["has_next"] is True
    assert json_response["has_previous"] is False

    # Assert - Items List
    items = json_response["items"]
    assert isinstance(items, list)
    assert len(items) == 2

    # Assert - First Item
    item1 = items[0]
    assert item1["id"] == "prod1"
    assert item1["name"] == "Product A"
    assert item1["price"] == 99.90
    assert item1["active"] is True
    assert isinstance(item1["price"], float)

    # Assert - Second Item
    item2 = items[1]
    assert item2["id"] == "prod2"
    assert item2["active"] is False

    # Assert - All Items Have Required Fields
    assert all("id" in item for item in items)
    assert all("name" in item for item in items)
    assert all("price" in item for item in items)

    # Assert - Mock Calls
    mock_db.count.assert_called_once()
    mock_db.query.assert_called_once()

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 4: Complete Update Validation

```python
async def test_update_product_complete_validation(http_client: AsyncClient):
    """Tests updating a product with complete validation."""
    # Arrange
    mock_db = MagicMock()
    mock_db.retrieve.return_value = {
        "id": "prod123",
        "name": "Old Name",
        "price": 99.90,
        "created_at": "2024-01-01T00:00:00Z"
    }
    mock_db.update.return_value = None
    app.dependency_overrides[get_database] = lambda: mock_db

    payload = {
        "name": "New Name",
        "price": 149.90
    }

    # Act
    response = await http_client.put("/products/prod123", json=payload)

    # Assert - Status Code
    assert response.status_code == status.HTTP_200_OK

    # Assert - Response Structure
    json_response = response.json()
    assert "id" in json_response
    assert "name" in json_response
    assert "price" in json_response
    assert "created_at" in json_response
    assert "updated_at" in json_response

    # Assert - Values Updated
    assert json_response["id"] == "prod123"
    assert json_response["name"] == "New Name"
    assert json_response["price"] == 149.90

    # Assert - Timestamps
    assert json_response["created_at"] == "2024-01-01T00:00:00Z"
    assert "updated_at" in json_response

    # Assert - Types
    assert isinstance(json_response["price"], float)
    assert isinstance(json_response["name"], str)

    # Assert - Mock Calls (Order Matters)
    from unittest.mock import call, ANY
    expected_calls = [
        call.retrieve("products", "prod123"),
        call.update("products", "prod123", {
            "name": "New Name",
            "price": 149.90,
            "updated_at": ANY
        })
    ]
    mock_db.assert_has_calls(expected_calls, any_order=False)

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 5: Complete Nested Response Validation

```python
async def test_get_order_with_nested_data_complete(
    http_client: AsyncClient
):
    """Tests an order with nested data and complete validation."""
    # Arrange
    mock_db = MagicMock()
    mock_db.retrieve.return_value = {
        "id": "order123",
        "status": "pending",
        "customer": {
            "id": "user123",
            "name": "John Doe",
            "email": "joao@example.com"
        },
        "items": [
            {
                "product_id": "prod1",
                "quantity": 2,
                "price": 99.90
            }
        ],
        "total": 199.80,
        "created_at": "2024-01-01T00:00:00Z"
    }
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.get("/orders/order123")

    # Assert - Status
    assert response.status_code == status.HTTP_200_OK

    # Assert - Root Level Structure
    json_response = response.json()
    assert "id" in json_response
    assert "status" in json_response
    assert "customer" in json_response
    assert "items" in json_response
    assert "total" in json_response
    assert "created_at" in json_response

    # Assert - Root Level Values
    assert json_response["id"] == "order123"
    assert json_response["status"] == "pending"
    assert json_response["total"] == 199.80

    # Assert - Customer Structure
    customer = json_response["customer"]
    assert "id" in customer
    assert "name" in customer
    assert "email" in customer

    # Assert - Customer Values
    assert customer["id"] == "user123"
    assert customer["name"] == "John Doe"
    assert customer["email"] == "joao@example.com"

    # Assert - Items List
    items = json_response["items"]
    assert isinstance(items, list)
    assert len(items) == 1

    # Assert - First Item Structure
    item = items[0]
    assert "product_id" in item
    assert "quantity" in item
    assert "price" in item

    # Assert - First Item Values
    assert item["product_id"] == "prod1"
    assert item["quantity"] == 2
    assert item["price"] == 99.90

    # Assert - Types
    assert isinstance(json_response["total"], float)
    assert isinstance(customer["name"], str)
    assert isinstance(item["quantity"], int)

    # Assert - Mock Calls
    mock_db.retrieve.assert_called_once_with("orders", "order123")

    # Cleanup
    app.dependency_overrides.clear()
```

---

## Assertion Categories

### 1. HTTP Status

```python
assert response.status_code == status.HTTP_200_OK
```

### 2. Response Structure

```python
assert "field" in json_response
assert isinstance(json_response["field"], expected_type)
```

### 3. Specific Values

```python
assert json_response["field"] == expected_value
```

### 4. Data Types

```python
assert isinstance(json_response["field"], str)
```

### 5. Mock Calls

```python
mock.assert_called_once_with(expected_args)
```

### 6. Logical Conditions

```python
assert json_response["value"] > 0
assert json_response["status"] in ["active", "pending"]
```

---

## Assertion Checklist

For each test, include:

- [ ] ✅ Status code
- [ ] ✅ Response structure (required fields present)
- [ ] ✅ Specific field values
- [ ] ✅ Data types
- [ ] ✅ Nested data (if any)
- [ ] ✅ Lists (size and content)
- [ ] ✅ Mock calls
- [ ] ✅ Mock arguments
- [ ] ✅ Call order (when relevant)
- [ ] ✅ Metadata (pagination, timestamps, etc.)

---

## Benefits

- ✅ **Complete Validation**: Ensures full response integrity
- ✅ **Easier Debugging**: Makes specific failures obvious
- ✅ **Documentation**: Assertions act as documentation
- ✅ **Confidence**: Produces robust, reliable tests
- ✅ **Maintainability**: Easier to identify what changed
