# Response Body Nested Data

Validation of nested data in the response body.

## Principle

Always validate nested structures completely, including objects within objects and lists within objects.

---

## ✅ Correct Pattern

```python
# Validate nested object
json_response = response.json()
assert json_response["user"]["id"] == "user123"
assert json_response["user"]["profile"]["name"] == "John"
assert len(json_response["user"]["permissions"]) == 2

# Validate nested list
assert isinstance(json_response["items"], list)
assert json_response["items"][0]["details"]["price"] == 99.90

# Validate multiple levels
assert json_response["data"]["meta"]["pagination"]["page"] == 1
```

---

## ❌ Anti-Pattern

```python
# BAD: Only check root level
assert "user" in json_response  # does not validate content

# BAD: Too shallow
assert json_response["user"]  # does not validate internal structure
```

**Problems:**
- Does not ensure nested structure is correct
- May pass even with incorrect nested data
- Does not detect issues in deep levels

---

## Usage in Tests

### Example 1: Simple Nested Object

```python
async def test_get_user_with_profile(http_client: AsyncClient):
    """Tests retrieval of user with nested profile."""
    # Arrange
    mock_db = MagicMock()
    mock_db.retrieve.return_value = {
        "id": "user123",
        "name": "John Doe",
        "profile": {
            "bio": "Python Developer",
            "avatar": "https://example.com/avatar.jpg",
            "location": "São Paulo"
        }
    }
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.get("/users/user123")

    # Assert - Root level
    json_response = response.json()
    assert json_response["id"] == "user123"
    assert json_response["name"] == "John Doe"
    assert "profile" in json_response

    # Assert - Nested object
    profile = json_response["profile"]
    assert profile["bio"] == "Python Developer"
    assert profile["avatar"] == "https://example.com/avatar.jpg"
    assert profile["location"] == "São Paulo"

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 2: Multiple Levels of Nesting

```python
async def test_get_order_with_nested_data(http_client: AsyncClient):
    """Tests order with multiple levels of nested data."""
    # Arrange
    mock_db = MagicMock()
    mock_db.retrieve.return_value = {
        "id": "order123",
        "customer": {
            "id": "user123",
            "name": "John Doe",
            "address": {
                "street": "123 Example St",
                "city": "São Paulo",
                "country": "Brazil"
            }
        },
        "items": [
            {
                "id": "item1",
                "product": {
                    "name": "Product A",
                    "price": 99.90
                }
            }
        ]
    }
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.get("/orders/order123")

    # Assert - Level 1: Root
    json_response = response.json()
    assert json_response["id"] == "order123"

    # Assert - Level 2: Customer
    customer = json_response["customer"]
    assert customer["id"] == "user123"
    assert customer["name"] == "John Doe"

    # Assert - Level 3: Address
    address = customer["address"]
    assert address["street"] == "123 Example St"
    assert address["city"] == "São Paulo"
    assert address["country"] == "Brazil"

    # Assert - Level 2: Items (list)
    items = json_response["items"]
    assert len(items) == 1

    # Assert - Level 3: Item and Product
    item = items[0]
    assert item["id"] == "item1"
    assert item["product"]["name"] == "Product A"
    assert item["product"]["price"] == 99.90

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 3: List of Nested Objects

```python
async def test_list_posts_with_authors(http_client: AsyncClient):
    """Tests listing of posts with nested authors."""
    # Arrange
    mock_db = MagicMock()
    mock_db.query.return_value = [
        {
            "id": "post1",
            "title": "Post 1",
            "author": {
                "id": "user1",
                "name": "John",
                "stats": {
                    "posts": 10,
                    "followers": 100
                }
            }
        },
        {
            "id": "post2",
            "title": "Post 2",
            "author": {
                "id": "user2",
                "name": "Mary",
                "stats": {
                    "posts": 20,
                    "followers": 200
                }
            }
        }
    ]
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.get("/posts")

    # Assert - List
    json_response = response.json()
    assert len(json_response["items"]) == 2

    # Assert - First post and author
    post1 = json_response["items"][0]
    assert post1["id"] == "post1"
    assert post1["title"] == "Post 1"
    assert post1["author"]["id"] == "user1"
    assert post1["author"]["name"] == "John"
    assert post1["author"]["stats"]["posts"] == 10
    assert post1["author"]["stats"]["followers"] == 100

    # Assert - Second post and author
    post2 = json_response["items"][1]
    assert post2["id"] == "post2"
    assert post2["author"]["stats"]["posts"] == 20

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 4: Nested List in Object

```python
async def test_get_team_with_members(http_client: AsyncClient):
    """Tests team with nested list of members."""
    # Arrange
    mock_db = MagicMock()
    mock_db.retrieve.return_value = {
        "id": "team123",
        "name": "Dev Team",
        "members": [
            {
                "id": "user1",
                "name": "John",
                "role": "Developer"
            },
            {
                "id": "user2",
                "name": "Mary",
                "role": "Designer"
            }
        ]
    }
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.get("/teams/team123")

    # Assert - Root
    json_response = response.json()
    assert json_response["id"] == "team123"
    assert json_response["name"] == "Dev Team"

    # Assert - List of members
    members = json_response["members"]
    assert isinstance(members, list)
    assert len(members) == 2

    # Assert - First member
    assert members[0]["id"] == "user1"
    assert members[0]["name"] == "John"
    assert members[0]["role"] == "Developer"

    # Assert - Second member
    assert members[1]["id"] == "user2"
    assert members[1]["role"] == "Designer"

    # Cleanup
    app.dependency_overrides.clear()
```

---

## Validation Strategies

### 1. Layered Validation

Validate from outside in:

```python
# Level 1: Root
assert "user" in json_response

# Level 2: Nested object
assert "profile" in json_response["user"]

# Level 3: Deep data
assert json_response["user"]["profile"]["bio"] == "Developer"
```

### 2. Use Variables for Clarity

```python
# Extract nested objects into variables
user = json_response["user"]
profile = user["profile"]
address = profile["address"]

# Validate using variables
assert address["city"] == "São Paulo"
```

### 3. Validate All Items in Nested Lists

```python
# Validate each item in the nested list
for member in json_response["team"]["members"]:
    assert "id" in member
    assert "name" in member
    assert isinstance(member["id"], str)
```

---

## Checklist

When validating nested data:

- [ ] ✅ Validate presence of parent object
- [ ] ✅ Validate internal structure of nested object
- [ ] ✅ Validate specific values at all levels
- [ ] ✅ Use variables for deeply nested objects
- [ ] ✅ Validate nested lists (size and content)
- [ ] ✅ Validate types at all levels
- [ ] ✅ Test multiple levels of nesting when applicable
