# Mock Call Validation

Verification that mocks were called correctly with the expected arguments.

## Principle

Always validate that mocks were called the correct number of times and with the correct arguments. Use `ANY` for dynamic values such as timestamps.

---

## ✅ Correct Pattern

```python
from unittest.mock import ANY

# Validate single call
mock_db.collection.assert_called_once_with("users")

# Validate multiple calls
mock_db.collection().document.assert_called_once_with("user123")
mock_db.collection().document().get.assert_called_once()

# Validate arguments using ANY for dynamic values
mock_db.update.assert_called_once_with("users", "user123", {
    "name": "John",
    "updated_at": ANY  # dynamic timestamp
})

# Validate specific calls among others
mock_db.retrieve.assert_any_call("users", "user123")
assert mock_db.create.call_count == 2

# Validate that it was NOT called
mock_db.delete.assert_not_called()
```

---

## ❌ Anti-Pattern

```python
# BAD: Not validating the call
mock_db.collection()  # does not check if it was called

# BAD: Not checking arguments
mock_db.retrieve()  # does not validate which arguments

# BAD: Generic validation
assert mock_db.collection.called  # does not validate the count
assert mock_db.retrieve.call_count > 0  # too vague
```

**Problems:**
- Does not guarantee the mock was used correctly
- May pass even if the mock was not called
- Does not detect incorrect arguments

---

## Usage in Tests

### Example 1: Basic Mock Validation

```python
async def test_create_user_calls_database(http_client: AsyncClient):
    """Tests that creating a user calls the database correctly."""
    # Arrange
    mock_db = MagicMock()
    mock_db.create.return_value = {"id": "user123"}
    app.dependency_overrides[get_database] = lambda: mock_db

    payload = {
        "name": "John Doe",
        "email": "joao@example.com"
    }

    # Act
    response = await http_client.post("/users", json=payload)

    # Assert - Mock was called
    from unittest.mock import ANY
    mock_db.create.assert_called_once_with("users", {
        "name": "John Doe",
        "email": "joao@example.com",
        "created_at": ANY  # dynamic timestamp
    })

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 2: Multiple Mock Calls

```python
async def test_update_user_calls_retrieve_and_update(http_client: AsyncClient):
    """Tests that update calls retrieve and then update."""
    # Arrange
    mock_db = MagicMock()
    mock_db.retrieve.return_value = {"id": "user123", "name": "John"}
    mock_db.update.return_value = {"id": "user123", "name": "John Doe"}
    app.dependency_overrides[get_database] = lambda: mock_db

    payload = {"name": "John Doe"}

    # Act
    response = await http_client.put("/users/user123", json=payload)

    # Assert - Retrieve was called first
    mock_db.retrieve.assert_called_once_with("users", "user123")

    # Assert - Update was called afterwards
    from unittest.mock import ANY
    mock_db.update.assert_called_once_with("users", "user123", {
        "name": "John Doe",
        "updated_at": ANY
    })

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 3: Validate Call Count

```python
async def test_batch_operation_calls_create_multiple_times(
    http_client: AsyncClient
):
    """Tests a batch operation that creates multiple records."""
    # Arrange
    mock_db = MagicMock()
    mock_db.create.return_value = {"id": "item123"}
    app.dependency_overrides[get_database] = lambda: mock_db

    payload = {
        "items": [
            {"name": "Item 1"},
            {"name": "Item 2"},
            {"name": "Item 3"}
        ]
    }

    # Act
    response = await http_client.post("/items/batch", json=payload)

    # Assert - Create was called 3 times
    assert mock_db.create.call_count == 3

    # Assert - Inspect arguments of each call
    calls = mock_db.create.call_args_list
    assert calls[0][0][1]["name"] == "Item 1"
    assert calls[1][0][1]["name"] == "Item 2"
    assert calls[2][0][1]["name"] == "Item 3"

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 4: Validate That It Was Not Called

```python
async def test_delete_user_not_found_does_not_call_delete(
    http_client: AsyncClient
):
    """Tests that delete is not called when the user does not exist."""
    # Arrange
    mock_db = MagicMock()
    mock_db.retrieve.return_value = None  # user does not exist
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.delete("/users/nonexistent")

    # Assert - Retrieve was called
    mock_db.retrieve.assert_called_once_with("users", "nonexistent")

    # Assert - Delete was NOT called
    mock_db.delete.assert_not_called()

    # Assert - Status 404
    assert response.status_code == status.HTTP_404_NOT_FOUND

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 5: Validate Calls with ANY

```python
async def test_create_order_with_dynamic_values(http_client: AsyncClient):
    """Tests creating an order with dynamic values."""
    # Arrange
    mock_db = MagicMock()
    mock_db.create.return_value = {"id": "order123"}
    app.dependency_overrides[get_database] = lambda: mock_db

    payload = {
        "customer_id": "user123",
        "items": [{"product_id": "prod1", "quantity": 2}]
    }

    # Act
    response = await http_client.post("/orders", json=payload)

    # Assert - Mock called with ANY for dynamic values
    from unittest.mock import ANY
    mock_db.create.assert_called_once_with("orders", {
        "customer_id": "user123",
        "items": ANY,  # complex list
        "created_at": ANY,  # timestamp
        "order_number": ANY,  # auto-generated
        "status": "pending"  # expected fixed value
    })

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 6: Validate assert_any_call

```python
async def test_process_items_calls_update_for_each(http_client: AsyncClient):
    """Tests that processing updates each item."""
    # Arrange
    mock_db = MagicMock()
    mock_db.query.return_value = [
        {"id": "item1", "status": "pending"},
        {"id": "item2", "status": "pending"}
    ]
    mock_db.update.return_value = None
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.post("/items/process")

    # Assert - Query was called
    mock_db.query.assert_called_once()

    # Assert - Update was called for item1
    from unittest.mock import ANY
    mock_db.update.assert_any_call("items", "item1", {
        "status": "processed",
        "processed_at": ANY
    })

    # Assert - Update was called for item2
    mock_db.update.assert_any_call("items", "item2", {
        "status": "processed",
        "processed_at": ANY
    })

    # Assert - Total calls
    assert mock_db.update.call_count == 2

    # Cleanup
    app.dependency_overrides.clear()
```

---

## Validation Methods

| Method | Usage | When to Use |
|--------|-----|-------------|
| `assert_called_once()` | Mock was called exactly once | Single operations |
| `assert_called_once_with(*args)` | Mock was called once with specific args | Validate arguments |
| `assert_called()` | Mock was called at least once | Check it was used |
| `assert_not_called()` | Mock was never called | Validate it was not executed |
| `assert_any_call(*args)` | Mock was called with these args (among other calls) | Multiple calls |
| `call_count` | Total number of calls | Batch operations |
| `call_args_list` | List of all calls with arguments | Inspect individual calls |

---

## Using ANY

Use `ANY` from `unittest.mock` for values that are:

- **Timestamps**: `created_at`, `updated_at`, `deleted_at`
- **Generated UUIDs/IDs**: `id`, `order_number`
- **Calculated values**: `total`, `hash`
- **Complex lists**: When internal structure is not important

```python
from unittest.mock import ANY

mock_db.create.assert_called_once_with("collection", {
    "static_value": "fixed",
    "dynamic_value": ANY,
    "timestamp": ANY
})
```

---

## Checklist

When validating mock calls:

- [ ] ✅ Use `assert_called_once_with()` for single calls
- [ ] ✅ Use `assert_any_call()` for multiple calls
- [ ] ✅ Use `assert_not_called()` when it should not be called
- [ ] ✅ Validate specific arguments when possible
- [ ] ✅ Use `ANY` for dynamic values (timestamps, IDs)
- [ ] ✅ Check `call_count` for batch operations
- [ ] ✅ Inspect `call_args_list` when necessary
- [ ] ✅ Validate call order when relevant

