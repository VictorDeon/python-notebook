# Timestamps and Dates

Validation of timestamps and dates in responses.

## Principle

Validate the format of timestamps and dates, but use `ANY` in mocks for dynamically generated system values.

---

## ✅ Correct Pattern

```python
from unittest.mock import ANY
from datetime import datetime

# Validate presence of the timestamp
json_response = response.json()
assert "created_at" in json_response

# Validate ISO 8601 format
datetime.fromisoformat(json_response["created_at"].replace("Z", "+00:00"))

# Use ANY in mocks for dynamic timestamps
mock_db.create.assert_called_once_with({
    "name": "John",
    "created_at": ANY  # dynamically generated
})
```

---

## ❌ Anti-Pattern

```python
# BAD: Hard-coded timestamp
assert json_response["created_at"] == "2024-01-01T00:00:00Z"  # will fail

# BAD: Does not validate format
assert "created_at" in json_response  # does not validate if it is valid

# BAD: Compare exact timestamps in mocks
mock_db.create.assert_called_with({
    "created_at": "2024-01-01T00:00:00Z"  # specific timestamp will fail
})
```

**Problems:**
- Hard-coded timestamps will fail in different executions
- Does not ensure the format is correct
- Tests become fragile and depend on execution time

---

## Usage in Tests

### Example 1: Validate Presence and Format

```python
async def test_create_user_returns_timestamp(http_client: AsyncClient):
    """Tests that creation returns a valid timestamp."""
    # Arrange
    mock_db = MagicMock()
    mock_db.create.return_value = {"id": "user123"}
    app.dependency_overrides[get_database] = lambda: mock_db

    payload = {
        "name": "John Doe",
        "email": "joao@example.com"
    }

    # Act
    response = await http_client.post("/users", json=payload)

    # Assert - Presence of the timestamp
    json_response = response.json()
    assert "created_at" in json_response

    # Assert - Valid ISO 8601 format
    from datetime import datetime
    timestamp = json_response["created_at"]
    # Remove 'Z' and try parsing
    datetime.fromisoformat(timestamp.replace("Z", "+00:00"))

    # If it reaches here, the format is valid
    assert isinstance(timestamp, str)

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 2: Use ANY in Mocks

```python
async def test_create_user_calls_db_with_timestamp(http_client: AsyncClient):
    """Tests that creation calls DB with a timestamp."""
    # Arrange
    mock_db = MagicMock()
    mock_db.create.return_value = {"id": "user123"}
    app.dependency_overrides[get_database] = lambda: mock_db

    payload = {
        "name": "John Doe",
        "email": "joao@example.com"
    }

    # Act
    response = await http_client.post("/users", json=payload)

    # Assert - Mock called with ANY for timestamp
    from unittest.mock import ANY
    mock_db.create.assert_called_once_with("users", {
        "name": "John Doe",
        "email": "joao@example.com",
        "created_at": ANY  # dynamic timestamp
    })

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 3: Validate Multiple Timestamps

```python
async def test_update_user_updates_timestamp(http_client: AsyncClient):
    """Tests that update modifies the timestamp."""
    # Arrange
    mock_db = MagicMock()
    mock_db.retrieve.return_value = {
        "id": "user123",
        "name": "John",
        "created_at": "2024-01-01T00:00:00Z"
    }
    mock_db.update.return_value = None
    app.dependency_overrides[get_database] = lambda: mock_db

    payload = {"name": "John Doe"}

    # Act
    response = await http_client.put("/users/user123", json=payload)

    # Assert - Response contains both timestamps
    json_response = response.json()
    assert "created_at" in json_response
    assert "updated_at" in json_response

    # Assert - created_at did not change
    assert json_response["created_at"] == "2024-01-01T00:00:00Z"

    # Assert - updated_at is present and valid
    from datetime import datetime
    datetime.fromisoformat(
        json_response["updated_at"].replace("Z", "+00:00")
    )

    # Assert - Mock called with updated_at
    from unittest.mock import ANY
    mock_db.update.assert_called_once_with("users", "user123", {
        "name": "John Doe",
        "updated_at": ANY
    })

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 4: Relative Timestamp (Recent)

```python
async def test_created_timestamp_is_recent(http_client: AsyncClient):
    """Tests that the creation timestamp is recent."""
    # Arrange
    from datetime import datetime, timezone, timedelta

    mock_db = MagicMock()
    mock_db.create.return_value = {"id": "user123"}
    app.dependency_overrides[get_database] = lambda: mock_db

    payload = {"name": "John", "email": "joao@example.com"}

    # Capture time before creation
    time_before = datetime.now(timezone.utc)

    # Act
    response = await http_client.post("/users", json=payload)

    # Capture time after creation
    time_after = datetime.now(timezone.utc)

    # Assert - Timestamp is between before and after
    json_response = response.json()
    created_at = datetime.fromisoformat(
        json_response["created_at"].replace("Z", "+00:00")
    )

    assert time_before <= created_at <= time_after

    # Assert - Timestamp is recent (last 5 seconds)
    assert (time_after - created_at) < timedelta(seconds=5)

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 5: Validate Timestamp Order

```python
async def test_updated_at_after_created_at(http_client: AsyncClient):
    """Tests that updated_at is later than created_at."""
    # Arrange
    from datetime import datetime
    import time

    mock_db = MagicMock()
    mock_db.retrieve.return_value = {
        "id": "item123",
        "name": "Item",
        "created_at": "2024-01-01T00:00:00Z"
    }
    mock_db.update.return_value = None
    app.dependency_overrides[get_database] = lambda: mock_db

    # Wait 1 second to ensure different timestamps
    time.sleep(1)

    # Act
    response = await http_client.put(
        "/items/item123",
        json={"name": "Item Updated"}
    )

    # Assert
    json_response = response.json()
    created_at = datetime.fromisoformat(
        json_response["created_at"].replace("Z", "+00:00")
    )
    updated_at = datetime.fromisoformat(
        json_response["updated_at"].replace("Z", "+00:00")
    )

    # updated_at must be later than created_at
    assert updated_at > created_at

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 6: Date Format (Without Time)

```python
async def test_user_birthday_date_format(http_client: AsyncClient):
    """Tests date format (without timestamp)."""
    # Arrange
    mock_db = MagicMock()
    mock_db.retrieve.return_value = {
        "id": "user123",
        "name": "John",
        "birthday": "1990-05-15"  # only date
    }
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.get("/users/user123")

    # Assert - Date format YYYY-MM-DD
    json_response = response.json()
    assert "birthday" in json_response

    # Validate format
    from datetime import date
    birthday_str = json_response["birthday"]
    birthday = date.fromisoformat(birthday_str)

    # Validate it is of type date
    assert isinstance(birthday, date)
    assert birthday.year == 1990
    assert birthday.month == 5
    assert birthday.day == 15

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 7: Timezone Awareness

```python
async def test_timestamp_includes_timezone(http_client: AsyncClient):
    """Tests that timestamp includes timezone information."""
    # Arrange
    mock_db = MagicMock()
    mock_db.create.return_value = {"id": "event123"}
    app.dependency_overrides[get_database] = lambda: mock_db

    payload = {"name": "Event", "date": "2024-06-01"}

    # Act
    response = await http_client.post("/events", json=payload)

    # Assert - Timestamp with timezone
    json_response = response.json()
    timestamp = json_response["created_at"]

    # Must end with Z or have +00:00
    assert timestamp.endswith("Z") or "+00:00" in timestamp

    # Parse with timezone
    from datetime import datetime
    dt = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))

    # Must have timezone info
    assert dt.tzinfo is not None

    # Cleanup
    app.dependency_overrides.clear()
```

---

## Common Formats

| Type | Format | Example | How to Validate |
|------|---------|---------|--------------|
| ISO 8601 with Z | `YYYY-MM-DDTHH:MM:SSZ` | `2024-01-15T10:30:00Z` | `datetime.fromisoformat(s.replace("Z", "+00:00"))` |
| ISO 8601 with TZ | `YYYY-MM-DDTHH:MM:SS+00:00` | `2024-01-15T10:30:00+00:00` | `datetime.fromisoformat(s)` |
| Date only | `YYYY-MM-DD` | `2024-01-15` | `date.fromisoformat(s)` |
| Unix timestamp | `1234567890` | `1705318200` | `datetime.fromtimestamp(t)` |

---

## Checklist

When validating timestamps:

- [ ] ✅ Verify presence of the timestamp field
- [ ] ✅ Validate ISO 8601 format with `datetime.fromisoformat()`
- [ ] ✅ Use `ANY` in mocks for dynamic timestamps
- [ ] ✅ Verify that timestamp includes timezone (Z or +00:00)
- [ ] ✅ For dates: use `date.fromisoformat()`
- [ ] ✅ Validate that `updated_at` > `created_at` when applicable
- [ ] ✅ Do not use hard-coded timestamps in assertions
- [ ] ✅ Optionally validate that the timestamp is recent
