# Validation Errors (422)

Validation of Pydantic validation errors (HTTP 422 Unprocessable Entity).

## Principle

Pydantic validation errors are captured by a custom exception handler that returns the API's standardized response with the `message` field. Validate the `message` field and the 422 status code.

---

## ✅ Correct Pattern

```python
# Validate Pydantic validation error
json_response = response.json()
assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY
assert "message" in json_response  # API uses standardized "message"
assert json_response["message"]  # non-empty message

# Validate specific message when relevant
assert "required" in json_response["message"]  # required field
assert "invalid" in json_response["message"]  # format/invalid type

# Validate internationalized message
assert "field 'email' is required" in json_response["message"]  # en-US
assert "campo 'email' é obrigatório" in json_response["message"]  # pt-BR
```

---

## ❌ Anti-Pattern

```python
# BAD: Only check status
assert response.status_code == 422
# does not validate the error message

# BAD: Use raw Pydantic field
assert "detail" in response.json()  # API uses "message", not "detail"

# BAD: Do not validate message
assert "message" in response.json()
# does not check the content of the message
```

**Problems:**
- Does not validate the returned error message
- Uses incorrect structure (detail vs message)
- May pass with incorrect error or generic message

---

## Usage in Tests

### Example 1: Missing Required Field

```python
async def test_create_user_missing_required_field(http_client: AsyncClient):
    """Tests error when required field is missing."""
    # Arrange
    payload = {
        "email": "joao@example.com"
        # missing "name" which is required
    }

    # Act
    response = await http_client.post("/users", json=payload)

    # Assert - Status 422
    assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY

    # Assert - Error message
    json_response = response.json()
    assert "message" in json_response
    assert "required" in json_response["message"]
    assert "name" in json_response["message"]
```

### Example 2: Invalid Data Type

```python
async def test_create_product_invalid_price_type(http_client: AsyncClient):
    """Tests error when data type is invalid."""
    # Arrange
    payload = {
        "name": "Product",
        "price": "invalid"  # expected: float
    }

    # Act
    response = await http_client.post("/products", json=payload)

    # Assert - Status 422
    assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY

    # Assert - Error message
    json_response = response.json()
    assert "message" in json_response
    assert json_response["message"]  # non-empty message
```

### Example 3: Invalid Format (Email)

```python
async def test_create_user_invalid_email_format(http_client: AsyncClient):
    """Tests error when email format is invalid."""
    # Arrange
    payload = {
        "name": "John Doe",
        "email": "not-an-email"  # invalid format
    }

    # Act
    response = await http_client.post("/users", json=payload)

    # Assert - Status 422
    assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY

    # Assert - Error message
    json_response = response.json()
    assert "message" in json_response
    assert json_response["message"]  # non-empty message
```

### Example 4: Multiple Validation Errors

```python
async def test_create_user_multiple_validation_errors(
    http_client: AsyncClient
):
    """Tests multiple validation errors simultaneously."""
    # Arrange
    payload = {
        # missing "name"
        "email": "invalid-email",  # invalid format
        "age": "not-a-number"  # invalid type
    }

    # Act
    response = await http_client.post("/users", json=payload)

    # Assert - Status 422
    assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY

    # Assert - Error message
    # Note: The handler returns only the first error found
    json_response = response.json()
    assert "message" in json_response
    assert json_response["message"]  # non-empty message
```

### Example 5: Validation of Range

```python
async def test_create_product_price_out_of_range(http_client: AsyncClient):
    """Tests error when value is out of the allowed range."""
    # Arrange
    payload = {
        "name": "Product",
        "price": -10.0  # negative price not allowed
    }

    # Act
    response = await http_client.post("/products", json=payload)

    # Assert - Status 422
    assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY

    # Assert - Error message
    json_response = response.json()
    assert "message" in json_response
    assert json_response["message"]  # non-empty message
```

### Example 6: Parameterized Validation Tests

```python
@pytest.mark.parametrize("field,value,expected_msg", [
    ("email", "invalid", ""),  # any message
    ("age", -1, ""),
    ("name", "", "required"),
    ("phone", "123", "")
], ids=["invalid-email", "negative-age", "empty-name", "short-phone"])
async def test_user_field_validations(
    http_client: AsyncClient,
    field: str,
    value: any,
    expected_msg: str
):
    """Tests specific field validations."""
    # Arrange
    payload = {
        "name": "John Doe",
        "email": "joao@example.com",
        "age": 25,
        "phone": "11999999999"
    }
    payload[field] = value  # replace with invalid value

    # Act
    response = await http_client.post("/users", json=payload)

    # Assert - Status 422
    assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY

    # Assert - Error message
    json_response = response.json()
    assert "message" in json_response
    if expected_msg:
        assert expected_msg in json_response["message"]
```

### Example 7: Empty List Not Allowed

```python
async def test_create_order_empty_items_list(http_client: AsyncClient):
    """Tests error when items list is empty."""
    # Arrange
    payload = {
        "customer_id": "user123",
        "items": []  # empty list not allowed
    }

    # Act
    response = await http_client.post("/orders", json=payload)

    # Assert - Status 422
    assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY

    # Assert - Error message
    json_response = response.json()
    assert "message" in json_response
    assert json_response["message"]  # non-empty message
```

---

## API Response Structure

The API uses a custom exception handler that transforms Pydantic validation errors into a standardized format:

```json
{
  "message": "The field 'email' is required."
}
```

or

```json
{
  "message": "Invalid quantity."
}
```

### Handler Behavior

- Captures the first validation error found
- For required fields (`missing`), returns an internationalized message: `"The field '{field}' is required."`
- For other error types, extracts and formats the original Pydantic message
- In case of processing error, returns a generic message: `"A validation error occurred with the input data. Please check the data and try again."`
- Always returns status code `422 UNPROCESSABLE ENTITY`

### Message Examples

| Situation | Message (en-US) |
|----------|------------------|
| Required field | `The field 'name' is required.` |
| Custom validation | `Invalid quantity.` |
| Generic error | `A validation error occurred with the input data. Please check the data and try again.` |

---

## Checklist

When testing validation errors (422):

- [ ] ✅ Use status `HTTP_422_UNPROCESSABLE_ENTITY` or `422`
- [ ] ✅ Validate presence of the `message` field (not `detail`)
- [ ] ✅ Verify that the message is not empty
- [ ] ✅ Validate message content when specific (e.g., "required", "invalid")
- [ ] ✅ Consider internationalization (default pt-BR, en-US with header)
- [ ] ✅ Use parameterized tests for multiple validations
- [ ] ✅ Remember that the handler returns only the first error found
- [ ] ✅ Avoid relying on the raw Pydantic `detail` structure
