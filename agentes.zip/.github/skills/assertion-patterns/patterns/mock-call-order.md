# Mock Call Order

Validation of mock call order when the sequence matters.

## Principle

Use `assert_has_calls()` to validate call order when the sequence of operations matters to business logic.

---

## ✅ Correct Pattern

```python
from unittest.mock import call

# Validate specific order
expected_calls = [
    call.collection("users"),
    call.collection().document("user123"),
    call.collection().document().get()
]
mock_db.assert_has_calls(expected_calls, any_order=False)

# Allow any order
mock_db.assert_has_calls(expected_calls, any_order=True)
```

---

## ❌ Anti-Pattern

```python
# BAD: Does not validate order when it matters
mock_db.create.assert_called()
mock_db.retrieve.assert_called()
# Order is not checked

# BAD: Multiple assertions without validating sequence
assert mock_db.create.call_count == 1
assert mock_db.update.call_count == 1
# Does not guarantee create was called before update
```

**Problems:**
- Does not detect out-of-order calls
- May pass even if the logic executed in the wrong order
- Does not validate dependencies between operations

---

## Usage in Tests

### Example 1: Specific Operation Order

```python
async def test_update_user_calls_in_correct_order(http_client: AsyncClient):
    """Tests that update calls retrieve before update."""
    # Arrange
    mock_db = MagicMock()
    mock_db.retrieve.return_value = {"id": "user123", "name": "John"}
    mock_db.update.return_value = None
    app.dependency_overrides[get_database] = lambda: mock_db

    payload = {"name": "John Doe"}

    # Act
    response = await http_client.put("/users/user123", json=payload)

    # Assert - Validate call order
    from unittest.mock import call, ANY
    expected_calls = [
        call.retrieve("users", "user123"),
        call.update("users", "user123", {
            "name": "John Doe",
            "updated_at": ANY
        })
    ]
    mock_db.assert_has_calls(expected_calls, any_order=False)

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 2: Validation Sequence

```python
async def test_create_order_validates_before_creating(
    http_client: AsyncClient
):
    """Tests that validations happen before creation."""
    # Arrange
    mock_db = MagicMock()
    mock_db.retrieve.return_value = {"id": "user123"}  # user exists
    mock_db.retrieve.side_effect = [
        {"id": "user123"},  # first call: user
        {"id": "prod1", "stock": 10}  # second call: product
    ]
    mock_db.create.return_value = {"id": "order123"}
    app.dependency_overrides[get_database] = lambda: mock_db

    payload = {
        "customer_id": "user123",
        "product_id": "prod1",
        "quantity": 2
    }

    # Act
    response = await http_client.post("/orders", json=payload)

    # Assert - Order: validate user -> validate product -> create order
    from unittest.mock import call, ANY
    expected_calls = [
        call.retrieve("users", "user123"),
        call.retrieve("products", "prod1"),
        call.create("orders", ANY)
    ]
    mock_db.assert_has_calls(expected_calls, any_order=False)

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 3: Transaction with Rollback

```python
async def test_transaction_rollback_on_error(http_client: AsyncClient):
    """Tests that a transaction rolls back on error."""
    # Arrange
    mock_db = MagicMock()
    mock_transaction = MagicMock()
    mock_db.transaction.return_value = mock_transaction

    # Simulate error after begin
    mock_transaction.begin.return_value = None
    mock_transaction.set.side_effect = Exception("Database error")
    mock_transaction.rollback.return_value = None

    app.dependency_overrides[get_database] = lambda: mock_db

    payload = {"name": "Test"}

    # Act
    response = await http_client.post("/items", json=payload)

    # Assert - Order: begin -> set (error) -> rollback
    from unittest.mock import call
    expected_calls = [
        call.transaction(),
        call.transaction().begin(),
        call.transaction().set(call.ANY, call.ANY),
        call.transaction().rollback()
    ]
    mock_db.assert_has_calls(expected_calls, any_order=False)

    # Assert - Commit was not called
    mock_transaction.commit.assert_not_called()

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 4: Processing Pipeline

```python
async def test_process_payment_pipeline_order(http_client: AsyncClient):
    """Tests payment pipeline order."""
    # Arrange
    mock_payment = MagicMock()
    mock_payment.validate_card.return_value = True
    mock_payment.charge.return_value = {"id": "charge123"}
    mock_payment.send_receipt.return_value = None

    app.dependency_overrides[get_payment_engine] = lambda: mock_payment

    payload = {
        "card": "4242424242424242",
        "amount": 99.90
    }

    # Act
    response = await http_client.post("/payments", json=payload)

    # Assert - Pipeline: validate -> charge -> send receipt
    from unittest.mock import call, ANY
    expected_calls = [
        call.validate_card("4242424242424242"),
        call.charge(amount=99.90, card=ANY),
        call.send_receipt(charge_id="charge123")
    ]
    mock_payment.assert_has_calls(expected_calls, any_order=False)

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 5: Batch Operations with Order

```python
async def test_bulk_update_processes_in_order(http_client: AsyncClient):
    """Tests that bulk updates are processed in order."""
    # Arrange
    mock_db = MagicMock()
    mock_db.update.return_value = None
    app.dependency_overrides[get_database] = lambda: mock_db

    payload = {
        "updates": [
            {"id": "item1", "status": "active"},
            {"id": "item2", "status": "inactive"},
            {"id": "item3", "status": "pending"}
        ]
    }

    # Act
    response = await http_client.post("/items/bulk-update", json=payload)

    # Assert - Update order
    from unittest.mock import call, ANY
    expected_calls = [
        call.update("items", "item1", {"status": "active", "updated_at": ANY}),
        call.update("items", "item2", {"status": "inactive", "updated_at": ANY}),
        call.update("items", "item3", {"status": "pending", "updated_at": ANY})
    ]
    mock_db.assert_has_calls(expected_calls, any_order=False)

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 6: Any Order Acceptable

```python
async def test_create_with_associations_any_order(http_client: AsyncClient):
    """Tests creation with associations where order does not matter."""
    # Arrange
    mock_db = MagicMock()
    mock_db.create.return_value = {"id": "entity123"}
    app.dependency_overrides[get_database] = lambda: mock_db

    payload = {
        "name": "Entity",
        "tags": ["tag1", "tag2"]
    }

    # Act
    response = await http_client.post("/entities", json=payload)

    # Assert - Calls may occur in any order
    from unittest.mock import call, ANY
    expected_calls = [
        call.create("entities", ANY),
        call.create("tags", ANY),
        call.create("tags", ANY)
    ]
    mock_db.assert_has_calls(expected_calls, any_order=True)

    # Cleanup
    app.dependency_overrides.clear()
```

---

## When to Validate Order

### Situations Requiring Order

- ✅ **Pre-insert validation**: Check existence before inserting
- ✅ **Transactions**: Begin → operations → commit/rollback
- ✅ **Pipelines**: Sequential processing stages
- ✅ **Dependencies**: Operation B depends on the result of A
- ✅ **Dependent updates**: Update after retrieve
- ✅ **Audit logs**: Record actions in sequence

### Situations Allowing Any Order

- ✅ **Independent operations**: Creating multiple unrelated records
- ✅ **Associations**: Creating bidirectional relations
- ✅ **Notifications**: Sending multiple notifications
- ✅ **Cache warming**: Preloading caches

---

## assert_has_calls Parameters

```python
mock.assert_has_calls(calls_list, any_order=False)
```

| Parameter | Value | Behavior |
|-----------|-------|---------------|
| `any_order` | `False` (default) | Calls must occur exactly in the specified order |
| `any_order` | `True` | Calls may occur in any order |

---

## Checklist

When validating call order:

- [ ] ✅ Identify whether order matters for business logic
- [ ] ✅ Use `assert_has_calls()` with `any_order=False` when order is critical
- [ ] ✅ Use `any_order=True` when order does not matter
- [ ] ✅ Include all relevant calls in the expected list
- [ ] ✅ Use `call()` to construct expected calls
- [ ] ✅ Combine with argument validations when needed
- [ ] ✅ Validate that dependent operations occur in sequence
- [ ] ✅ Verify that rollbacks occur after errors
