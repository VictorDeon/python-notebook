# Status Code Assertions

Validation of HTTP status codes using FastAPI constants.

## Principle

Always use constants from the `fastapi.status` module instead of magic numbers for better readability and maintainability.

---

## ✅ Correct Pattern

```python
from fastapi import status

# Success responses
assert response.status_code == status.HTTP_200_OK
assert response.status_code == status.HTTP_201_CREATED
assert response.status_code == status.HTTP_204_NO_CONTENT

# Client errors
assert response.status_code == status.HTTP_400_BAD_REQUEST
assert response.status_code == status.HTTP_401_UNAUTHORIZED
assert response.status_code == status.HTTP_403_FORBIDDEN
assert response.status_code == status.HTTP_404_NOT_FOUND
assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY

# Server errors
assert response.status_code == status.HTTP_500_INTERNAL_SERVER_ERROR
```

---

## ❌ Anti-Pattern

```python
# BAD: Magic numbers
assert response.status_code == 200
assert response.status_code == 201
assert response.status_code == 404
assert response.status_code == 422
```

**Problems:**
- Less readable
- Harder to maintain
- Doesn't follow FastAPI convention

---

## Usage in Tests

```python
async def test_get_user_success(http_client: AsyncClient):
    """Tests successful user retrieval."""
    # Arrange
    mock_db = MagicMock()
    mock_db.retrieve.return_value = {"id": "user123", "name": "John"}
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.get("/users/user123")

    # Assert
    assert response.status_code == status.HTTP_200_OK

    # Cleanup
    app.dependency_overrides.clear()


async def test_get_user_not_found(http_client: AsyncClient):
    """Tests error when user doesn't exist."""
    # Arrange
    mock_db = MagicMock()
    mock_db.retrieve.return_value = None
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.get("/users/nonexistent")

    # Assert
    assert response.status_code == status.HTTP_404_NOT_FOUND

    # Cleanup
    app.dependency_overrides.clear()
```

---

## Common Codes

| Constant | Value | Usage |
|-----------|-------|-----|
| `HTTP_200_OK` | 200 | Successful request (GET, PUT, PATCH) |
| `HTTP_201_CREATED` | 201 | Resource created successfully (POST) |
| `HTTP_204_NO_CONTENT` | 204 | Successful operation without content (DELETE) |
| `HTTP_400_BAD_REQUEST` | 400 | Invalid request |
| `HTTP_401_UNAUTHORIZED` | 401 | Not authenticated |
| `HTTP_403_FORBIDDEN` | 403 | Not authorized |
| `HTTP_404_NOT_FOUND` | 404 | Resource not found |
| `HTTP_422_UNPROCESSABLE_ENTITY` | 422 | Pydantic validation error |
| `HTTP_500_INTERNAL_SERVER_ERROR` | 500 | Internal server error |
