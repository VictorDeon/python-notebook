# Response Body Structure

Validation of the HTTP response body structure.

## Principle

Always validate the complete structure of the response body, ensuring the presence of all expected keys and their specific values.

---

## ✅ Correct Pattern

```python
# Validate complete structure
json_response = response.json()
assert json_response["id"] == "user123"
assert json_response["name"] == "John Doe"
assert len(json_response["items"]) == 3
assert "created_at" in json_response

# Validate nested object
assert json_response["user"]["id"] == "user123"
assert json_response["user"]["profile"]["name"] == "John"
assert "email" in json_response["user"]

# Validate list of objects
assert len(json_response["items"]) == 3
assert json_response["items"][0]["id"] == "item1"
assert json_response["items"][0]["name"] == "Item 1"
```

---

## ❌ Anti-Pattern

```python
# BAD: Vague assertion - does not validate structure
assert response.json()

# BAD: Too generic
assert len(json_response) > 0

# BAD: Does not validate anything specific
assert json_response

# BAD: Only checks existence, not value
assert "name" in json_response
```

**Problems:**
- Does not ensure the structure is correct
- Does not validate specific values
- Tests may pass even with incorrect data

---

## Usage in Tests

### Example 1: Simple Response

```python
async def test_create_user_success(http_client: AsyncClient):
    """Tests user creation with complete response validation."""
    # Arrange
    mock_db = MagicMock()
    mock_db.create.return_value = {"id": "user123"}
    app.dependency_overrides[get_database] = lambda: mock_db

    payload = {"name": "John Doe", "email": "joao@example.com"}

    # Act
    response = await http_client.post("/users", json=payload)

    # Assert - Complete structure
    json_response = response.json()
    assert "id" in json_response
    assert "name" in json_response
    assert "email" in json_response
    assert "created_at" in json_response

    # Assert - Specific values
    assert json_response["id"] == "user123"
    assert json_response["name"] == "John Doe"
    assert json_response["email"] == "joao@example.com"

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 2: Response with Nested Object

```python
async def test_get_user_profile(http_client: AsyncClient):
    """Tests retrieval of profile with nested data."""
    # Arrange
    mock_db = MagicMock()
    mock_db.retrieve.return_value = {
        "id": "user123",
        "name": "John Doe",
        "profile": {
            "bio": "Developer",
            "avatar": "https://example.com/avatar.jpg"
        }
    }
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.get("/users/user123/profile")

    # Assert - Root level structure
    json_response = response.json()
    assert "id" in json_response
    assert "name" in json_response
    assert "profile" in json_response

    # Assert - Nested structure
    assert "bio" in json_response["profile"]
    assert "avatar" in json_response["profile"]

    # Assert - Specific values
    assert json_response["id"] == "user123"
    assert json_response["profile"]["bio"] == "Developer"

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 3: Response with List

```python
async def test_list_users(http_client: AsyncClient):
    """Tests listing users."""
    # Arrange
    mock_db = MagicMock()
    mock_db.query.return_value = [
        {"id": "user1", "name": "John"},
        {"id": "user2", "name": "Mary"}
    ]
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.get("/users")

    # Assert - List structure
    json_response = response.json()
    assert "items" in json_response
    assert isinstance(json_response["items"], list)
    assert len(json_response["items"]) == 2

    # Assert - Item structure
    assert "id" in json_response["items"][0]
    assert "name" in json_response["items"][0]

    # Assert - Specific values
    assert json_response["items"][0]["id"] == "user1"
    assert json_response["items"][1]["name"] == "Mary"

    # Cleanup
    app.dependency_overrides.clear()
```

---

## Checklist

When validating the response body structure:

- [ ] ✅ Verify the presence of all expected keys
- [ ] ✅ Validate specific values, not just existence
- [ ] ✅ Check nested structures when applicable
- [ ] ✅ Validate the size of lists/arrays
- [ ] ✅ Verify the structure of items in lists
- [ ] ✅ Use specific assertions, not generic ones
