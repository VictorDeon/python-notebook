# Lists and Collections

Validation of lists and collections in API responses.

## Principle

Always validate the length, structure, and contents of lists — not just their presence.

---

### Correct Pattern

```python
# Validate list length
json_response = response.json()
assert len(json_response["items"]) == 3

# Validate first item
assert json_response["items"][0]["id"] == "item1"
assert json_response["items"][0]["name"] == "Item 1"

# Validate all items have expected fields
assert all("name" in item for item in json_response["items"])
assert all(isinstance(item["id"], str) for item in json_response["items"])

# Validate empty list case
assert json_response["items"] == []
assert len(json_response["items"]) == 0
```

---

### Anti-Pattern

```python
# BAD: Does not validate the contents of the list
assert json_response["items"]  # may be empty

# BAD: Too generic
assert len(json_response["items"]) > 0  # doesn't validate contents

# BAD: Does not validate structure of items
assert "items" in json_response  # doesn't check what's inside
```

Problems:
- Does not guarantee the list contains correct data
- May pass with an empty list when items are expected
- Does not validate the structure of objects inside the list

---

## Usage in Tests

### Example 1: Expected List Size

```python
async def test_list_users_returns_correct_count(http_client: AsyncClient):
    """Tests that listing returns the correct number of users."""
    # Arrange
    mock_db = MagicMock()
    mock_db.query.return_value = [
        {"id": "user1", "name": "John"},
        {"id": "user2", "name": "Mary"},
        {"id": "user3", "name": "Peter"}
    ]
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.get("/users")

    # Assert - List length
    json_response = response.json()
    assert "items" in json_response
    assert isinstance(json_response["items"], list)
    assert len(json_response["items"]) == 3

    # Assert - Item structure
    for item in json_response["items"]:
        assert "id" in item
        assert "name" in item
        assert isinstance(item["id"], str)
        assert isinstance(item["name"], str)

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 2: Empty List

```python
async def test_list_users_empty_result(http_client: AsyncClient):
    """Tests that listing returns an empty list when there is no data."""
    # Arrange
    mock_db = MagicMock()
    mock_db.query.return_value = []
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.get("/users")

    # Assert - Empty list
    json_response = response.json()
    assert response.status_code == status.HTTP_200_OK
    assert "items" in json_response
    assert json_response["items"] == []
    assert len(json_response["items"]) == 0

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 3: Validate Specific Items

```python
async def test_list_products_validates_each_item(http_client: AsyncClient):
    """Tests that each item in the list has the correct structure."""
    # Arrange
    mock_db = MagicMock()
    mock_db.query.return_value = [
        {"id": "prod1", "name": "Product A", "price": 99.90, "active": True},
        {"id": "prod2", "name": "Product B", "price": 149.90, "active": False}
    ]
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.get("/products")

    # Assert - List
    json_response = response.json()
    items = json_response["items"]
    assert len(items) == 2

    # Assert - First item
    assert items[0]["id"] == "prod1"
    assert items[0]["name"] == "Product A"
    assert items[0]["price"] == 99.90
    assert items[0]["active"] is True

    # Assert - Second item
    assert items[1]["id"] == "prod2"
    assert items[1]["name"] == "Product B"
    assert items[1]["price"] == 149.90
    assert items[1]["active"] is False

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 4: Validate All Items with all()

```python
async def test_list_items_all_have_required_fields(http_client: AsyncClient):
    """Tests that all items have the required fields."""
    # Arrange
    mock_db = MagicMock()
    mock_db.query.return_value = [
        {"id": "item1", "name": "Item 1", "status": "active"},
        {"id": "item2", "name": "Item 2", "status": "inactive"},
        {"id": "item3", "name": "Item 3", "status": "pending"}
    ]
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.get("/items")

    # Assert - All items have required fields
    json_response = response.json()
    items = json_response["items"]

    assert all("id" in item for item in items)
    assert all("name" in item for item in items)
    assert all("status" in item for item in items)

    # Assert - All IDs are strings
    assert all(isinstance(item["id"], str) for item in items)

    # Assert - All statuses are valid
    valid_statuses = ["active", "inactive", "pending"]
    assert all(item["status"] in valid_statuses for item in items)

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 5: List with Nested Items

```python
async def test_list_orders_with_nested_items(http_client: AsyncClient):
    """Tests listing orders with nested items."""
    # Arrange
    mock_db = MagicMock()
    mock_db.query.return_value = [
        {
            "id": "order1",
            "customer": {"id": "user1", "name": "John"},
            "items": [
                {"product_id": "prod1", "quantity": 2},
                {"product_id": "prod2", "quantity": 1}
            ]
        },
        {
            "id": "order2",
            "customer": {"id": "user2", "name": "Mary"},
            "items": [
                {"product_id": "prod3", "quantity": 5}
            ]
        }
    ]
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.get("/orders")

    # Assert - Root list
    json_response = response.json()
    orders = json_response["items"]
    assert len(orders) == 2

    # Assert - First order and nested items
    order1 = orders[0]
    assert order1["id"] == "order1"
    assert len(order1["items"]) == 2
    assert order1["items"][0]["product_id"] == "prod1"
    assert order1["items"][0]["quantity"] == 2

    # Assert - Second order
    order2 = orders[1]
    assert len(order2["items"]) == 1
    assert order2["items"][0]["quantity"] == 5

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 6: Filtered List

```python
async def test_list_users_filtered_by_status(http_client: AsyncClient):
    """Tests that filtered listing returns only matching items."""
    # Arrange
    mock_db = MagicMock()
    mock_db.query.return_value = [
        {"id": "user1", "name": "John", "status": "active"},
        {"id": "user2", "name": "Mary", "status": "active"}
    ]
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.get("/users?status=active")

    # Assert - All items have status "active"
    json_response = response.json()
    items = json_response["items"]
    assert len(items) == 2
    assert all(item["status"] == "active" for item in items)

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 7: Ordered List

```python
async def test_list_products_ordered_by_price(http_client: AsyncClient):
    """Tests that listing is ordered by price."""
    # Arrange
    mock_db = MagicMock()
    mock_db.query.return_value = [
        {"id": "prod1", "price": 10.0},
        {"id": "prod2", "price": 20.0},
        {"id": "prod3", "price": 30.0}
    ]
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.get("/products?sort=price")

    # Assert - Ordered list
    json_response = response.json()
    items = json_response["items"]
    prices = [item["price"] for item in items]
    assert prices == sorted(prices)  # checks that it's ordered
    assert prices == [10.0, 20.0, 30.0]

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 8: List with Specific Indices

```python
async def test_list_items_specific_indices(http_client: AsyncClient):
    """Tests specific items by index."""
    # Arrange
    mock_db = MagicMock()
    mock_db.query.return_value = [
        {"id": "item1", "position": 1},
        {"id": "item2", "position": 2},
        {"id": "item3", "position": 3}
    ]
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.get("/items")

    # Assert - Items at specific positions
    json_response = response.json()
    items = json_response["items"]

    # First item
    assert items[0]["id"] == "item1"
    assert items[0]["position"] == 1

    # Last item
    assert items[-1]["id"] == "item3"
    assert items[-1]["position"] == 3

    # Middle item
    assert items[1]["id"] == "item2"

    # Cleanup
    app.dependency_overrides.clear()
```

---

## Validation Strategies

### 1. Validate Length

```python
assert len(items) == expected_count
assert len(items) > 0
assert len(items) == 0  # empty list
```

### 2. Validate Structure

```python
# All items have the field
assert all("id" in item for item in items)

# All items have the correct type
assert all(isinstance(item["price"], float) for item in items)
```

### 3. Validate Specific Items

```python
# First item
assert items[0]["id"] == "expected"

# Last item
assert items[-1]["status"] == "complete"

# Specific index
assert items[2]["name"] == "Item 3"
```

### 4. Validate Order

```python
# Ordered list
values = [item["value"] for item in items]
assert values == sorted(values)

# Reverse order
assert values == sorted(values, reverse=True)
```

---

## Checklist

### When validating lists:

- [ ] ✅ Verify that the field is of type `list`
- [ ] ✅ Validate list length (`len()`)
- [ ] ✅ Validate empty list when expected (`== []`)
- [ ] ✅ Validate the structure of each item
- [ ] ✅ Validate specific items by index
- [ ] ✅ Use `all()` for validations across all items
- [ ] ✅ Validate item data types
- [ ] ✅ Validate ordering when relevant
- [ ] ✅ Validate nested items when applicable
