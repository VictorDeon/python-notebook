# Optional Fields

Validation of optional fields in responses.

## Principle

Validate that optional fields can be absent or `None`, and handle both cases appropriately.

---

## ✅ Correct Pattern

```python
# Validate optional field present
json_response = response.json()
if "optional_field" in json_response:
    assert json_response["optional_field"] == "expected_value"
else:
    assert True  # optional field absent is valid

# Validate optional field with None
assert json_response.get("optional_field") is None

# Use get() with default
value = json_response.get("optional_field", "default")
assert value in ["expected_value", "default"]
```

---

## ❌ Anti-Pattern

```python
# BAD: Assume optional field exists
assert json_response["optional_field"] == "value"  # may not exist

# BAD: Not handling None
assert json_response["optional_field"]  # None is falsy, assertion will fail
```

**Problems:**
- KeyError if field does not exist
- Assertion fails with None even if valid
- Does not test all possible scenarios

---

## Usage in Tests

### Example 1: Optional Field Present

```python
async def test_get_user_with_bio(http_client: AsyncClient):
    """Tests user with bio filled."""
    # Arrange
    mock_db = MagicMock()
    mock_db.retrieve.return_value = {
        "id": "user123",
        "name": "John Doe",
        "bio": "Python Developer"  # optional field present
    }
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.get("/users/user123")

    # Assert - Optional field is present
    json_response = response.json()
    assert "bio" in json_response
    assert json_response["bio"] == "Python Developer"
    assert isinstance(json_response["bio"], str)

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 2: Optional Field Absent

```python
async def test_get_user_without_bio(http_client: AsyncClient):
    """Tests user without bio (optional field absent)."""
    # Arrange
    mock_db = MagicMock()
    mock_db.retrieve.return_value = {
        "id": "user123",
        "name": "John Doe"
        # bio is not present
    }
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.get("/users/user123")

    # Assert - Optional field absent
    json_response = response.json()

    # Option 1: Verify it is not present
    assert "bio" not in json_response

    # Option 2: Use get() which returns None
    assert json_response.get("bio") is None

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 3: Optional Field Explicitly None

```python
async def test_get_user_with_null_bio(http_client: AsyncClient):
    """Tests user with bio explicitly None."""
    # Arrange
    mock_db = MagicMock()
    mock_db.retrieve.return_value = {
        "id": "user123",
        "name": "John Doe",
        "bio": None  # explicitly None
    }
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.get("/users/user123")

    # Assert - Field present but None
    json_response = response.json()
    assert "bio" in json_response
    assert json_response["bio"] is None

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 4: Validate Both Cases

```python
@pytest.mark.parametrize("bio,bio_present", [
    ("Python Developer", True),
    (None, True),
    (None, False)  # not included in response
], ids=["bio-present", "bio-none", "bio-absent"])
async def test_get_user_bio_scenarios(
    http_client: AsyncClient,
    bio: str,
    bio_present: bool
):
    """Tests all scenarios of optional field."""
    # Arrange
    mock_db = MagicMock()
    user_data = {"id": "user123", "name": "John Doe"}

    if bio_present:
        user_data["bio"] = bio

    mock_db.retrieve.return_value = user_data
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.get("/users/user123")

    # Assert
    json_response = response.json()

    if bio_present:
        assert "bio" in json_response
        if bio is None:
            assert json_response["bio"] is None
        else:
            assert json_response["bio"] == bio
    else:
        # Field is not present or is None
        bio_value = json_response.get("bio")
        assert bio_value is None or "bio" not in json_response

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 5: Multiple Optional Fields

```python
async def test_create_product_with_optional_fields(
    http_client: AsyncClient
):
    """Tests creation of product with optional fields."""
    # Arrange
    mock_db = MagicMock()
    mock_db.create.return_value = {"id": "prod123"}
    app.dependency_overrides[get_database] = lambda: mock_db

    payload = {
        "name": "Product",
        "price": 99.90,
        # Optional fields omitted:
        # "description": "...",
        # "image_url": "...",
        # "category": "..."
    }

    # Act
    response = await http_client.post("/products", json=payload)

    # Assert - Mandatory fields
    json_response = response.json()
    assert json_response["name"] == "Product"
    assert json_response["price"] == 99.90

    # Assert - Optional fields (absent or None)
    assert json_response.get("description") is None
    assert json_response.get("image_url") is None
    assert json_response.get("category") is None

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 6: Optional Field with Default

```python
async def test_create_item_with_default_optional_value(
    http_client: AsyncClient
):
    """Tests that optional field receives default value when omitted."""
    # Arrange
    mock_db = MagicMock()
    mock_db.create.return_value = {"id": "item123"}
    app.dependency_overrides[get_database] = lambda: mock_db

    payload = {
        "name": "Item"
        # "status" omitted (default: "pending")
    }

    # Act
    response = await http_client.post("/items", json=payload)

    # Assert - Optional field received default
    json_response = response.json()
    assert "status" in json_response
    assert json_response["status"] == "pending"  # default value

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 7: Partial Update (PATCH)

```python
async def test_partial_update_optional_fields(http_client: AsyncClient):
    """Tests partial update with optional fields."""
    # Arrange
    mock_db = MagicMock()
    mock_db.retrieve.return_value = {
        "id": "user123",
        "name": "John Doe",
        "email": "joao@example.com",
        "bio": "Developer",
        "phone": "11999999999"
    }
    mock_db.update.return_value = None
    app.dependency_overrides[get_database] = lambda: mock_db

    # Payload with only some fields
    payload = {
        "bio": "Python Developer"
        # Other fields not included
    }

    # Act
    response = await http_client.patch("/users/user123", json=payload)

    # Assert - Only bio was updated
    from unittest.mock import ANY
    mock_db.update.assert_called_once()

    # Verify that only bio is in the update
    call_args = mock_db.update.call_args[0][2]
    assert "bio" in call_args
    assert call_args["bio"] == "Python Developer"

    # Fields not included in the payload should not be updated
    assert "name" not in call_args or call_args["name"] == "John Doe"
    assert "email" not in call_args or call_args["email"] == "joao@example.com"

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 8: Optional List

```python
async def test_user_with_optional_tags_list(http_client: AsyncClient):
    """Tests user with optional list of tags."""
    # Arrange
    mock_db = MagicMock()
    mock_db.retrieve.return_value = {
        "id": "user123",
        "name": "John Doe",
        "tags": ["developer", "python"]  # optional list present
    }
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.get("/users/user123")

    # Assert - Optional list present
    json_response = response.json()
    if "tags" in json_response:
        assert isinstance(json_response["tags"], list)
        assert len(json_response["tags"]) == 2
        assert "developer" in json_response["tags"]

    # Cleanup
    app.dependency_overrides.clear()


async def test_user_without_optional_tags_list(http_client: AsyncClient):
    """Tests user without optional list of tags."""
    # Arrange
    mock_db = MagicMock()
    mock_db.retrieve.return_value = {
        "id": "user123",
        "name": "John Doe"
        # tags is not present
    }
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.get("/users/user123")

    # Assert - Optional list absent or None
    json_response = response.json()
    tags = json_response.get("tags")
    assert tags is None or tags == []

    # Cleanup
    app.dependency_overrides.clear()
```

---

## Validation Strategies

### 1. Verify Presence

```python
if "optional_field" in json_response:
    # field present - validate value
    assert json_response["optional_field"] == expected
else:
    # field absent - also valid
    pass
```

### 2. Use get() with Default

```python
value = json_response.get("optional_field", "default")
assert value in [expected_value, "default"]
```

### 3. Explicitly Check None

```python
assert json_response.get("optional_field") is None
# or
assert "optional_field" in json_response
assert json_response["optional_field"] is None
```

### 4. Parameterized Test

```python
@pytest.mark.parametrize("value,present", [
    ("value", True),
    (None, True),
    (None, False)
])
```

---

## Pydantic Optional Fields

In Pydantic, optional fields are defined as:

```python
from typing import Optional

class UserDTO(BaseModel):
    name: str  # mandatory
    bio: Optional[str] = None  # optional, default None
    tags: Optional[List[str]] = None  # optional list
```

---

## Checklist

When validating optional fields:

- [ ] ✅ Test scenario with field present
- [ ] ✅ Test scenario with field absent
- [ ] ✅ Test scenario with field explicitly None
- [ ] ✅ Use `get()` to access optional fields
- [ ] ✅ Use `is None` to compare with None (not `== None`)
- [ ] ✅ Do not assume field exists without checking
- [ ] ✅ Test default values when applicable
- [ ] ✅ Validate field type when present
