# Error Messages

Complete validation of error messages in responses.

## Principle

Always validate the full structure of error messages, including the message, error code (when applicable), and status code.

---

## ✅ Correct Pattern

```python
# Validate full error
json_response = response.json()
assert response.status_code == status.HTTP_400_BAD_REQUEST
assert json_response["message"] == "Email already registered"

# Validate i18n of the message
@pytest.mark.parametrize("language,expected_message", [
    ("pt-BR", "Email já cadastrado"),
    ("en-US", "Email already registered")
])
```

---

## ❌ Anti-Pattern

```python
# BAD: Only check status
assert response.status_code == 400
# does not validate the error message

# BAD: Incomplete validation
assert "message" in response.json()
# does not validate the message content

# BAD: Use the wrong field
assert "detail" in response.json()  # our standard uses "message"
```

**Problems:**
- Does not ensure the correct message was returned
- Does not validate the error structure
- May pass with an incorrect message

---

## Usage in Tests

### Example 1: Basic Business Error

```python
async def test_create_user_email_already_exists(http_client: AsyncClient):
    """Tests error when email is already registered."""
    # Arrange
    mock_db = MagicMock()
    mock_db.retrieve.return_value = {"id": "existing_user"}
    app.dependency_overrides[get_database] = lambda: mock_db

    payload = {
        "name": "John Doe",
        "email": "existing@example.com"
    }

    # Act
    response = await http_client.post("/users", json=payload)

    # Assert - Status Code
    assert response.status_code == status.HTTP_400_BAD_REQUEST

    # Assert - Error Structure
    json_response = response.json()
    assert "message" in json_response

    # Assert - Error Content
    assert json_response["message"] == "Email already registered"

    # Assert - Error Types
    assert isinstance(json_response["message"], str)

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 2: Error with i18n

```python
@pytest.mark.parametrize("language,expected_message", [
    ("pt-BR", "Produto not found"),
    ("en-US", "Product not found")
], ids=["pt-BR", "en-US"])
async def test_get_product_not_found_i18n(
    http_client: AsyncClient,
    language: str,
    expected_message: str
):
    """Tests error message in Portuguese and English."""
    # Arrange
    mock_db = MagicMock()
    mock_db.retrieve.return_value = None
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.get(
        "/products/nonexistent",
        headers={"Accept-Language": language}
    )

    # Assert - Status Code
    assert response.status_code == status.HTTP_404_NOT_FOUND

    # Assert - Error Message
    json_response = response.json()
    assert json_response["message"] == expected_message

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 3: Error with Additional Details

```python
async def test_purchase_insufficient_stock_detailed_error(
    http_client: AsyncClient
):
    """Tests insufficient stock error with details."""
    # Arrange
    mock_db = MagicMock()
    mock_db.retrieve.return_value = {
        "id": "prod123",
        "name": "Product A",
        "stock": 5
    }
    app.dependency_overrides[get_database] = lambda: mock_db

    payload = {
        "product_id": "prod123",
        "quantity": 10  # greater than available stock
    }

    # Act
    response = await http_client.post("/purchases", json=payload)

    # Assert - Status Code
    assert response.status_code == status.HTTP_400_BAD_REQUEST

    # Assert - Error Structure
    json_response = response.json()
    assert "message" in json_response
    assert "error_code" in json_response
    assert "details" in json_response

    # Assert - Error Content
    assert "insufficient stock" in json_response["message"].lower()
    assert json_response["error_code"] == "INSUFFICIENT_STOCK"

    # Assert - Error Details
    details = json_response["details"]
    assert details["requested"] == 10
    assert details["available"] == 5
    assert details["product_id"] == "prod123"

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 4: Multiple Error Messages

```python
@pytest.mark.parametrize("scenario,status_code,message,error_code", [
    ("not_found", 404, "Order not found", "ORDER_NOT_FOUND"),
    ("forbidden", 403, "Access denied", "ACCESS_DENIED"),
    ("invalid_status", 400, "Invalid order status", "INVALID_STATUS"),
    ("already_paid", 400, "Order already paid", "ALREADY_PAID")
], ids=["not-found", "forbidden", "invalid-status", "already-paid"])
async def test_process_order_errors(
    http_client: AsyncClient,
    scenario: str,
    status_code: int,
    message: str,
    error_code: str
):
    """Tests different error messages from the endpoint."""
    # Arrange
    mock_db = MagicMock()

    if scenario == "not_found":
        mock_db.retrieve.return_value = None
    elif scenario == "forbidden":
        mock_db.retrieve.return_value = {"id": "order123", "user_id": "other"}
    elif scenario == "invalid_status":
        mock_db.retrieve.return_value = {"id": "order123", "status": "cancelled"}
    elif scenario == "already_paid":
        mock_db.retrieve.return_value = {"id": "order123", "status": "paid"}

    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.post(f"/orders/order123/process")

    # Assert - Status and Error
    assert response.status_code == status_code
    json_response = response.json()
    assert json_response["message"] == message
    assert json_response["error_code"] == error_code

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 5: Internal Server Error

```python
async def test_internal_error_generic_message(http_client: AsyncClient):
    """Tests internal server error."""
    # Arrange
    mock_db = MagicMock()
    mock_db.retrieve.side_effect = Exception("Database connection failed")
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.get("/users/user123")

    # Assert - Status Code
    assert response.status_code == status.HTTP_500_INTERNAL_SERVER_ERROR

    # Assert - Error Structure
    json_response = response.json()
    assert "message" in json_response

    # Assert - Generic Error Message (do not expose internal details)
    assert json_response["message"] == "Internal server error"

    # Assert - Internal details MUST NOT be exposed
    assert "database" not in json_response["message"].lower()

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 6: Error with List of Issues

```python
async def test_bulk_operation_partial_failures(http_client: AsyncClient):
    """Tests batch operation with partial failures."""
    # Arrange
    mock_db = MagicMock()
    app.dependency_overrides[get_database] = lambda: mock_db

    payload = {
        "operations": [
            {"id": "item1", "action": "update"},
            {"id": "item2", "action": "delete"},
            {"id": "item3", "action": "invalid"}  # invalid action
        ]
    }

    # Act
    response = await http_client.post("/items/bulk", json=payload)

    # Assert - Status (Multi-Status or Bad Request)
    assert response.status_code in [
        status.HTTP_400_BAD_REQUEST,
        status.HTTP_207_MULTI_STATUS
    ]

    # Assert - Error Structure
    json_response = response.json()
    assert "message" in json_response
    assert "errors" in json_response

    # Assert - Errors List
    errors = json_response["errors"]
    assert isinstance(errors, list)
    assert len(errors) > 0

    # Assert - Each Error Structure
    for error in errors:
        assert "item_id" in error
        assert "message" in error
        assert "error_code" in error

    # Assert - Specific Error
    invalid_error = next(
        (e for e in errors if e["item_id"] == "item3"),
        None
    )
    assert invalid_error is not None
    assert "invalid action" in invalid_error["message"].lower()

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 7: Error with Suggestion

```python
async def test_invalid_filter_with_suggestion(http_client: AsyncClient):
    """Tests error with correction suggestion."""
    # Arrange
    mock_db = MagicMock()
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act - Invalid filter
    response = await http_client.get("/users?statu=active")  # typo: statu

    # Assert - Status Code
    assert response.status_code == status.HTTP_400_BAD_REQUEST

    # Assert - Error with Suggestion
    json_response = response.json()
    assert json_response["message"] == "Invalid filter parameter"
    assert json_response["error_code"] == "INVALID_FILTER"

    # Assert - Suggestion
    assert "suggestion" in json_response
    assert json_response["suggestion"] == "Did you mean 'status'?"

    # Cleanup
    app.dependency_overrides.clear()
```

---

## Standard Error Structure

### Our API (Field "message")

```json
{"message": "Human-readable description of the error"}
```

---

## Checklist

When validating error messages:

- [ ] ✅ Validate correct status code
- [ ] ✅ Validate error structure (field "message")
- [ ] ✅ Validate exact or expected message
- [ ] ✅ Validate `error_code` when applicable
- [ ] ✅ Test message in pt-BR AND en-US
- [ ] ✅ Validate additional details when present
- [ ] ✅ Do not expose internal details in 500 errors
- [ ] ✅ Validate types of error fields
- [ ] ✅ Validate `errors` list in batch operations
- [ ] ✅ Validate suggestions when applicable
