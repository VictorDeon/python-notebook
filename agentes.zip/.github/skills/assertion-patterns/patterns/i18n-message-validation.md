# i18n Message Validation

Validation of internationalized messages for pt-BR and en-US.

## Principle

Always test i18n messages in BOTH languages (pt-BR and en-US) to ensure translations are correct and complete.

---

## ✅ Correct Pattern

```python
# Test in pt-BR
async def test_endpoint_error_message_ptbr(http_client: AsyncClient):
    response = await http_client.get(
        "/endpoint",
        headers={"Accept-Language": "pt-BR"}
    )
    json_response = response.json()
    assert json_response["message"] == "Usuário not found"

# Test in en-US
async def test_endpoint_error_message_enus(http_client: AsyncClient):
    response = await http_client.get(
        "/endpoint",
        headers={"Accept-Language": "en-US"}
    )
    json_response = response.json()
    assert json_response["message"] == "User not found"

# Parameterized test (RECOMMENDED)
@pytest.mark.parametrize("language,expected_message", [
    ("pt-BR", "Usuário not found"),
    ("en-US", "User not found")
])
async def test_endpoint_error_message(
    http_client: AsyncClient,
    language: str,
    expected_message: str
):
    response = await http_client.get(
        "/endpoint",
        headers={"Accept-Language": language}
    )
    json_response = response.json()
    assert json_response["message"] == expected_message
```

---

## ❌ Anti-Pattern

```python
# BAD: Testing only one language
async def test_error_message(http_client: AsyncClient):
    response = await http_client.get("/endpoint")
    assert "message" in response.json()  # does not validate content

# BAD: Using the wrong field (FastAPI uses "detail" for validation; our API uses "message")
assert "detail" in response.json()
assert response.json()["detail"] == "mensagem"

# BAD: Not asserting exact message
assert len(response.json()["message"]) > 0  # too vague
assert "not found" in response.json()["message"]  # partial
```

**Problems:**
- Does not guarantee both languages work
- May pass with incorrect translations
- Does not detect missing messages

---

## Usage in Tests

### Example 1: Parameterized Test (Recommended)

```python
@pytest.mark.parametrize("language,expected_message", [
    ("pt-BR", "Usuário not found"),
    ("en-US", "User not found")
], ids=["pt-BR", "en-US"])
async def test_get_user_not_found_i18n(
    http_client: AsyncClient,
    language: str,
    expected_message: str
):
    """Tests the error message in Portuguese and English."""
    # Arrange
    mock_db = MagicMock()
    mock_db.retrieve.return_value = None
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.get(
        "/users/nonexistent",
        headers={"Accept-Language": language}
    )

    # Assert
    assert response.status_code == status.HTTP_404_NOT_FOUND
    json_response = response.json()
    assert json_response["message"] == expected_message

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 2: Message Interpolation

```python
@pytest.mark.parametrize("language,expected_message", [
    ("pt-BR", "Usuário João Silva foi criado successfully"),
    ("en-US", "User João Silva was successfully created")
], ids=["pt-BR", "en-US"])
async def test_create_user_success_message_i18n(
    http_client: AsyncClient,
    language: str,
    expected_message: str
):
    """Tests success messages with variable interpolation."""
    # Arrange
    mock_db = MagicMock()
    mock_db.create.return_value = {"id": "user123"}
    app.dependency_overrides[get_database] = lambda: mock_db

    payload = {
        "name": "John Doe",
        "email": "joao@example.com"
    }

    # Act
    response = await http_client.post(
        "/users",
        json=payload,
        headers={"Accept-Language": language}
    )

    # Assert
    assert response.status_code == status.HTTP_201_CREATED
    json_response = response.json()
    assert json_response["message"] == expected_message

    # Alternative: Assert it contains the name
    assert "John Doe" in json_response["message"]

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 3: Multiple Messages on the Same Endpoint

```python
@pytest.mark.parametrize("scenario,status_code,language,expected_message", [
    ("success", 201, "pt-BR", "Produto criado successfully"),
    ("success", 201, "en-US", "Product successfully created"),
    ("duplicate", 400, "pt-BR", "Produto already exists"),
    ("duplicate", 400, "en-US", "Product already exists"),
    ("invalid_price", 400, "pt-BR", "Invalid price"),
    ("invalid_price", 400, "en-US", "Invalid price")
], ids=[
    "success-pt-BR", "success-en-US",
    "duplicate-pt-BR", "duplicate-en-US",
    "invalid-price-pt-BR", "invalid-price-en-US"
])
async def test_create_product_messages_i18n(
    http_client: AsyncClient,
    scenario: str,
    status_code: int,
    language: str,
    expected_message: str
):
    """Tests all endpoint messages in both languages."""
    # Arrange
    mock_db = MagicMock()

    if scenario == "success":
        mock_db.create.return_value = {"id": "prod123"}
        payload = {"name": "Product", "price": 99.90}
    elif scenario == "duplicate":
        mock_db.retrieve.return_value = {"id": "existing"}
        payload = {"name": "Product", "price": 99.90}
    elif scenario == "invalid_price":
        payload = {"name": "Product", "price": -10}

    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.post(
        "/products",
        json=payload,
        headers={"Accept-Language": language}
    )

    # Assert
    assert response.status_code == status_code
    json_response = response.json()
    assert json_response["message"] == expected_message

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 4: Pydantic Validation Messages

```python
# Note: Pydantic uses "detail", not "message"
async def test_validation_error_required_field_ptbr(http_client: AsyncClient):
    """Tests Pydantic validation error in Portuguese."""
    # Arrange
    payload = {}  # required field missing

    # Act
    response = await http_client.post(
        "/users",
        json=payload,
        headers={"Accept-Language": "pt-BR"}
    )

    # Assert
    assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY
    json_response = response.json()
    assert "detail" in json_response  # Pydantic uses "detail"
    assert len(json_response["detail"]) > 0

    # Validate error structure
    error = json_response["detail"][0]
    assert error["loc"] == ["body", "name"]
    assert error["type"] == "missing"
```

### Example 5: Language-configured Client Fixtures

```python
@pytest.fixture
async def http_client_ptbr(http_client: AsyncClient) -> AsyncClient:
    """HTTP client configured for pt-BR."""
    http_client.headers["Accept-Language"] = "pt-BR"
    return http_client


@pytest.fixture
async def http_client_enus(http_client: AsyncClient) -> AsyncClient:
    """HTTP client configured for en-US."""
    http_client.headers["Accept-Language"] = "en-US"
    return http_client


async def test_error_message_ptbr(http_client_ptbr: AsyncClient):
    """Tests the message in Portuguese using a fixture."""
    # Arrange
    mock_db = MagicMock()
    mock_db.retrieve.return_value = None
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client_ptbr.get("/users/nonexistent")

    # Assert
    json_response = response.json()
    assert json_response["message"] == "Usuário not found"

    # Cleanup
    app.dependency_overrides.clear()


async def test_error_message_enus(http_client_enus: AsyncClient):
    """Tests the message in English using a fixture."""
    # Arrange
    mock_db = MagicMock()
    mock_db.retrieve.return_value = None
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client_enus.get("/users/nonexistent")

    # Assert
    json_response = response.json()
    assert json_response["message"] == "User not found"

    # Cleanup
    app.dependency_overrides.clear()
```

---

## Message Structure

### Success Messages

```python
# Our convention: use the "message" field
{
    "message": "Operation completed successfully",
    "data": {...}
}
```

### Error Messages (Our API)

```python
# Our convention: use the "message" field
{
    "message": "Resource not found",
    "error_code": "RESOURCE_NOT_FOUND"
}
```

### Error Messages (Pydantic)

```python
# Pydantic uses "detail"
{
    "detail": [
        {
            "loc": ["body", "field"],
            "msg": "field required",
            "type": "value_error.missing"
        }
    ]
}
```

---

## Identifying i18n Messages in Code

Look for `_("...")` in the code:

```python
# Controller or route
from engines.i18n import _

def create_user():
    if user_exists:
        raise HTTPException(
            status_code=400,
            detail=_("User already exists")  # ← TEST both pt-BR + en-US
        )
```

---

## Checklist

When testing i18n messages:

- [ ] ✅ Test BOTH languages (pt-BR and en-US)
- [ ] ✅ Use `@pytest.mark.parametrize` to avoid duplication
- [ ] ✅ Assert the exact message, not just presence
- [ ] ✅ Use `headers={"Accept-Language": language}` on requests
- [ ] ✅ Validate variable interpolation when applicable
- [ ] ✅ Use the correct field: `message` (our API) vs `detail` (Pydantic)
- [ ] ✅ Test all endpoint messages in both languages
- [ ] ✅ Use descriptive ids in parameterized tests
