# Pagination

Validation of pagination metadata in responses.

## Principle

Always validate all pagination metadata: total items, current page, page size, and indicators for previous/next pages.

---

## ✅ Correct Pattern

```python
# Validate pagination metadata
json_response = response.json()
assert json_response["total"] == 50
assert json_response["page"] == 1
assert json_response["page_size"] == 10
assert len(json_response["items"]) == 10
assert json_response["has_next"] is True
assert json_response["has_previous"] is False

# Validate total number of pages
assert json_response["total_pages"] == 5
```

---

## ❌ Anti-Pattern

```python
# BAD: Does not validate pagination metadata
assert "items" in json_response  # does not validate pagination

# BAD: Incomplete validation
assert len(json_response["items"]) > 0  # does not validate metadata
```

**Problems:**
- Does not ensure pagination is working
- May return all items without pagination
- Does not validate navigation between pages

---

## Usage in Tests

### Example 1: First Page

```python
async def test_list_users_first_page(http_client: AsyncClient):
    """Tests first page with pagination."""
    # Arrange
    mock_db = MagicMock()
    # Simulate 25 total users
    mock_db.count.return_value = 25
    # Return first 10 users
    mock_db.query.return_value = [
        {"id": f"user{i}", "name": f"User {i}"}
        for i in range(1, 11)
    ]
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.get("/users?page=1&page_size=10")

    # Assert - Status
    assert response.status_code == status.HTTP_200_OK

    # Assert - Pagination metadata
    json_response = response.json()
    assert json_response["total"] == 25
    assert json_response["page"] == 1
    assert json_response["page_size"] == 10
    assert json_response["total_pages"] == 3
    assert json_response["has_next"] is True
    assert json_response["has_previous"] is False

    # Assert - Items
    assert len(json_response["items"]) == 10
    assert json_response["items"][0]["id"] == "user1"

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 2: Middle Page

```python
async def test_list_users_middle_page(http_client: AsyncClient):
    """Tests middle page with pagination."""
    # Arrange
    mock_db = MagicMock()
    mock_db.count.return_value = 25
    # Return users 11-20 (page 2)
    mock_db.query.return_value = [
        {"id": f"user{i}", "name": f"User {i}"}
        for i in range(11, 21)
    ]
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.get("/users?page=2&page_size=10")

    # Assert - Pagination metadata
    json_response = response.json()
    assert json_response["page"] == 2
    assert json_response["has_next"] is True
    assert json_response["has_previous"] is True

    # Assert - Correct items for page 2
    assert len(json_response["items"]) == 10
    assert json_response["items"][0]["id"] == "user11"

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 3: Last Page

```python
async def test_list_users_last_page(http_client: AsyncClient):
    """Tests last page with partial item count."""
    # Arrange
    mock_db = MagicMock()
    mock_db.count.return_value = 25
    # Last page with only 5 items (21-25)
    mock_db.query.return_value = [
        {"id": f"user{i}", "name": f"User {i}"}
        for i in range(21, 26)
    ]
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.get("/users?page=3&page_size=10")

    # Assert - Pagination metadata
    json_response = response.json()
    assert json_response["total"] == 25
    assert json_response["page"] == 3
    assert json_response["total_pages"] == 3
    assert json_response["has_next"] is False  # last page
    assert json_response["has_previous"] is True

    # Assert - Items (only 5 on the last page)
    assert len(json_response["items"]) == 5
    assert json_response["items"][0]["id"] == "user21"
    assert json_response["items"][-1]["id"] == "user25"

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 4: Empty Page (Out of Range)

```python
async def test_list_users_page_out_of_range(http_client: AsyncClient):
    """Tests page beyond available range."""
    # Arrange
    mock_db = MagicMock()
    mock_db.count.return_value = 25  # only 3 pages with page_size=10
    mock_db.query.return_value = []  # no results
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.get("/users?page=10&page_size=10")

    # Assert - Empty list but correct metadata
    json_response = response.json()
    assert json_response["total"] == 25
    assert json_response["page"] == 10
    assert json_response["total_pages"] == 3
    assert json_response["items"] == []
    assert len(json_response["items"]) == 0

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 5: Different Page Sizes

```python
@pytest.mark.parametrize("page_size,expected_pages", [
    (5, 5),   # 25 items / 5 per page = 5 pages
    (10, 3),  # 25 items / 10 per page = 3 pages
    (25, 1),  # 25 items / 25 per page = 1 page
    (50, 1),  # 25 items / 50 per page = 1 page
], ids=["size-5", "size-10", "size-25", "size-50"])
async def test_list_users_different_page_sizes(
    http_client: AsyncClient,
    page_size: int,
    expected_pages: int
):
    """Tests pagination with different page sizes."""
    # Arrange
    mock_db = MagicMock()
    mock_db.count.return_value = 25
    mock_db.query.return_value = [
        {"id": f"user{i}", "name": f"User {i}"}
        for i in range(1, min(page_size + 1, 26))
    ]
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.get(f"/users?page=1&page_size={page_size}")

    # Assert - Metadata
    json_response = response.json()
    assert json_response["total"] == 25
    assert json_response["page_size"] == page_size
    assert json_response["total_pages"] == expected_pages

    # Assert - Number of items
    expected_items = min(page_size, 25)
    assert len(json_response["items"]) == expected_items

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 6: Cursor-Based Pagination

```python
async def test_list_items_cursor_based_pagination(http_client: AsyncClient):
    """Tests cursor-based pagination."""
    # Arrange
    mock_db = MagicMock()
    mock_db.query.return_value = [
        {"id": "item1", "cursor": "cursor1"},
        {"id": "item2", "cursor": "cursor2"},
        {"id": "item3", "cursor": "cursor3"}
    ]
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.get("/items?limit=3")

    # Assert - Cursor metadata
    json_response = response.json()
    assert "items" in json_response
    assert "next_cursor" in json_response
    assert "has_more" in json_response

    # Assert - Items and cursor
    assert len(json_response["items"]) == 3
    assert json_response["next_cursor"] == "cursor3"
    assert json_response["has_more"] is True

    # Cleanup
    app.dependency_overrides.clear()


async def test_list_items_next_page_with_cursor(http_client: AsyncClient):
    """Tests next page using cursor."""
    # Arrange
    mock_db = MagicMock()
    mock_db.query.return_value = [
        {"id": "item4", "cursor": "cursor4"},
        {"id": "item5", "cursor": "cursor5"}
    ]
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act - Use cursor from previous page
    response = await http_client.get("/items?cursor=cursor3&limit=3")

    # Assert
    json_response = response.json()
    assert len(json_response["items"]) == 2
    assert json_response["items"][0]["id"] == "item4"
    assert json_response["has_more"] is False  # last page

    # Cleanup
    app.dependency_overrides.clear()
```

### Example 7: Pagination with Unknown Total

```python
async def test_list_stream_pagination_no_total(http_client: AsyncClient):
    """Tests stream pagination where total is unknown."""
    # Arrange
    mock_db = MagicMock()
    mock_db.query.return_value = [
        {"id": f"item{i}"} for i in range(1, 11)
    ]
    app.dependency_overrides[get_database] = lambda: mock_db

    # Act
    response = await http_client.get("/stream?limit=10")

    # Assert - No "total" field
    json_response = response.json()
    assert "total" not in json_response  # total unknown
    assert "items" in json_response
    assert "has_more" in json_response

    # Assert - Returned items
    assert len(json_response["items"]) == 10
    assert json_response["has_more"] is True  # may have more

    # Cleanup
    app.dependency_overrides.clear()
```

---

## Pagination Structures

### Offset-Based Pagination

```json
{
  "items": [...],
  "total": 100,
  "page": 1,
  "page_size": 10,
  "total_pages": 10,
  "has_next": true,
  "has_previous": false
}
```

### Cursor-Based Pagination

```json
{
  "items": [...],
  "next_cursor": "cursor123",
  "has_more": true
}
```

---

## Pagination Calculations

```python
# Total pages
total_pages = math.ceil(total_items / page_size)

# Has next page?
has_next = page < total_pages

# Has previous page?
has_previous = page > 1

# Offset for query
offset = (page - 1) * page_size
```

---

## Checklist

When validating pagination:

- [ ] ✅ Validate `total` (total number of items)
- [ ] ✅ Validate `page` (current page)
- [ ] ✅ Validate `page_size` (items per page)
- [ ] ✅ Validate `total_pages` (total number of pages)
- [ ] ✅ Validate `has_next` (has next page)
- [ ] ✅ Validate `has_previous` (has previous page)
- [ ] ✅ Validate actual size of the items list
- [ ] ✅ Test first, last, and middle pages
- [ ] ✅ Test different page sizes
- [ ] ✅ Test page beyond range (empty)
- [ ] ✅ For cursor: validate `next_cursor` and `has_more`
