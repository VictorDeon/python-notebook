---
name: assertion-patterns
description: Comprehensive assertion patterns for FastAPI integration tests covering status codes, response bodies, mock validations, i18n messages, error handling, and edge cases; use this skill to ensure robust and complete test assertions that validate all aspects of endpoint behavior, from HTTP responses to mock call verification and internationalized messages.
---

# Skill: Assertion Patterns

This skill provides comprehensive assertion patterns for creating robust and deterministic tests.

## When to Use This Skill

* When implementing assertions in integration tests
* When validating HTTP responses from FastAPI endpoints
* When verifying mock calls
* When testing i18n messages (pt-BR and en-US)
* When validating Pydantic validation errors
* When ensuring complete and specific tests

---

## Core Principles

### ✅ Always Do

* **Specific assertions**: Validate exact values, not just existence
* **Multiple assertions**: Validate status, body, mocks, types
* **Use constants**: `status.HTTP_200_OK` instead of `200`
* **Validate structure**: Types, keys, nested structures
* **Verify mocks**: Calls, arguments, order when relevant
* **Test i18n**: Messages in BOTH pt-BR AND en-US
* **Error Assersion**: Assert json response error by "message" attribute.

### ❌ Never Do

* **Magic numbers**: `assert response.status_code == 200`
* **Vague assertions**: `assert response.json()`
* **Don't validate mocks**: Leave mocks without verification
* **Ignore types**: Don't validate data types
* **Skip i18n**: Test only one language
* **Incomplete assertions**: Validate only status without body
* **Superficial assertions**: Use `in` to compare instead of exact matches.

---

## Assertion Patterns

### 1. HTTP Status

Validation of status codes using FastAPI constants.

* [Status Code Assertions](./patterns/status-code-assertions.md)

### 2. Response Body

Validation of response body structure and content.

* [Response Body Structure](./patterns/response-body-structure.md)
* [Response Body Data Types](./patterns/response-body-data-types.md)
* [Response Body Nested Data](./patterns/response-body-nested-data.md)

### 3. Mock Validation

Verification that mocks were called correctly.

* [Mock Call Validation](./patterns/mock-call-validation.md)
* [Mock Call Order](./patterns/mock-call-order.md)

### 4. i18n Messages

Validation of internationalized messages.

* [i18n Message Validation](./patterns/i18n-message-validation.md)

### 5. Validation Errors

Validation of Pydantic errors (422).

* [Validation Errors](./patterns/validation-errors.md)

### 6. Exception Handling

Tests for exception handling.

* [Exception Handling](./patterns/exception-handling.md)

### 7. Lists and Collections

Validation of arrays and collections.

* [Lists and Collections](./patterns/lists-collections.md)
* [Pagination](./patterns/pagination.md)

### 8. Special Cases

Validation of special cases and edge cases.

* [Timestamps and Dates](./patterns/timestamps-dates.md)
* [Optional Fields](./patterns/optional-fields.md)
* [Multiple Assertions](./patterns/multiple-assertions.md)
* [Error Messages](./patterns/error-messages.md)

---

## Usage Examples

### Complete Test with Robust Assertions

```python
async def test_create_user_success(http_client: AsyncClient):
    """
    Tests successful user creation with complete assertions.

    Scenario:
    - Valid data provided
    - Mock configured for success

    Assertions:
    - Status 201 Created
    - Body contains correct data
    - Mock was called correctly
    - Data types validated
    """

    # Arrange
    mock_db = MagicMock()
    mock_db.create.return_value = {"id": "user123"}
    app.dependency_overrides[get_database] = lambda: mock_db

    payload = {
        "name": "John Doe",
        "email": "john@example.com"
    }

    # Act
    response = await http_client.post("/users", json=payload)

    # Assert - Status Code
    assert response.status_code == status.HTTP_201_CREATED

    # Assert - Response Body Structure
    json_response = response.json()
    assert "id" in json_response
    assert "name" in json_response
    assert "email" in json_response
    assert "created_at" in json_response

    # Assert - Response Body Values
    assert json_response["id"] == "user123"
    assert json_response["name"] == "John Doe"
    assert json_response["email"] == "john@example.com"

    # Assert - Response Body Types
    assert isinstance(json_response["id"], str)
    assert isinstance(json_response["name"], str)
    assert isinstance(json_response["created_at"], str)

    # Assert - Mock Calls
    from unittest.mock import ANY
    mock_db.create.assert_called_once_with("users", {
        "name": "John Doe",
        "email": "john@example.com",
        "created_at": ANY
    })

    # Cleanup
    app.dependency_overrides.clear()
```

---

## Quality Checklist

Use this checklist when implementing assertions:

- [ ] ✅ Status code validated with FastAPI constant
- [ ] ✅ Response body structure verified
- [ ] ✅ Specific body values validated
- [ ] ✅ Data types checked
- [ ] ✅ Nested data validated (if present)
- [ ] ✅ Mocks verified with `assert_called_once_with()`
- [ ] ✅ Mock arguments validated (use `ANY` for dynamic values)
- [ ] ✅ i18n messages tested in both pt-BR and en-US
- [ ] ✅ Pydantic validation errors verified (if 422)
- [ ] ✅ Lists/collections checked (size and content)
- [ ] ✅ Optional fields handled correctly
- [ ] ✅ Multiple related assertions included

---

## Common Anti-Patterns

### ❌ Vague Assertion

```python
# BAD: Doesn't validate anything specific
assert response.json()
```

```python
# GOOD: Validates specific values
json_response = response.json()
assert json_response["id"] == "user123"
assert json_response["name"] == "John Doe"
```

### ❌ Magic Number

```python
# BAD: Hard-coded code
assert response.status_code == 200
```

```python
# GOOD: Use constant
assert response.status_code == status.HTTP_200_OK
```

### ❌ Unverified Mock

```python
# BAD: Mock is not validated
mock_db.create.return_value = {"id": "123"}
response = await http_client.post("/users", json={...})
# doesn't verify if create was called
```

```python
# GOOD: Mock is verified
mock_db.create.return_value = {"id": "123"}
response = await http_client.post("/users", json={...})
mock_db.create.assert_called_once()
```

### ❌ Doesn't Validate Type

```python
# BAD: Doesn't validate data type
assert json_response["count"]
```

```python
# GOOD: Validates type and value
assert isinstance(json_response["count"], int)
assert json_response["count"] == 5
```

---

## References

* [FastAPI Testing](https://fastapi.tiangolo.com/tutorial/testing/)
* [unittest.mock Documentation](https://docs.python.org/3/library/unittest.mock.html)
* [pytest Best Practices](https://docs.pytest.org/en/stable/goodpractices.html)
