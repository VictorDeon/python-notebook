### [Issue Title] — `file.py:line`

**Category:** Security

**Location:** `api/module/file.py:123` (function `function_name`)

**Description:**

[Hardcoded credential / Lack of validation / etc.]

**Evidence:**

```python
# Problematic code
API_KEY = "sk-abc123..."
```

**Impact:**

- Exposure of sensitive credentials
- Unauthorized access possible
- **Estimated risk:** High - Full system access

**Suggested Solution:**

```python
from api.constants import API_KEY  # From environment variable

# Use the constant loaded from .env
client = OpenAI(api_key=API_KEY)
```

**References:**

- [OWASP A02:2021 – Cryptographic Failures](https://owasp.org/Top10/A02_2021-Cryptographic_Failures/)
