## Authentication and Authorization

### ❌ Common Issues:

- Endpoints without auth verification
- Authorization checked only on frontend
- Missing rate limiting
- Tokens without expiration or rotation

### ✅ Checks:

- [ ] All private endpoints use `Depends(get_current_user)`
- [ ] Backend permission verification
- [ ] Rate limiting configured for public endpoints
- [ ] Tokens have appropriate expiration
- [ ] Refresh tokens properly implemented

### Example:

```python
# ❌ CRITICAL: Endpoint without authentication
@router.delete("/users/{user_id}")
async def delete_user(user_id: str):
    await db.collection('users').document(user_id).delete()

# ✅ Solution: With authentication and authorization
from fastapi import Depends
from engines.security import get_current_admin_user

@router.delete(
    "/users/{user_id}",
    status_code=204,
    dependencies=[Depends(RateLimiter(times=5, seconds=60))]
)
async def delete_user(
    user_id: str,
    current_user: User = Depends(get_current_admin_user)
):
    """Delete user (requires admin permissions)."""
    await user_controller.delete_user(user_id, current_user)
```
