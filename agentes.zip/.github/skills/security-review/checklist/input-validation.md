## Input Validation

### ❌ Common Issues:

- Endpoints accepting `dict` instead of validated DTOs
- Lack of input sanitization
- Validation only on frontend
- Missing size limits for uploads

### ✅ Checks:

- [ ] All endpoints use Pydantic DTOs for validation
- [ ] Proper type, format, and range validation
- [ ] Inputs are sanitized before use in queries
- [ ] Size limits defined for uploads and payloads

### Example:

```python
# ❌ CRITICAL: No validation
@router.post("/users")
async def create_user(data: dict):  # Accepts anything!
    return await db.collection('users').add(data)

# ✅ Solution: Validation with Pydantic
from pydantic import Field, EmailStr

class CreateUserDTO(BaseModel):
    email: EmailStr = Field(..., description="Valid email")
    age: int = Field(..., ge=18, le=120, description="Age between 18 and 120")
    name: str = Field(..., min_length=2, max_length=100)

@router.post("/users", response_model=UserModel, status_code=201)
async def create_user(data: CreateUserDTO):
    return await user_controller.create_user(data)
```
