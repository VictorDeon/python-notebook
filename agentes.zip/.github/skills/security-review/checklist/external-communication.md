## External Communication

### ❌ Common Issues:

- HTTP requests without timeout
- SSL certificates not validated
- CORS configured as `allow_origins=["*"]`
- Missing security headers

### ✅ Checks:

- [ ] All HTTP requests have defined timeout
- [ ] SSL/TLS certificates are validated (don't use `verify=False`)
- [ ] CORS configured with specific origins in production
- [ ] Security headers present (HSTS, X-Frame-Options, CSP)

### Example:

```python
# ❌ CRITICAL: No timeout and SSL disabled
response = httpx.get("https://api.example.com", verify=False)

# ✅ Solution: Timeout and SSL validated
response = await httpx.AsyncClient(timeout=10.0).get(
    "https://api.example.com"
)
```
