## Secrets and Credentials

### ❌ Common Issues:

- Hardcoded API keys
- Passwords or tokens in source code
- Credentials in logs or error messages
- Exposed environment variables

### ✅ Checks:

- [ ] No hardcoded secrets in code
- [ ] All credentials loaded via environment variables
- [ ] Use of Pydantic's `SecretStr` for sensitive fields
- [ ] `.env` files are in `.gitignore`

### Example:

```python
# ❌ CRITICAL: Hardcoded credential
FIREBASE_KEY = "AIzaSyC_abc123_REAL_KEY"

# ✅ Solution: Use environment variable
from api.constants import FIREBASE_KEY  # loaded from .env via Pydantic Settings
```
