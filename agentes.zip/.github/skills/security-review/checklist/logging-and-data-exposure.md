## Logging and Data Exposure

### ❌ Common Issues:

- Logs with passwords or tokens
- Stack traces with sensitive data in production
- PII in error messages
- Logs without sanitization

### ✅ Checks:

- [ ] Logs don't contain passwords, tokens, or PII
- [ ] Use of logger configured in `engines/logger.py`
- [ ] Automatic sanitization of sensitive data
- [ ] Detailed stack traces only in development

### Example:

```python
# ❌ CRITICAL: Exposing sensitive data
logger.info(f"User login: {email}, password: {password}")

# ✅ Solution: Automatic sanitization
from engines.logger import logger

logger.info(f"User login attempt", json_data={
    "email": email,  # will be automatically sanitized
    "user_id": user.id
})
```
