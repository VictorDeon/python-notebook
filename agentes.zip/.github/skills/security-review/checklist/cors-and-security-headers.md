## CORS and Security Headers

### ✅ Checks:

- [ ] CORS doesn't use `allow_origins=["*"]` in production
- [ ] Security headers configured:
  - `X-Frame-Options: DENY`
  - `X-Content-Type-Options: nosniff`
  - `Strict-Transport-Security` (HSTS)
  - `Content-Security-Policy` (CSP)
- [ ] HTTPS enforced in production
