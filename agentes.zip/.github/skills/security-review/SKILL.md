---
name: security-review
description: Security Skill is a specialized tool for identifying vulnerabilities and data exposures in Python/FastAPI code, following OWASP standards and best practices for GDPR and LGPD compliance. Use this skill during security-focused code reviews, especially when analyzing public endpoints or those handling sensitive data, validating authentication and authorization, or verifying the proper handling of personally identifiable information (PII). The skill provides a comprehensive checklist covering secrets and credentials, input validation, access control, data leaks in logs, secure external communication, and CORS configuration, allowing you to detect and mitigate critical risks before code integration.
---

# Skill: Security Review

## Objective

Identify security vulnerabilities and data exposure in Python/FastAPI code, following OWASP standards and GDPR/LGPD best practices.

## When to Use

- During code reviews with a security focus
- When analyzing public endpoints or those handling sensitive data
- When reviewing authentication and authorization
- When validating personally identifiable information (PII) handling

## Severity

🔴 **CRITICAL** — Vulnerabilities must be fixed before merge

---

## Security Checklist

* [Secrets and Credentials](./checklist/secrets-and-credentials.md)
* [Input Validation](./checklist/input-validation.md)
* [Authentication and Authorization](./checklist/authentication-and-authorization.md)
* [Logging and Data Exposure](./checklist/logging-and-data-exposure.md)
* [External Communication](./checklist/external-communication.md)
* [CORS and Security Headers](./checklist/cors-and-security-headers.md)

---

## Common Risks and Impacts

| Vulnerability | Impact | Mitigation |
|---------------|--------|------------|
| Hardcoded secrets | Total unauthorized access | Use environment variables |
| Lack of validation | Injection attacks (SQL, NoSQL) | Mandatory Pydantic DTOs |
| No authentication | Unauthorized data access | Auth dependency injection |
| Logs with PII | GDPR/LGPD violation | Logger with automatic sanitization |
| CORS `*` | CSRF attacks | Specific origins |
| No rate limiting | DDoS and abuse | Rate limiter on public endpoints |

---

## Referências

- [OWASP Top 10](https://owasp.org/www-project-top-ten/)
- [FastAPI Security](https://fastapi.tiangolo.com/tutorial/security/)
- [Pydantic SecretStr](https://docs.pydantic.dev/latest/api/types/#pydantic.types.SecretStr)
- [GDPR - General Data Protection Regulation](https://gdpr.eu/)
- [LGPD - Brazilian General Data Protection Law](https://www.gov.br/cidadania/pt-br/acesso-a-informacao/lgpd)

---

## Finding Template

You can find the complete security review skill template [here](./template.md).
