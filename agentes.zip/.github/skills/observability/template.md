### [Title] — `file.py:line`

**Category:** Observability

**Location:** `api/orders/controllers/order.py:67` (function `process_order`)

**Description:**

Critical operation without adequate logs, making production debugging difficult.

**Evidence:**

```python
async def process_order(order_id: str):
    order = await get_order(order_id)
    # No logs here
    result = await payment_service.charge(order.amount)
    # No success/failure logs
    return result
```

**Impact:**

- Difficult to debug production issues
- No performance visibility
- No audit trail for financial operations
- **Estimated risk:** Low - Doesn't affect functionality, but makes operations difficult

**Suggested Solution:**

```python
from engines.logger import logger

async def process_order(order_id: str):
    logger.info(
        "Processing order started",
        json_data={
            "order_id": order_id,
            "operation": "process_order"
        }
    )

    order = await get_order(order_id)

    try:
        result = await payment_service.charge(order.amount)

        logger.info(
            "Order processed successfully",
            json_data={
                "order_id": order_id,
                "amount": order.amount,
                "payment_id": result.payment_id,
                "status": "success"
            }
        )

        return result

    except Exception as e:
        logger.error(
            "Order processing failed",
            json_data={
                "order_id": order_id,
                "amount": order.amount,
                "error_type": type(e).__name__
            }
        )
        raise
```

**References:**

- [Structured Logging Best Practices](https://www.datadoghq.com/blog/python-logging-best-practices/)
