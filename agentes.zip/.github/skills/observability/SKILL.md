---
name: observability
description: Observability is the ability to understand the internal behavior of a system through its external outputs (logs, metrics, and traces). This skill ensures that the application is monitorable in production through structured JSON logs, performance metrics, request tracing, and system health checks. Use this skill during code reviews with critical business logic, implementation of new endpoints or functionalities, error handling validation, and when analyzing logs and metrics. Observability facilitates the rapid detection of problems, debugging in production, and data-driven operational decision-making.
---

# Skill: Observability

## Objective

Ensure that the application is observable through structured logs, metrics, and tracing, facilitating debugging and monitoring in production.

## When to Use

- During code reviews with critical business logic
- During implementation of new endpoints or features
- When reviewing error handling
- When validating logs and metrics
- When analyzing health check endpoints

## Severity

🟢 **LOW** — Observability is important for operations, but doesn't typically block merge

---

## Observability Checklist

### 🔴 Critical (Always check)

* [Structured Logs (JSON)](./checklist/structured-logs-json.md)
* [Sensitive Data Sanitization](./checklist/sensitive-data-sanitization.md)
* [Exception Tracking](./checklist/exception-tracking.md)

### 🟡 Important (Check in production)

* [Appropriate Log Levels](./checklist/appropriate-log-levels.md)
* [Correlation IDs for Tracing](./checklist/correlation-ids-for-tracing.md)
* [Performance Metrics](./checklist/performance-metrics.md)
* [Health Check Endpoints](./checklist/health-check-endpoints.md)

### 🟢 Recommended (Nice to have)

* [Context Manager for Operations](./checklist/context-manager-for-operations.md)
* [Alerts and Monitoring](./checklist/alerts-and-monitoring.md)
* [Audit Logs](./checklist/audit-logs.md)

---

## Observability Patterns

* [Structured Logging Pattern](./patterns/structured-logging-pattern.md)
* [Distributed Tracing](./patterns/distributed-tracing.md)

---

## Important Metrics to Collect

### Application Metrics

- Request rate (requests/second)
- Latency (p50, p95, p99)
- Error rate (%)
- Active users
- Operations by type

### Business Metrics

- New registrations
- Completed transactions
- Revenue
- Conversions

### Infrastructure Metrics

- CPU usage
- Memory usage
- Disk usage
- Network connections
- Firestore reads/writes

---

## Finding Template

When reporting observability issues in code review, use the standardized template:

**When to use:**

- Finding code without adequate logs
- Identifying critical operations without metrics
- Detecting logs with sensitive data

**Format:** [View full template here](./template.md)

---

## References

- [Python Logging Best Practices](https://docs.python.org/3/howto/logging.html)
- [Structured Logging](https://www.structlog.org/)
- [OpenTelemetry Python](https://opentelemetry.io/docs/instrumentation/python/)
- [Sentry Python SDK](https://docs.sentry.io/platforms/python/)
- [12 Factor App - Logs](https://12factor.net/logs)
