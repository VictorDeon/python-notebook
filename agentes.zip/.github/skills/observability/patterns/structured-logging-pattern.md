## Pattern: Structured Logging Pattern

```python
# Base for all logs
def log_event(
    event_name: str,
    level: str = "info",
    **context
):
    """Helper for consistent structured logs."""
    log_func = getattr(logger, level)
    log_func(
        event_name,
        json_data={
            "event": event_name,
            "timestamp": datetime.now().isoformat(),
            **context
        }
    )

# Usage
log_event(
    "user_registered",
    level="info",
    user_id=user.id,
    email=user.email,
    source="web"
)
```
