## Pattern: Distributed Tracing

```python
# Trace context propagation
@app.middleware("http")
async def trace_context_middleware(request: Request, call_next):
    # Extract or create trace ID
    trace_id = request.headers.get('X-Trace-ID', str(uuid4()))
    span_id = str(uuid4())

    # Store in context var
    trace_id_var.set(trace_id)
    span_id_var.set(span_id)

    # Add to all logs
    logger.info(
        "Request started",
        json_data={
            "trace_id": trace_id,
            "span_id": span_id,
            "method": request.method,
            "path": request.url.path
        }
    )

    response = await call_next(request)

    # Propagate to response
    response.headers['X-Trace-ID'] = trace_id

    return response
```
