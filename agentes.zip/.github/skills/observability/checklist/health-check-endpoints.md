## Health Check Endpoints

### ✅ Health Check Endpoint:

```python
from fastapi import APIRouter, status
from pydantic import BaseModel
from datetime import datetime
from typing import Dict

router = APIRouter(tags=["Health"])

class HealthResponse(BaseModel):
    status: str  # "healthy", "degraded", "unhealthy"
    timestamp: datetime
    version: str
    dependencies: Dict[str, str]  # {service: status}

@router.get(
    "/health",
    response_model=HealthResponse,
    status_code=status.HTTP_200_OK,
    summary="System health check"
)
async def health_check():
    """
    Check system health and its dependencies.

    - **status**: healthy (all OK), degraded (some issues), unhealthy (system unavailable)
    - **dependencies**: Status of each external dependency
    """
    dependencies = {}
    overall_status = "healthy"

    # Check Firestore
    try:
        db.collection('_health_check').limit(1).get()
        dependencies["firestore"] = "healthy"
    except Exception as e:
        logger.error("Firestore health check failed")
        dependencies["firestore"] = "unhealthy"
        overall_status = "unhealthy"

    # Check external services (optional)
    try:
        async with httpx.AsyncClient(timeout=2.0) as client:
            response = await client.get("https://api.external.com/health")
            dependencies["external_api"] = "healthy" if response.status_code == 200 else "degraded"
    except:
        dependencies["external_api"] = "degraded"
        overall_status = "degraded" if overall_status == "healthy" else overall_status

    return HealthResponse(
        status=overall_status,
        timestamp=datetime.now(),
        version="1.0.0",  # From environment variable
        dependencies=dependencies
    )

@router.get(
    "/health/liveness",
    summary="Liveness probe",
    status_code=status.HTTP_200_OK
)
async def liveness():
    """Check if application is running (for Kubernetes)."""
    return {"status": "alive"}

@router.get(
    "/health/readiness",
    summary="Readiness probe",
    status_code=status.HTTP_200_OK
)
async def readiness():
    """Check if application is ready to receive traffic."""
    # Check critical dependencies
    try:
        db.collection('_health_check').limit(1).get()
        return {"status": "ready"}
    except:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Service not ready"
        )
```
