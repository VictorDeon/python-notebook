## Context Manager for Operations

### ✅ Operation Logging with Context Manager:

```python
from contextlib import asynccontextmanager
from time import time

@asynccontextmanager
async def log_operation(operation_name: str, **context):
    """Context manager for logging operations."""
    start_time = time()

    logger.info(
        f"{operation_name} started",
        json_data=context
    )

    try:
        yield

        duration = time() - start_time
        logger.info(
            f"{operation_name} completed",
            json_data={
                **context,
                "duration_ms": round(duration * 1000, 2),
                "status": "success"
            }
        )
    except Exception as e:
        duration = time() - start_time
        logger.error(
            f"{operation_name} failed",
            json_data={
                **context,
                "duration_ms": round(duration * 1000, 2),
                "status": "error",
                "error_type": type(e).__name__,
                "error_message": str(e)
            }
        )
        raise

# Usage
async def process_order(order_id: str):
    async with log_operation(
        "process_order",
        order_id=order_id
    ):
        # Operation here
        await do_something(order_id)
```
