## Appropriate Log Levels

### ✅ Correct Usage of Levels:

| Level | When to Use | Example |
|-------|-------------|---------|
| `DEBUG` | Detailed information for debugging | Variable values, execution flow |
| `INFO` | Normal system events | User login, operation completed |
| `WARNING` | Abnormal but recoverable situations | Operation retry, fallback used |
| `ERROR` | Errors that prevent operation but don't break system | Failed to send email, external API timeout |
| `CRITICAL` | Severe errors that can break system | Database inaccessible, out of memory |

```python
from engines.logger import logger

# DEBUG - Execution details
logger.debug(
    "Query parameters received",
    json_data={"params": query_params}
)

# INFO - Normal operation
logger.info(
    "User created successfully",
    json_data={"user_id": user.id, "email": user.email}
)

# WARNING - Abnormal but recoverable situation
logger.warning(
    "External API timeout, using cached data",
    json_data={"api_url": api_url, "cache_age": cache_age}
)

# ERROR - Operation failure
logger.error(
    "Failed to send welcome email",
    json_data={"user_id": user.id, "error": str(e)}
)

# CRITICAL - Severe error
logger.critical(
    "Database connection failed",
    json_data={"db_host": db_host, "error": str(e)}
)
```
