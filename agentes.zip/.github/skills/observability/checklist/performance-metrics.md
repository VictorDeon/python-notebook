## Performance Metrics

### ✅ Latency Logging:

```python
import time
from engines.logger import logger

@app.middleware("http")
async def log_request_metrics(request: Request, call_next):
    start_time = time.time()

    response = await call_next(request)

    process_time = time.time() - start_time

    logger.info(
        "Request completed",
        json_data={
            "method": request.method,
            "path": request.url.path,
            "status_code": response.status_code,
            "process_time_ms": round(process_time * 1000, 2),
            "client_ip": request.client.host
        }
    )

    # Alert for slow requests
    if process_time > 5.0:
        logger.warning(
            "Slow request detected",
            json_data={
                "path": request.url.path,
                "process_time_ms": round(process_time * 1000, 2)
            }
        )

    return response
```
