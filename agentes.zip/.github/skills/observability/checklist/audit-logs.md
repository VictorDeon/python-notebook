## Audit Logs

### ✅ Audit Trail for Sensitive Operations:

```python
from engines.logger import logger

async def audit_log(
    action: str,
    resource_type: str,
    resource_id: str,
    user_id: str,
    changes: dict = None
):
    """Record audit operations."""
    logger.info(
        "Audit log",
        json_data={
            "event_type": "audit",
            "action": action,  # "create", "update", "delete"
            "resource_type": resource_type,  # "user", "order", etc.
            "resource_id": resource_id,
            "user_id": user_id,
            "changes": changes,  # Before/after
            "timestamp": datetime.now().isoformat()
        }
    )

# Usage in controllers
async def update_user(user_id: str, data: UpdateUserDTO, current_user: User):
    old_user = await get_user(user_id)
    new_user = await _update_user(user_id, data)

    # Audit log
    await audit_log(
        action="update",
        resource_type="user",
        resource_id=user_id,
        user_id=current_user.id,
        changes={
            "before": old_user.model_dump(),
            "after": new_user.model_dump()
        }
    )

    return new_user
```
