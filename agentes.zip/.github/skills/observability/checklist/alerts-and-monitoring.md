## Alerts and Monitoring

### ✅ Alert Patterns:

```python
from engines.slack import send_alert  # Slack notifications

async def critical_operation():
    try:
        result = await do_something_critical()
    except Exception as e:
        # Log + alert
        logger.critical(
            "Critical operation failed",
            json_data={
                "operation": "critical_operation",
                "error": str(e)
            }
        )

        # Notify team via Slack
        await send_alert(
            channel="#alerts",
            message=f"🚨 Critical operation failed: {str(e)}",
            severity="critical"
        )

        raise
```
