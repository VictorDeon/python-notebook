## Structured Logs (JSON)

### ❌ Common Problem:

```python
# ❌ LOW: Unstructured logs
print(f"User {user_id} logged in")  # Don't use print!

logger.info(f"Processing order {order_id} for user {user.email}")
# Hard to parse and search
```

### ✅ Solution with Structured Logs:

```python
from engines.logger import logger

# ✅ Structured log with context
logger.info(
    "User logged in",
    json_data={
        "user_id": user_id,
        "email": user.email,
        "ip_address": request.client.host,
        "user_agent": request.headers.get("user-agent")
    }
)

logger.info(
    "Processing order",
    json_data={
        "order_id": order_id,
        "user_id": user.id,
        "amount": order.total,
        "currency": "BRL",
        "items_count": len(order.items)
    }
)
```

### Output JSON:

```json
{
  "timestamp": "2025-01-22T10:30:45.123Z",
  "level": "INFO",
  "message": "Processing order",
  "order_id": "abc123",
  "user_id": "user456",
  "amount": 199.90,
  "currency": "BRL",
  "items_count": 3,
  "service": "api",
  "environment": "production"
}
```

### Benefits:

- Easy to parse and search
- Indexable in log systems (Elasticsearch, CloudWatch, etc.)
- Efficient queries
