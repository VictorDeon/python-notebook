## Sensitive Data Sanitization

### ❌ Common Problem:

```python
# ❌ CRITICAL: Exposing sensitive data in logs
logger.info(f"Login attempt: {user.email}, password: {password}")

logger.error(f"Payment failed: {payment_data}")
# payment_data may contain card number!
```

### ✅ Solution with Sanitization:

```python
from engines.logger import logger  # Logger already sanitizes automatically

# ✅ Project logger sanitizes automatically
logger.info(
    "Login attempt",
    json_data={
        "email": user.email,  # Will be sanitized if necessary
        # DO NOT log passwords, tokens, or payment data!
    }
)

# For payment data, log only identifiers
logger.error(
    "Payment failed",
    json_data={
        "payment_id": payment.id,
        "user_id": user.id,
        "amount": payment.amount,
        "status": payment.status,
        # DO NOT include: card_number, cvv, etc.
    }
)
```

### Fields that should NEVER be logged:

- Passwords
- Authentication tokens
- API keys
- Credit card numbers
- CVV
- Complete CPF/SSN (use only masked last digits)
