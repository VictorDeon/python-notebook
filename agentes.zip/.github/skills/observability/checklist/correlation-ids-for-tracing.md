## Correlation IDs for Tracing

### ✅ Request ID in All Logs:

```python
from uuid import uuid4
from fastapi import Request
from contextvars import ContextVar

# Context var for request_id
request_id_var: ContextVar[str] = ContextVar('request_id', default='')

@app.middleware("http")
async def add_request_id(request: Request, call_next):
    """Adds request_id to all logs."""
    request_id = request.headers.get('X-Request-ID', str(uuid4()))
    request_id_var.set(request_id)

    response = await call_next(request)
    response.headers['X-Request-ID'] = request_id

    return response

# In code
from engines.logger import logger

logger.info(
    "Processing request",
    json_data={
        "request_id": request_id_var.get(),
        "operation": "create_user"
    }
)
```

#### **Benefits:**
- Track complete request across multiple services
- Correlate logs from same request
- Easier debugging
