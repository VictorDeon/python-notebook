## Exception Tracking

### ✅ Sentry Integration (example):

```python
import sentry_sdk
from sentry_sdk.integrations.fastapi import FastApiIntegration

# Initialization (main.py)
if SENTRY_DSN:  # Environment variable
    sentry_sdk.init(
        dsn=SENTRY_DSN,
        integrations=[FastApiIntegration()],
        environment=ENVIRONMENT,  # "production", "staging", etc.
        traces_sample_rate=0.1,  # 10% of transactions
        release="api@1.0.0"
    )

# Custom exception capture
try:
    result = await risky_operation()
except Exception as e:
    logger.error("Operation failed")
    sentry_sdk.capture_exception(e)
    raise
```
