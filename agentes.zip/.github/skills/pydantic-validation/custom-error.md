## Standard vs Custom Validation Error

### ❌ Standard error (not very useful):

```
ValidationError: 1 validation error for UserDTO
age
  ensure this value is greater than or equal to 18
```

### ✅ Custom error:

```python
from pydantic import ValidationError

try:
    user = UserDTO(email="invalid", age=15)
except ValidationError as e:
    # Format errors for API response
    errors = []
    for error in e.errors():
        errors.append({
            "field": ".".join(str(loc) for loc in error["loc"]),
            "message": _(f"validation.{error['type']}", **error),
            "type": error["type"]
        })

    raise HTTPException(
        status_code=422,
        detail={"errors": errors}
    )
```
