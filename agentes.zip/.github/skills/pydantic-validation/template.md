### [Title] — `file.py:line`

**Category:** Pydantic - Validation

**Location:** `api/users/dtos/user.py:12` (class `CreateUserDTO`)

**Description:**

Fields without proper validation and non-internationalized error messages.

**Evidence:**

```python
class CreateUserDTO(BaseModel):
    email: str  # Accepts any string
    age: int  # No range validation
```

**Impact:**

- Invalid data can be accepted
- Error messages in English only
- Lack of automatic OpenAPI documentation
- **Estimated risk:** Medium - Can lead to validation bugs

**Suggested Solution:**

```python
from pydantic import EmailStr, Field
from fastapi_babel import _

class CreateUserDTO(BaseModel):
    email: EmailStr = Field(
        ...,
        description="Valid user email"
    )
    age: int = Field(
        ...,
        ge=18,
        le=120,
        description="Age between 18 and 120 years"
    )

    @field_validator('age')
    @classmethod
    def validate_age(cls, v: int) -> int:
        if v < 18:
            raise ValueError(_("user.age_must_be_18_or_older"))
        return v
```

**References:**

- [Pydantic v2 Validators](https://docs.pydantic.dev/latest/concepts/validators/)
- [Pydantic Field Types](https://docs.pydantic.dev/latest/api/types/)
