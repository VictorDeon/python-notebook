## ConfigDict for Model Configuration

### ✅ Common Configurations:

```python
from pydantic import BaseModel, ConfigDict, Field

class UserModel(BaseModel):
    email: EmailStr
    name: str
    age: int

    model_config = ConfigDict(
        # Allows creating model from ORM objects (Firestore docs)
        from_attributes=True,

        # Validates assignments after creation
        validate_assignment=True,

        # Freezes model (makes it immutable)
        frozen=False,

        # Allows extra fields not defined
        extra='forbid',  # 'allow', 'ignore', 'forbid'

        # Uses enum values when serializing
        use_enum_values=True,

        # Schema examples for OpenAPI
        json_schema_extra={
            "examples": [
                {
                    "email": "user@example.com",
                    "name": "João Silva",
                    "age": 25
                }
            ]
        }
    )
```
