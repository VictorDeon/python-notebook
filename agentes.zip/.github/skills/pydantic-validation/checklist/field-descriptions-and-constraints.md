## Field Descriptions and Constraints

### ❌ Common Problem:

```python
# ❌ MEDIUM: Fields without proper validation
class UserDTO(BaseModel):
    email: str
    age: int
    name: str
```

#### ✅ Solution:

```python
from pydantic import BaseModel, Field, EmailStr

class UserDTO(BaseModel):
    email: EmailStr = Field(
        ...,
        description="Valid user email address",
        examples=["user@example.com"]
    )
    age: int = Field(
        ...,
        ge=18,
        le=120,
        description="User age (between 18 and 120 years)"
    )
    name: str = Field(
        ...,
        min_length=2,
        max_length=100,
        pattern=r"^[a-zA-ZÀ-ÿ\s]+$",
        description="User's full name"
    )
```

### Benefits:

- Automatic OpenAPI documentation
- Automatic constraint validation
- Clear error messages
