## Custom Field Validators

### ❌ Common Problem:

```python
# ❌ MEDIUM: Complex validation in controller
class UserDTO(BaseModel):
    cpf: str

# Validation done manually in controller
if not validate_cpf(user_data.cpf):
    raise ValueError("Invalid CPF")
```

### ✅ Solution with field_validator (Pydantic v2):

```python
from pydantic import BaseModel, Field, field_validator
from fastapi_babel import _

class UserDTO(BaseModel):
    cpf: str = Field(
        ...,
        pattern=r"^\d{3}\.\d{3}\.\d{3}-\d{2}$",
        description="CPF in format XXX.XXX.XXX-XX"
    )

    @field_validator('cpf')
    @classmethod
    def validate_cpf(cls, v: str) -> str:
        """Validates CPF check digits."""
        # Remove punctuation
        cpf_numbers = v.replace('.', '').replace('-', '')

        if not validate_cpf_digits(cpf_numbers):
            raise ValueError(_("user.invalid_cpf"))

        return v
```

### Benefits:

- Centralized and reusable validation
- Internationalized error messages
- Fast-fail before reaching controller
