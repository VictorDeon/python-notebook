## Enum Validation

### ✅ Correct use of Enums:

```python
from enum import Enum
from pydantic import BaseModel, Field

class UserRole(str, Enum):
    """System user types."""
    ADMIN = "admin"
    USER = "user"
    GUEST = "guest"

class UserDTO(BaseModel):
    role: UserRole = Field(
        default=UserRole.USER,
        description="User role in the system"
    )

# Automatic validation - only enum values are accepted
user = UserDTO(role="admin")  # ✅ OK
user = UserDTO(role="superuser")  # ❌ ValidationError
```
