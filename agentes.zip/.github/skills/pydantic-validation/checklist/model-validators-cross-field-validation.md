## Model Validators (Cross-Field Validation)

### ❌ Common Problem:

```python
# ❌ MEDIUM: Cross-field validation in controller
class DateRangeDTO(BaseModel):
    start_date: datetime
    end_date: datetime

# In controller
if data.end_date <= data.start_date:
    raise ValueError("End date must be after start date")
```

### ✅ Solution with model_validator (Pydantic v2):

```python
from pydantic import BaseModel, model_validator
from datetime import datetime
from fastapi_babel import _

class DateRangeDTO(BaseModel):
    start_date: datetime = Field(..., description="Start date")
    end_date: datetime = Field(..., description="End date")

    @model_validator(mode='after')
    def validate_date_range(self) -> 'DateRangeDTO':
        """Validates that end_date is after start_date."""
        if self.end_date <= self.start_date:
            raise ValueError(_("validation.end_date_must_be_after_start"))

        # Additional validation: maximum range of 1 year
        delta = self.end_date - self.start_date
        if delta.days > 365:
            raise ValueError(_("validation.date_range_max_one_year"))

        return self
```
