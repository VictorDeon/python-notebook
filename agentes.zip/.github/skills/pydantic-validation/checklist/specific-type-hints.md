## Specific Type Hints

### ❌ Common Problem:

```python
# ❌ LOW: Generic types
class ProductDTO(BaseModel):
    url: str  # Accepts any string
    price: float  # Can be negative!
    tags: list  # List of what?
```

### ✅ Solution with specific types:

```python
from pydantic import HttpUrl, PositiveFloat, conlist
from typing import List

class ProductDTO(BaseModel):
    url: HttpUrl = Field(..., description="Valid product URL")
    price: PositiveFloat = Field(
        ...,
        description="Positive price in reais",
        examples=[19.99]
    )
    tags: conlist(str, min_length=1, max_length=10) = Field(
        ...,
        description="Between 1 and 10 tags"
    )
    # Or using Pydantic v2 type hints syntax:
    # tags: List[str] = Field(..., min_length=1, max_length=10)
```

### ✅ Useful Pydantic types:

- `EmailStr` — Valid email
- `HttpUrl` — Valid URL
- `SecretStr` — Sensitive string
- `PositiveInt`, `PositiveFloat` — Positive numbers
- `conint(ge=0, le=100)` — Int with constraints
- `constr(min_length=X, max_length=Y, pattern=r"...")` — String with constraints
- `UUID` — Valid UUID
- `datetime`, `date`, `time` — Dates and times
