## Internationalization of Messages

### ❌ Common Problem:

```python
# ❌ MEDIUM: Hardcoded English messages
@field_validator('age')
@classmethod
def validate_age(cls, v: int) -> int:
    if v < 18:
        raise ValueError("User must be at least 18 years old")
    return v
```

### ✅ Solution with i18n:

```python
from fastapi_babel import _

@field_validator('age')
@classmethod
def validate_age(cls, v: int) -> int:
    if v < 18:
        raise ValueError(_("user.age_must_be_18_or_older"))
    return v
```

### ✅ Required translation files:

`i18n/pt_BR/LC_MESSAGES/messages.po`:
```
msgid "user.age_must_be_18_or_older"
msgstr "Usuário deve ter pelo menos 18 anos"
```

`i18n/en_US/LC_MESSAGES/messages.po`:
```
msgid "user.age_must_be_18_or_older"
msgstr "User must be at least 18 years old"
```
