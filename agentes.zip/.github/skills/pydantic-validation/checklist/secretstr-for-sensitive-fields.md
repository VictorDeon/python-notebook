## SecretStr for Sensitive Fields

### ❌ Common Problem:

```python
# ❌ HIGH: Passwords can be accidentally logged
class LoginDTO(BaseModel):
    email: str
    password: str  # Exposed in logs and tracebacks!

logger.info(f"Login attempt: {login_data}")
# Output: email='user@example.com' password='secret123'
```

### ✅ Solution with SecretStr:

```python
from pydantic import SecretStr, Field

class LoginDTO(BaseModel):
    email: EmailStr
    password: SecretStr = Field(
        ...,
        min_length=8,
        description="User password (minimum 8 characters)"
    )

# To use the value:
password_value = login_data.password.get_secret_value()

logger.info(f"Login attempt: {login_data}")
# Output: email='user@example.com' password='**********'
```
