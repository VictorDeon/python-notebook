---
name: pydantic-validation
description: Data validation with Pydantic v2 is essential to ensure data integrity and security in FastAPI applications. This skill provides practical guidelines for implementing robust validation with appropriate constraints, internationalized error messages, and secure patterns, such as the use of `SecretStr` for sensitive data. Use this skill when reviewing Pydantic DTOs and models, creating new endpoints that process user input, validating application configuration data, or implementing data serialization/deserialization. The importance is **medium**, as inadequate validation can result in bugs, data inconsistency, and potential security vulnerabilities in the system.
---

# Skill: Pydantic Validation

## Objective

Ensure robust and comprehensive data validation using Pydantic v2, with internationalized error messages and appropriate constraints.

## When to Use

- During DTO and Model reviews
- When creating new endpoints that use Pydantic
- When validating user input in endpoints
- When reviewing data serialization and deserialization
- When validating application configurations

## Severity

🟡 **MEDIUM** — Inadequate validation can lead to bugs and inconsistent data

---

## Pydantic v2 - Key Changes

### Migration from v1 to v2

| Pydantic v1 | Pydantic v2 |
|-------------|-------------|
| `@validator` | `@field_validator` |
| `@root_validator` | `@model_validator` |
| `class Config` | `model_config = ConfigDict(...)` |
| `.dict()` | `.model_dump()` |
| `.json()` | `.model_dump_json()` |
| `parse_obj()` | `model_validate()` |

---

## Validation Checklist

* [Field Descriptions and Constraints](./checklist/field-descriptions-and-constraints.md)
* [Custom Field Validators](./checklist/custom-field-validators.md)
* [Model Validators (Cross-Field Validation)](./checklist/model-validators-cross-field-validation.md)
* [Internationalization of Messages](./checklist/internationalization-of-messages.md)
* [SecretStr for Sensitive Fields](./checklist/secretstr-for-sensitive-fields.md)
* [ConfigDict for Model Configuration](./checklist/configdict-for-model-configuration.md)
* [Specific Type Hints](./checklist/specific-type-hints.md)
* [Enum Validation](./checklist/enum-validation.md)

---

## Common Patterns

* [Base DTO with Timestamps](./patterns/base-dto-with-timestamps.md)
* [Creation DTO vs Response Model](./patterns/creation-dto-vs-response-model.md)
* [Partial DTOs for Updates](./patterns/partial-dtos-for-updates.md)

---

## Custom Error Messages

You can find custom error messages [here](./custom-error.md).

---

## Finding Template

You can find the complete pydantic validation skill template [here](./template.md).

---

## References

- [Pydantic v2 Documentation](https://docs.pydantic.dev/latest/)
- [Pydantic Migration Guide (v1 to v2)](https://docs.pydantic.dev/latest/migration/)
- [Field Types](https://docs.pydantic.dev/latest/api/types/)
- [Validators](https://docs.pydantic.dev/latest/concepts/validators/)
- [fastapi_babel for i18n](https://github.com/MrNaif2018/fastapi-babel)
