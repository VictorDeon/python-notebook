## Pattern: Partial DTOs for Updates

```python
from typing import Optional

class UpdateUserDTO(BaseModel):
    """DTO for updates - all fields optional."""
    email: Optional[EmailStr] = None
    name: Optional[str] = Field(None, min_length=2, max_length=100)
    age: Optional[int] = Field(None, ge=18, le=120)

    @model_validator(mode='after')
    def check_at_least_one_field(self) -> 'UpdateUserDTO':
        """Validates that at least one field was provided."""
        if not any([self.email, self.name, self.age]):
            raise ValueError(_("validation.at_least_one_field_required"))
        return self
```
