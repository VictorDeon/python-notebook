## Pattern: Creation DTO vs Response Model

```python
# DTO for creation (input)
class CreateUserDTO(BaseModel):
    email: EmailStr
    password: SecretStr = Field(..., min_length=8)
    name: str = Field(..., min_length=2, max_length=100)

# Model for response (output)
class UserModel(BaseModel):
    id: str
    email: EmailStr
    name: str
    created_at: datetime
    # No password!

    model_config = ConfigDict(from_attributes=True)
```
