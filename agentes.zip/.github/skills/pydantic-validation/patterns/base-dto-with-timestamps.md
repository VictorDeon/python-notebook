## Pattern: Base DTO with Timestamps

```python
from datetime import datetime
from pydantic import BaseModel, Field

class TimestampedDTO(BaseModel):
    """Base DTO with automatic timestamps."""
    created_at: datetime = Field(
        default_factory=datetime.now,
        description="Creation date"
    )
    updated_at: datetime = Field(
        default_factory=datetime.now,
        description="Last update date"
    )
```
