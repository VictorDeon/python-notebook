# Check Document Existence

## Use Case

Check if a document exists without retrieving its data (more efficient).

## Pattern

```python
from engines.database import DatabaseEngine

async def user_exists(db: DatabaseEngine, user_id: str) -> bool:
    """
    Checks if a user document exists.

    Args:
        user_id: The user document ID

    Returns:
        bool: True if document exists, False otherwise
    """

    exists = await db.exists(f"users/{user_id}")
    return exists
```

## Example

```python
# Check if user exists
if await db.exists("users/abc123"):
    print("User found!")
else:
    print("User not found")

# Use in validation
async def validate_user_exists(db: DatabaseEngine, user_id: str):
    if not await db.exists(f"users/{user_id}"):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=_("Usuário não encontrado")
        )
```

## Key Points

- ✅ More efficient than `retrieve()` when you only need existence check
- ✅ Returns `bool` (never throws 404)
- ✅ Can be used in transactions
- ✅ Useful for validation logic

## Within Transaction

```python
@db.transaction()
async def check_and_create(transaction: AsyncTransaction, user_id: str, data: dict):
    if not await db.exists(f"users/{user_id}", transaction=transaction):
        db.create_by_transaction(f"users/{user_id}", data, transaction)
        return True
    return False
```

## Performance Comparison

```python
# ❌ Less efficient: Fetches entire document
try:
    user = await db.retrieve("users/abc123")
    exists = True
except HTTPException:
    exists = False

# ✅ More efficient: Only checks existence
exists = await db.exists("users/abc123")
```

## Related

- [Retrieve Document](./retrieve-document.md)
- [Create with Specific ID](./create-specific-id.md)
