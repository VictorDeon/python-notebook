# Count Documents in Firestore Collection

## Descrição

O método `count()` é utilizado para contar o número de documentos em uma coleção do Firestore de forma assíncrona. Ele é útil para obter rapidamente o tamanho de uma coleção sem precisar carregar todos os documentos na memória.

---

## Assinatura
```python
async def count(self, path: str, timeout: float = FIRESTORE_READ_TIMEOUT) -> int:
```

---

## Parâmetros
- **path** (`str`): O caminho da coleção no Firestore (exemplo: `users`).
- **timeout** (`float`, opcional): Tempo limite para a operação em segundos. O valor padrão é `FIRESTORE_READ_TIMEOUT`.

---

## Retorno
- **int**: O número de documentos na coleção especificada.

---

## Exceções
- **HTTPException**: Lançada em caso de erro de comunicação com o Firestore.

---

## Exemplo de Uso
```python
from engines.database import DatabaseEngine

# Supondo que `db` seja uma instância de `AsyncClient`
database_engine = DatabaseEngine(db=db)

# Contar documentos na coleção "users"
count = await database_engine.count("users")
print(f"Número de usuários: {count}")
```

---

## Notas
- Este método utiliza um contexto de tratamento de exceções para capturar e registrar erros de comunicação com o Firestore.
- É importante garantir que o caminho fornecido seja válido e corresponda a uma coleção existente no Firestore.
