# Handling Batch Results

## Use Case

Properly interpret and handle results from batch operations (create, update, delete).

## BatchResult Structure

```python
from engines.database import BatchResult

class BatchResult:
    total_attempted: int    # Total number of documents in the batch
    total_succeeded: int    # Successfully processed documents
    total_failed: int       # Failed documents
```

## Patterns

### Basic Result Handling

```python
result = await db.create_by_batch("users", user_data)

# Check if all succeeded
if result.total_failed == 0:
    logger.info(f"✅ All {result.total_succeeded} documents processed successfully")
else:
    logger.warning(f"⚠️ {result.total_failed}/{result.total_attempted} documents failed")
```

### Complete Success Check

```python
async def create_with_success_check(
    db: DatabaseEngine,
    collection: str,
    data: list[dict]
) -> BatchResult:
    """Creates documents and ensures all succeeded."""

    result = await db.create_by_batch(collection, data)

    if result.total_failed > 0:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=_(f"Falha ao criar {result.total_failed} documentos")
        )

    return result
```

### Partial Failure Handling

```python
async def tolerant_batch_create(
    db: DatabaseEngine,
    collection: str,
    data: list[dict],
    min_success_rate: float = 0.95
) -> BatchResult:
    """Creates documents with tolerance for partial failures."""

    result = await db.create_by_batch(collection, data)

    # Calculate success rate
    success_rate = result.total_succeeded / result.total_attempted if result.total_attempted > 0 else 0

    # Check if acceptable
    if success_rate < min_success_rate:
        logger.error(
            f"Batch success rate too low: {success_rate:.2%}",
            json_data={
                "attempted": result.total_attempted,
                "succeeded": result.total_succeeded,
                "failed": result.total_failed,
                "required_rate": min_success_rate
            }
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=_(f"Taxa de sucesso muito baixa: {success_rate:.1%}")
        )

    # Log warning if some failed
    if result.total_failed > 0:
        logger.warning(
            f"{result.total_failed} documents failed, but within acceptable threshold"
        )

    return result
```

## Common Scenarios

### Scenario 1: All Succeeded

```python
result = BatchResult(
    total_attempted=100,
    total_succeeded=100,
    total_failed=0
)

# ✅ Perfect - all operations succeeded
```

### Scenario 2: Partial Failure

```python
result = BatchResult(
    total_attempted=100,
    total_succeeded=98,
    total_failed=2
)

# ⚠️ Mostly successful, but 2 documents failed
# Common causes: duplicate IDs, validation errors, permission issues
```

### Scenario 3: Complete Failure

```python
result = BatchResult(
    total_attempted=100,
    total_succeeded=0,
    total_failed=100
)

# ❌ Complete failure - usually indicates:
# - Network issues
# - Permission errors
# - Invalid collection path
```

### Scenario 4: Empty Batch

```python
result = BatchResult(
    total_attempted=0,
    total_succeeded=0,
    total_failed=0
)

# ℹ️ No operations attempted (empty input)
```

## Response Formatting for APIs

### Success Response

```python
@router.post("/users/batch")
async def create_users_batch(
    users: list[UserCreate],
    db: DatabaseEngine = Depends(get_db)
):
    """Creates multiple users in batch."""

    # Convert to dict
    user_data = [user.model_dump() for user in users]

    # Execute batch
    result = await db.create_by_batch("users", user_data)

    # Return formatted response
    return {
        "success": result.total_failed == 0,
        "summary": {
            "total": result.total_attempted,
            "succeeded": result.total_succeeded,
            "failed": result.total_failed
        },
        "message": _(
            f"Criados {result.total_succeeded} de {result.total_attempted} usuários"
        )
    }
```

### Detailed Response with Warnings

```python
@router.delete("/users/batch")
async def delete_users_batch(
    user_ids: list[str],
    db: DatabaseEngine = Depends(get_db)
):
    """Deletes multiple users in batch."""

    # Prepare deletes
    deletes = [{"id": user_id} for user_id in user_ids]

    # Execute batch
    result = await db.delete_by_batch("users", deletes)

    # Build response
    response = {
        "summary": {
            "attempted": result.total_attempted,
            "succeeded": result.total_succeeded,
            "failed": result.total_failed
        }
    }

    # Add warnings if needed
    if result.total_failed > 0:
        response["warning"] = _(
            f"{result.total_failed} usuários não puderam ser deletados"
        )

    # Set appropriate status code
    status_code = (
        status.HTTP_200_OK if result.total_failed == 0
        else status.HTTP_207_MULTI_STATUS  # Partial success
    )

    return JSONResponse(content=response, status_code=status_code)
```

## Logging Best Practices

### Structured Logging

```python
async def logged_batch_operation(
    db: DatabaseEngine,
    collection: str,
    data: list[dict],
    operation: str  # "create", "update", "delete"
) -> BatchResult:
    """Executes batch operation with comprehensive logging."""

    logger.info(
        f"Starting batch {operation}",
        json_data={
            "collection": collection,
            "document_count": len(data),
            "operation": operation
        }
    )

    start_time = time.time()

    # Execute appropriate batch operation
    if operation == "create":
        result = await db.create_by_batch(collection, data)
    elif operation == "update":
        result = await db.update_by_batch(collection, data)
    elif operation == "delete":
        result = await db.delete_by_batch(collection, data)
    else:
        raise ValueError(f"Invalid operation: {operation}")

    duration = time.time() - start_time

    # Log results
    log_level = "info" if result.total_failed == 0 else "warning"
    getattr(logger, log_level)(
        f"Batch {operation} completed",
        json_data={
            "collection": collection,
            "operation": operation,
            "attempted": result.total_attempted,
            "succeeded": result.total_succeeded,
            "failed": result.total_failed,
            "success_rate": f"{(result.total_succeeded / result.total_attempted * 100):.1f}%",
            "duration_seconds": round(duration, 2),
            "throughput_per_second": round(result.total_succeeded / duration, 2)
        }
    )

    return result
```

### Failure Investigation Logging

```python
async def batch_with_failure_tracking(
    db: DatabaseEngine,
    collection: str,
    data: list[dict]
) -> BatchResult:
    """Batch operation with failure tracking for debugging."""

    # Log input sample
    logger.debug(
        "Batch input sample",
        json_data={
            "collection": collection,
            "total_documents": len(data),
            "sample": data[:3] if len(data) > 0 else []
        }
    )

    result = await db.create_by_batch(collection, data)

    # If failures, log details for investigation
    if result.total_failed > 0:
        logger.error(
            "Batch operation had failures - investigate",
            json_data={
                "collection": collection,
                "failed_count": result.total_failed,
                "succeeded_count": result.total_succeeded,
                "possible_causes": [
                    "Duplicate IDs",
                    "Missing required fields",
                    "Permission errors",
                    "Network issues",
                    "Firestore quota exceeded"
                ]
            }
        )

    return result
```

## Metrics and Monitoring

### Calculate Success Rate

```python
def calculate_success_rate(result: BatchResult) -> float:
    """Calculates percentage of successful operations."""
    if result.total_attempted == 0:
        return 0.0
    return (result.total_succeeded / result.total_attempted) * 100

# Usage
result = await db.create_by_batch("users", data)
success_rate = calculate_success_rate(result)

logger.info(f"Batch success rate: {success_rate:.1f}%")
```

### Performance Metrics

```python
async def batch_with_metrics(
    db: DatabaseEngine,
    collection: str,
    data: list[dict]
) -> tuple[BatchResult, dict]:
    """Executes batch and returns performance metrics."""

    start_time = time.time()

    result = await db.create_by_batch(collection, data)

    duration = time.time() - start_time

    metrics = {
        "duration_seconds": round(duration, 2),
        "throughput_per_second": round(result.total_succeeded / duration, 2) if duration > 0 else 0,
        "success_rate_percent": round((result.total_succeeded / result.total_attempted * 100), 2) if result.total_attempted > 0 else 0,
        "avg_time_per_doc_ms": round((duration / result.total_attempted * 1000), 2) if result.total_attempted > 0 else 0
    }

    return result, metrics

# Usage
result, metrics = await batch_with_metrics(db, "users", user_data)
logger.info("Batch metrics", json_data=metrics)
```

## Error Recovery Strategies

### Retry Failed Portion

While DatabaseEngine doesn't track which specific documents failed, you can implement your own tracking:

```python
async def batch_create_with_tracking(
    db: DatabaseEngine,
    collection: str,
    data: list[dict]
) -> dict:
    """Creates documents and tracks which ones succeeded."""

    # Add tracking ID to each document
    tracked_data = []
    for i, item in enumerate(data):
        item_with_tracking = item.copy()
        item_with_tracking["_tracking_id"] = i
        tracked_data.append(item_with_tracking)

    result = await db.create_by_batch(collection, tracked_data)

    return {
        "result": result,
        "total_processed": result.total_succeeded,
        "note": "Check database for _tracking_id to identify succeeded documents"
    }
```

## Best Practices

### ✅ DO

```python
# ✅ Always check results
result = await db.create_by_batch("users", data)
if result.total_failed > 0:
    handle_failures(result)

# ✅ Log appropriately
logger.info(f"Batch completed: {result.total_succeeded}/{result.total_attempted}")

# ✅ Return meaningful responses
return {
    "success": result.total_failed == 0,
    "processed": result.total_succeeded,
    "failed": result.total_failed
}
```

### ❌ DON'T

```python
# ❌ Don't ignore results
await db.create_by_batch("users", data)
# No checking of result ❌

# ❌ Don't assume all succeeded
result = await db.create_by_batch("users", data)
return {"created": len(data)}  # Wrong if some failed! ❌

# ❌ Don't fail silently
result = await db.create_by_batch("users", data)
# No logging or error handling ❌
```

## Related

- [Batch Create](./batch-create.md)
- [Batch Update](./batch-update.md)
- [Batch Delete](./batch-delete.md)
- [Observability Skill](../../observability/SKILL.md)
