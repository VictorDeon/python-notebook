# Update Document in Transaction

## Use Case

Update an existing document within a transaction to ensure atomicity with other operations.

## Pattern

```python
from engines.database import DatabaseEngine
from google.cloud.firestore_v1 import AsyncTransaction

async def update_user_points_atomically(
    db: DatabaseEngine,
    user_id: str,
    points_to_add: int
) -> int:
    """
    Atomically updates user points.

    Returns:
        int: New points total
    """

    @db.transaction()
    async def _update(transaction: AsyncTransaction) -> int:
        # Read current value
        user = await db.retrieve(f"users/{user_id}", transaction=transaction)

        # Calculate new value
        new_points = user.get("points", 0) + points_to_add

        # Update in transaction
        db.update_by_transaction(
            path=f"users/{user_id}",
            data={"points": new_points, "updated_at": int(time.time())},
            transaction=transaction
        )

        return new_points

    return await _update()
```

## Method Signatures

### Standard Update

```python
def update_by_transaction(
    path: str,
    data: dict,
    transaction: AsyncTransaction,
    merge: bool = False
) -> str:
    """
    Updates document in transaction.

    Args:
        path: Complete document path (e.g., "users/abc123")
        data: Fields to update
        transaction: Active transaction
        merge: If True, creates document if doesn't exist

    Returns:
        str: Document ID
    """
```

## Examples

### Update Single Field

```python
@db.transaction()
async def mark_notification_read(transaction: AsyncTransaction, notification_id: str):
    """Marks notification as read."""

    db.update_by_transaction(
        f"notifications/{notification_id}",
        {"read": True, "read_at": int(time.time())},
        transaction
    )
```

### Update with Current Value

```python
@db.transaction()
async def increment_view_count(transaction: AsyncTransaction, post_id: str):
    """Increments post view count."""

    # Read current count
    post = await db.retrieve(f"posts/{post_id}", transaction=transaction)

    # Increment
    new_views = post.get("views", 0) + 1

    # Update
    db.update_by_transaction(
        f"posts/{post_id}",
        {"views": new_views, "updated_at": int(time.time())},
        transaction
    )
```

### Update Multiple Documents

```python
@db.transaction()
async def process_order(transaction: AsyncTransaction, order_id: str):
    """Processes order and updates related documents."""

    # Get order details
    order = await db.retrieve(f"orders/{order_id}", transaction=transaction)

    # Update order status
    db.update_by_transaction(
        f"orders/{order_id}",
        {"status": "processing", "processed_at": int(time.time())},
        transaction
    )

    # Update user's order count
    user = await db.retrieve(f"users/{order['user_id']}", transaction=transaction)
    db.update_by_transaction(
        f"users/{order['user_id']}",
        {"total_orders": user.get("total_orders", 0) + 1},
        transaction
    )
```

### Update with Merge (Upsert)

```python
@db.transaction()
async def save_user_preferences(
    transaction: AsyncTransaction,
    user_id: str,
    preferences: dict
):
    """Saves user preferences, creating if needed."""

    db.update_by_transaction(
        f"user_preferences/{user_id}",
        preferences,
        transaction,
        merge=True  # Creates if doesn't exist
    )
```

## Key Points

- ✅ Synchronous method (no `await`)
- ✅ Must be called within `@db.transaction()` decorator
- ✅ Requires **document path** (not collection path)
- ✅ Only updates specified fields (partial update)
- ✅ Returns document ID immediately
- ✅ Use `merge=True` for upsert behavior
- ⚠️ Throws error if document doesn't exist (unless `merge=True`)

## Update Behavior

### Standard Update (merge=False)

```python
# Before: { "id": "user_1", "name": "John", "email": "john@example.com", "points": 100 }

db.update_by_transaction(
    "users/user_1",
    {"points": 150},
    transaction
)

# After: { "id": "user_1", "name": "John", "email": "john@example.com", "points": 150 }
# Only 'points' changed
```

### Merge Update (merge=True)

```python
# Document doesn't exist yet

db.update_by_transaction(
    "user_preferences/user_1",
    {"theme": "dark", "language": "en"},
    transaction,
    merge=True
)

# Creates: { "id": "user_preferences/user_1", "theme": "dark", "language": "en" }
```

## Complete Transaction Examples

### Transfer Between Accounts

```python
async def transfer_balance(
    db: DatabaseEngine,
    from_id: str,
    to_id: str,
    amount: float
) -> None:
    """Transfers balance atomically."""

    @db.transaction()
    async def _transfer(transaction: AsyncTransaction):
        # Read both accounts
        from_acc = await db.retrieve(f"accounts/{from_id}", transaction=transaction)
        to_acc = await db.retrieve(f"accounts/{to_id}", transaction=transaction)

        # Validate
        if from_acc["balance"] < amount:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=_("Saldo insuficiente")
            )

        # Update both
        db.update_by_transaction(
            f"accounts/{from_id}",
            {"balance": from_acc["balance"] - amount},
            transaction
        )

        db.update_by_transaction(
            f"accounts/{to_id}",
            {"balance": to_acc["balance"] + amount},
            transaction
        )

    await _transfer()
```

### Conditional Update

```python
async def update_if_status(
    db: DatabaseEngine,
    order_id: str,
    expected_status: str,
    new_data: dict
) -> bool:
    """Updates order only if status matches."""

    @db.transaction()
    async def _conditional_update(transaction: AsyncTransaction) -> bool:
        # Read current state
        order = await db.retrieve(f"orders/{order_id}", transaction=transaction)

        # Check condition
        if order["status"] != expected_status:
            return False

        # Update
        db.update_by_transaction(
            f"orders/{order_id}",
            new_data,
            transaction
        )

        return True

    return await _conditional_update()
```

### Update with Nested Fields

```python
@db.transaction()
async def update_nested_fields(transaction: AsyncTransaction, user_id: str):
    """Updates nested object fields."""

    db.update_by_transaction(
        f"users/{user_id}",
        {
            "address.city": "New York",
            "address.country": "USA",
            "address.zip_code": "10001"
        },
        transaction
    )
```

## Error Handling

```python
@db.transaction()
async def safe_update(transaction: AsyncTransaction, doc_id: str, data: dict):
    """Updates document with validation."""

    try:
        # Check if document exists
        if not await db.exists(f"documents/{doc_id}", transaction=transaction):
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=_("Documento não encontrado")
            )

        # Update
        db.update_by_transaction(f"documents/{doc_id}", data, transaction)

    except HTTPException:
        # Re-raise (transaction rolls back)
        raise
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        raise
```

## Performance Considerations

### ✅ Good Practice

```python
@db.transaction()
async def efficient_update(transaction: AsyncTransaction, user_id: str):
    # Read once
    user = await db.retrieve(f"users/{user_id}", transaction=transaction)

    # Calculate all changes
    new_points = user["points"] + 10
    new_level = calculate_level(new_points)

    # Single update with all changes
    db.update_by_transaction(
        f"users/{user_id}",
        {
            "points": new_points,
            "level": new_level,
            "updated_at": int(time.time())
        },
        transaction
    )
```

### ❌ Bad Practice

```python
@db.transaction()
async def inefficient_update(transaction: AsyncTransaction, user_id: str):
    # Multiple separate updates (still atomic, but verbose)
    user = await db.retrieve(f"users/{user_id}", transaction=transaction)

    db.update_by_transaction(f"users/{user_id}", {"points": user["points"] + 10}, transaction)
    db.update_by_transaction(f"users/{user_id}", {"level": 5}, transaction)
    db.update_by_transaction(f"users/{user_id}", {"updated_at": int(time.time())}, transaction)
```

## Related

- [Update Existing Fields](./update-fields.md)
- [Merge New Fields](./update-merge.md)
- [Transaction Read-Write](./transaction-read-write.md)
- [Create in Transaction](./create-transaction.md)
- [Delete in Transaction](./delete-transaction.md)
