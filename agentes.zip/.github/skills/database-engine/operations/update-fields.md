# Update Existing Fields

## Use Case

Update specific fields in an existing document without affecting other fields.

## Pattern

```python
from engines.database import DatabaseEngine

async def update_user_email(db: DatabaseEngine, user_id: str, new_email: str) -> str:
    """
    Updates user's email address.

    Args:
        user_id: The user document ID
        new_email: New email address

    Returns:
        str: The document ID

    Raises:
        HTTPException 404: User not found
    """

    doc_id = await db.update(
        path=f"users/{user_id}",
        data={"email": new_email, "updated_at": int(time.time())}
    )

    return doc_id
```

## Example

```python
# Before update:
# { "id": "abc123", "name": "John", "email": "old@example.com", "points": 100 }

await db.update("users/abc123", {"email": "new@example.com"})

# After update:
# { "id": "abc123", "name": "John", "email": "new@example.com", "points": 100 }
# Only 'email' changed, other fields remain unchanged
```

## Key Points

- ✅ Use **document path** (e.g., `"users/abc123"`)
- ✅ Only specified fields are updated
- ✅ Other fields remain unchanged
- ✅ Throws `HTTPException 404` if document doesn't exist
- ✅ Returns document ID on success
- ⚠️ Cannot be used on non-existent documents (use `create()` instead)

## Multiple Fields

```python
# Update multiple fields at once
await db.update(
    f"users/{user_id}",
    {
        "email": "new@example.com",
        "name": "John Smith",
        "updated_at": int(time.time())
    }
)
```

## Nested Fields

```python
# Update nested field using dot notation
await db.update(
    f"users/{user_id}",
    {
        "address.city": "New York",
        "address.country": "USA"
    }
)
```

## Within Transaction

```python
from google.cloud.firestore_v1 import AsyncTransaction

@db.transaction()
async def update_in_transaction(transaction: AsyncTransaction, user_id: str):
    # Read current value
    user = await db.retrieve(f"users/{user_id}", transaction=transaction)

    # Calculate new value
    new_points = user["points"] + 10

    # Update in transaction
    db.update_by_transaction(
        path=f"users/{user_id}",
        data={"points": new_points},
        transaction=transaction
    )

await update_in_transaction(user_id="abc123")
```

## Related

- [Merge New Fields](./update-merge.md)
- [Update in Transaction](./update-transaction.md)
- [Batch Update](./batch-update.md)
