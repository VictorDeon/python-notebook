# Batch Create Operation

## Use Case

Create multiple documents efficiently in a single batch operation.

## Pattern

```python
from engines.database import DatabaseEngine, BatchResult

async def create_products_batch(
    db: DatabaseEngine,
    products: list[dict]
) -> BatchResult:
    """
    Creates multiple products in batch.

    Args:
        products: List of product data dictionaries

    Returns:
        BatchResult: Summary of batch operation
    """

    result = await db.create_by_batch(
        collection="products",
        data=products
    )

    return result
```

## Examples

### Basic Batch Create

```python
# Prepare data
products = [
    {"name": "Product A", "price": 29.99, "stock": 100},
    {"name": "Product B", "price": 49.99, "stock": 50},
    {"name": "Product C", "price": 19.99, "stock": 200},
]

# Create in batch
result = await db.create_by_batch("products", products)

print(f"Attempted: {result.total_attempted}")
print(f"Succeeded: {result.total_succeeded}")
print(f"Failed: {result.total_failed}")
```

### Import from CSV

```python
import csv

async def import_users_from_csv(db: DatabaseEngine, csv_path: str) -> BatchResult:
    """Imports users from CSV file."""

    users = []
    with open(csv_path, 'r') as file:
        reader = csv.DictReader(file)
        for row in reader:
            users.append({
                "name": row["name"],
                "email": row["email"],
                "created_at": int(time.time())
            })

    # Create all users in batch
    result = await db.create_by_batch("users", users)

    logger.info(f"Imported {result.total_succeeded}/{result.total_attempted} users")

    return result
```

### Bulk User Registration

```python
async def register_multiple_users(
    db: DatabaseEngine,
    registrations: list[dict]
) -> BatchResult:
    """Registers multiple users at once."""

    # Prepare user documents
    users_data = []
    for reg in registrations:
        users_data.append({
            "name": reg["name"],
            "email": reg["email"],
            "status": "pending",
            "created_at": int(time.time()),
            "metadata": {}
        })

    # Batch create
    result = await db.create_by_batch("users", users_data)

    # Handle partial failures
    if result.total_failed > 0:
        logger.warning(f"{result.total_failed} users failed to register")

    return result
```

## BatchResult Structure

```python
class BatchResult:
    total_attempted: int   # Total documents attempted
    total_succeeded: int   # Successfully created documents
    total_failed: int      # Failed documents
```

### Example Response

```python
result = await db.create_by_batch("users", users_data)

# BatchResult(
#     total_attempted=100,
#     total_succeeded=98,
#     total_failed=2
# )
```

## Key Points

- ✅ Efficient for creating 10+ documents
- ✅ Automatically chunks requests (450 docs per chunk)
- ✅ Built-in retry logic for transient failures
- ✅ IDs are auto-generated for each document
- ✅ Documents are created with `"id"` field
- ⚠️ Partial failures possible (check `total_failed`)
- ⚠️ Not atomic (unlike transactions)

## Automatic Chunking

DatabaseEngine automatically splits large batches:

```python
# Create 2000 documents
large_batch = [{"name": f"Doc {i}"} for i in range(2000)]

# Automatically split into chunks of 450
result = await db.create_by_batch("documents", large_batch)

# Chunks: [450, 450, 450, 450, 200]
# Each chunk is sent separately with retries
```

## Error Handling

```python
async def create_with_error_handling(db: DatabaseEngine, data: list[dict]):
    """Creates documents with comprehensive error handling."""

    try:
        result = await db.create_by_batch("collection", data)

        # Check for partial failures
        if result.total_failed > 0:
            logger.warning(
                f"Partial batch failure",
                json_data={
                    "attempted": result.total_attempted,
                    "succeeded": result.total_succeeded,
                    "failed": result.total_failed
                }
            )

        # Check if completely failed
        if result.total_succeeded == 0:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=_("Falha ao criar documentos")
            )

        return result

    except HTTPException as e:
        # DatabaseEngine errors (network, permissions, etc.)
        logger.error(f"Batch create failed: {e.detail}")
        raise
```

## Performance Comparison

```python
# ❌ BAD: Loop create (very slow for many documents)
for item in items:  # 100 items
    await db.create("collection", item)
# Time: ~10 seconds (100 network calls)

# ✅ GOOD: Batch create
result = await db.create_by_batch("collection", items)
# Time: ~1 second (3 network calls with chunking)
```

## When to Use

### ✅ Use Batch Create When:
- Creating 10+ documents at once
- Importing data from external sources
- Bulk user registration
- Initial data seeding
- Background data processing

### ❌ Use Regular Create When:
- Creating 1-5 documents
- Documents need individual validation
- Need atomic guarantee (use transactions instead)
- Creating documents with specific IDs

## Monitoring Batch Operations

```python
async def monitored_batch_create(
    db: DatabaseEngine,
    collection: str,
    data: list[dict]
) -> BatchResult:
    """Creates documents with detailed monitoring."""

    logger.info(f"Starting batch create: {len(data)} documents", json_data={
        "collection": collection,
        "document_count": len(data)
    })

    start_time = time.time()

    try:
        result = await db.create_by_batch(collection, data)

        duration = time.time() - start_time

        logger.info("Batch create completed", json_data={
            "collection": collection,
            "attempted": result.total_attempted,
            "succeeded": result.total_succeeded,
            "failed": result.total_failed,
            "duration_seconds": round(duration, 2),
            "docs_per_second": round(result.total_succeeded / duration, 2)
        })

        return result

    except Exception as e:
        logger.error(f"Batch create failed: {e}")
        raise
```

## Best Practices

### ✅ DO

```python
# ✅ Validate data before batch
validated_data = [item for item in data if validate(item)]
result = await db.create_by_batch("collection", validated_data)

# ✅ Check results
if result.total_failed > 0:
    handle_partial_failure(result)

# ✅ Use for bulk operations
result = await db.create_by_batch("logs", log_entries)
```

### ❌ DON'T

```python
# ❌ Don't use for small batches
if len(items) < 5:
    result = await db.create_by_batch("collection", items)  # Overkill!

# ❌ Don't ignore failures
result = await db.create_by_batch("collection", data)
# Not checking result.total_failed ❌

# ❌ Don't use when you need atomicity
result = await db.create_by_batch("orders", orders)  # Should use transaction!
```

## Related

- [Batch Update](./batch-update.md)
- [Batch Delete](./batch-delete.md)
- [Handling Batch Results](./batch-results.md)
- [Create with Auto ID](./create-auto-id.md)
