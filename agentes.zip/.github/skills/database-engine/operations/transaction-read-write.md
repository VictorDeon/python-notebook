# Transaction Read-Modify-Write Pattern

## Use Case

The read-modify-write pattern ensures that updates based on current values are atomic and consistent.

## Pattern

```python
from engines.database import DatabaseEngine
from google.cloud.firestore_v1 import AsyncTransaction

async def increment_user_points(
    db: DatabaseEngine,
    user_id: str,
    points_to_add: int
) -> int:
    """
    Atomically increments user points.

    Args:
        user_id: User document ID
        points_to_add: Points to add to current total

    Returns:
        int: New points total
    """

    @db.transaction()
    async def _increment(transaction: AsyncTransaction) -> int:
        # READ: Get current value
        user = await db.retrieve(f"users/{user_id}", transaction=transaction)
        current_points = user.get("points", 0)

        # MODIFY: Calculate new value
        new_points = current_points + points_to_add

        # WRITE: Save new value
        db.update_by_transaction(
            path=f"users/{user_id}",
            data={"points": new_points, "updated_at": int(time.time())},
            transaction=transaction
        )

        return new_points

    # Execute and return result
    return await _increment()
```

## Why Use Transactions for Read-Modify-Write?

### ❌ Without Transaction (Race Condition)

```python
# ❌ WRONG: Race condition possible
async def increment_points_unsafe(db: DatabaseEngine, user_id: str, points: int):
    # User A reads: points = 100
    user = await db.retrieve(f"users/{user_id}")

    # Meanwhile, User B reads: points = 100
    # User B calculates: 100 + 50 = 150
    # User B writes: points = 150

    # User A calculates: 100 + 20 = 120
    # User A writes: points = 120  ❌ Overwrites User B's update!

    new_points = user["points"] + points
    await db.update(f"users/{user_id}", {"points": new_points})
```

**Result**: User B's update is lost! (Lost Update Problem)

### ✅ With Transaction (Atomic)

```python
# ✅ CORRECT: Atomic operation
@db.transaction()
async def increment_points_safe(transaction: AsyncTransaction, user_id: str, points: int):
    user = await db.retrieve(f"users/{user_id}", transaction=transaction)
    new_points = user["points"] + points
    db.update_by_transaction(f"users/{user_id}", {"points": new_points}, transaction)

await increment_points_safe(user_id="123", points=20)
```

**Result**: Updates are serialized. If conflict occurs, transaction automatically retries.

## Common Patterns

### Counter Increment

```python
async def increment_counter(
    db: DatabaseEngine,
    counter_name: str,
    increment_by: int = 1
) -> int:
    """Atomically increments a counter."""

    @db.transaction()
    async def _increment(transaction: AsyncTransaction):
        counter = await db.retrieve(f"counters/{counter_name}", transaction=transaction)
        new_value = counter["value"] + increment_by

        db.update_by_transaction(
            f"counters/{counter_name}",
            {"value": new_value, "updated_at": int(time.time())},
            transaction
        )

        return new_value

    return await _increment()

# Usage
new_total = await increment_counter(db, "page_views", increment_by=1)
```

### Stock Management

```python
async def reserve_product(
    db: DatabaseEngine,
    product_id: str,
    quantity: int
) -> bool:
    """
    Reserves product stock atomically.

    Returns:
        bool: True if reservation successful, False if insufficient stock
    """

    @db.transaction()
    async def _reserve(transaction: AsyncTransaction):
        # Read current stock
        product = await db.retrieve(f"products/{product_id}", transaction=transaction)
        current_stock = product.get("stock", 0)

        # Check availability
        if current_stock < quantity:
            return False

        # Decrement stock
        new_stock = current_stock - quantity
        db.update_by_transaction(
            f"products/{product_id}",
            {
                "stock": new_stock,
                "reserved": product.get("reserved", 0) + quantity,
                "updated_at": int(time.time())
            },
            transaction
        )

        return True

    return await _reserve()

# Usage
if await reserve_product(db, "prod_123", quantity=5):
    print("Reservation successful")
else:
    print("Insufficient stock")
```

### Transfer Between Documents

```python
async def transfer_balance(
    db: DatabaseEngine,
    from_account_id: str,
    to_account_id: str,
    amount: float
) -> None:
    """Transfers balance between accounts atomically."""

    @db.transaction()
    async def _transfer(transaction: AsyncTransaction):
        # Read both accounts
        from_account = await db.retrieve(f"accounts/{from_account_id}", transaction=transaction)
        to_account = await db.retrieve(f"accounts/{to_account_id}", transaction=transaction)

        # Validate balance
        if from_account["balance"] < amount:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=_("Saldo insuficiente")
            )

        # Calculate new balances
        from_balance = from_account["balance"] - amount
        to_balance = to_account["balance"] + amount

        # Update both accounts
        db.update_by_transaction(
            f"accounts/{from_account_id}",
            {"balance": from_balance, "updated_at": int(time.time())},
            transaction
        )

        db.update_by_transaction(
            f"accounts/{to_account_id}",
            {"balance": to_balance, "updated_at": int(time.time())},
            transaction
        )

        # Create transaction record
        db.create_by_transaction(
            "transactions",
            {
                "from_account": from_account_id,
                "to_account": to_account_id,
                "amount": amount,
                "timestamp": int(time.time())
            },
            transaction
        )

    await _transfer()
```

### Conditional Updates

```python
async def update_if_unchanged(
    db: DatabaseEngine,
    doc_path: str,
    expected_version: int,
    new_data: dict
) -> bool:
    """
    Updates document only if version hasn't changed (optimistic locking).

    Returns:
        bool: True if update successful, False if version conflict
    """

    @db.transaction()
    async def _conditional_update(transaction: AsyncTransaction):
        # Read current state
        doc = await db.retrieve(doc_path, transaction=transaction)

        # Check version
        if doc.get("version") != expected_version:
            return False  # Version conflict

        # Update with new version
        update_data = {**new_data, "version": expected_version + 1}
        db.update_by_transaction(doc_path, update_data, transaction)

        return True

    return await _conditional_update()

# Usage
success = await update_if_unchanged(
    db,
    "documents/abc123",
    expected_version=5,
    new_data={"title": "Updated Title"}
)
```

## Key Points

- ✅ Prevents race conditions and lost updates
- ✅ Ensures consistency across multiple documents
- ✅ Automatic retry on contention
- ✅ All reads before writes
- ✅ Operations are atomic (all or nothing)

## Performance Considerations

### When to Use Transactions

✅ **USE transactions for:**
- Counters and aggregations
- Stock/inventory management
- Financial transfers
- Any operation based on current value
- Multi-document consistency

❌ **DON'T use transactions for:**
- Simple single-document updates with fixed values
- Read-only operations
- Operations that don't depend on current state
- Long-running processes

### Example: When NOT Needed

```python
# ❌ Transaction NOT needed (fixed value update)
async def update_user_email(db: DatabaseEngine, user_id: str, new_email: str):
    # No need for transaction - not reading current value
    await db.update(f"users/{user_id}", {"email": new_email})

# ✅ Transaction needed (depends on current value)
async def add_user_points(db: DatabaseEngine, user_id: str, points: int):
    @db.transaction()
    async def _add(transaction: AsyncTransaction):
        user = await db.retrieve(f"users/{user_id}", transaction=transaction)
        new_points = user["points"] + points  # Reading current value!
        db.update_by_transaction(f"users/{user_id}", {"points": new_points}, transaction)

    await _add()
```

## Related

- [Basic Transaction Pattern](./transaction-basic.md)
- [Transaction Error Handling](./transaction-errors.md)
- [Update Fields](./update-fields.md)
- [Create in Transaction](./create-transaction.md)
