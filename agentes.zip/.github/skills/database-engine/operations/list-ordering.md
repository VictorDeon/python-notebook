# List Documents with Ordering

## Use Case

Retrieve documents sorted by specific fields.

## Pattern

```python
from engines.database import DatabaseEngine, OrderBy, OrderDirection

async def get_top_users_by_points(db: DatabaseEngine) -> list[dict]:
    """
    Retrieves users ordered by points (highest first).

    Returns:
        list[dict]: List of users sorted by points
    """

    order_by = [
        OrderBy(field="points", direction=OrderDirection.DESCENDING)
    ]

    users = []
    async for user in db.list_documents_by("users", order_by=order_by):
        users.append(user)

    return users
```

## Examples

### Single Field Ordering

```python
from engines.database import OrderBy, OrderDirection

# Newest users first
order_by = [OrderBy(field="created_at", direction=OrderDirection.DESCENDING)]
async for user in db.list_documents_by("users", order_by=order_by):
    print(user["name"])

# Alphabetical order
order_by = [OrderBy(field="name", direction=OrderDirection.ASCENDING)]
async for user in db.list_documents_by("users", order_by=order_by):
    print(user["name"])
```

### Multiple Field Ordering

```python
# Order by status (ascending), then by points (descending)
order_by = [
    OrderBy(field="status", direction=OrderDirection.ASCENDING),
    OrderBy(field="points", direction=OrderDirection.DESCENDING)
]

async for user in db.list_documents_by("users", order_by=order_by):
    print(f"{user['status']}: {user['name']} - {user['points']} points")
```

## Order Directions

| Direction | Usage | Example |
|-----------|-------|---------|
| `ASCENDING` | A → Z, 0 → 9, oldest → newest | `OrderDirection.ASCENDING` |
| `DESCENDING` | Z → A, 9 → 0, newest → oldest | `OrderDirection.DESCENDING` |

## Common Patterns

### Top 10 by Score

```python
order_by = [OrderBy(field="score", direction=OrderDirection.DESCENDING)]

top_users = []
async for user in db.list_documents_by("users", order_by=order_by, limit=10):
    top_users.append(user)
```

### Recent First

```python
order_by = [OrderBy(field="created_at", direction=OrderDirection.DESCENDING)]

async for item in db.list_documents_by("posts", order_by=order_by, limit=20):
    print(f"Recent post: {item['title']}")
```

### Alphabetical with Pagination

```python
order_by = [OrderBy(field="name", direction=OrderDirection.ASCENDING)]

users, next_cursor = await db.list_paginated_documents(
    "users",
    order_by=order_by,
    limit=50
)
```

## Combining with Filters

```python
from engines.database import Filter, OrderBy, OrderDirection

# Active users, ordered by points
filters = [Filter(field="status", operator="==", value="active")]
order_by = [OrderBy(field="points", direction=OrderDirection.DESCENDING)]

async for user in db.list_documents_by(
    "users",
    filters=filters,
    order_by=order_by,
    limit=10
):
    print(f"{user['name']}: {user['points']} points")
```

## Important Considerations

### ⚠️ Composite Indexes Required

When combining filters and ordering, you need composite indexes:

```python
# Requires composite index
filters = [Filter(field="status", operator="==", value="active")]
order_by = [OrderBy(field="created_at", direction=OrderDirection.DESCENDING)]
```

Add to `firestore.indexes.json`:
```json
{
  "collectionGroup": "users",
  "queryScope": "COLLECTION",
  "fields": [
    { "fieldPath": "status", "order": "ASCENDING" },
    { "fieldPath": "created_at", "order": "DESCENDING" }
  ]
}
```

### ⚠️ Range Filter Ordering

When using range filters, the first `order_by` must be the same field:

```python
# ✅ CORRECT: Range filter and first order_by match
filters = [Filter(field="points", operator=">", value=100)]
order_by = [
    OrderBy(field="points", direction=OrderDirection.DESCENDING),
    OrderBy(field="created_at", direction=OrderDirection.DESCENDING)
]

# ❌ WRONG: Range filter and first order_by don't match
filters = [Filter(field="points", operator=">", value=100)]
order_by = [
    OrderBy(field="created_at", direction=OrderDirection.DESCENDING)  # ❌
]
```

### ✅ Automatic __name__ Ordering

For paginated queries, `__name__` (document ID) is automatically added as the last ordering field to ensure unique cursors:

```python
# You specify:
order_by = [OrderBy(field="points", direction=OrderDirection.DESCENDING)]

# DatabaseEngine automatically adds:
# order_by = [
#     OrderBy(field="points", direction=OrderDirection.DESCENDING),
#     OrderBy(field="__name__", direction=OrderDirection.DESCENDING)
# ]
```

## Performance Tips

```python
# ✅ GOOD: Order by indexed field
order_by = [OrderBy(field="created_at", direction=OrderDirection.DESCENDING)]

# ⚠️ SLOW: Order by non-indexed field
order_by = [OrderBy(field="custom_field", direction=OrderDirection.ASCENDING)]
# Make sure to add index in firestore.indexes.json
```

## Related

- [List with Filters](./list-filters.md)
- [List with Limit](./list-limit.md)
- [Cursor-Based Pagination](./pagination-cursor.md)
- [Firestore Optimization Skill](../../firestore-optimization/SKILL.md)
