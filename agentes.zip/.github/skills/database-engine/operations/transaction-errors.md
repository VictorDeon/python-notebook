# Transaction Error Handling

## Use Case

Properly handle errors and ensure appropriate rollback behavior in transactions.

## Pattern

```python
from engines.database import DatabaseEngine
from google.cloud.firestore_v1 import AsyncTransaction
from fastapi import HTTPException, status

async def safe_transaction_operation(
    db: DatabaseEngine,
    user_id: str,
    amount: int
) -> dict:
    """
    Executes transaction with proper error handling.
    """

    @db.transaction()
    async def _operation(transaction: AsyncTransaction) -> dict:
        try:
            # Read
            user = await db.retrieve(f"users/{user_id}", transaction=transaction)

            # Validate
            if user.get("status") == "banned":
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail=_("Usuário banido")
                )

            if user.get("balance", 0) < amount:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=_("Saldo insuficiente")
                )

            # Write
            new_balance = user["balance"] - amount
            db.update_by_transaction(
                f"users/{user_id}",
                {"balance": new_balance},
                transaction
            )

            return {"user_id": user_id, "new_balance": new_balance}

        except HTTPException:
            # HTTPException is automatically propagated
            # Transaction will rollback
            raise

        except Exception as e:
            # Log unexpected errors
            logger.error(f"Unexpected transaction error: {e}", json_data={
                "user_id": user_id,
                "amount": amount
            })
            raise

    return await _operation()
```

## Automatic Rollback

Transactions automatically rollback when:
- Any exception is raised
- HTTPException is raised
- Validation fails
- Network error occurs
- Firestore conflict detected

```python
@db.transaction()
async def auto_rollback_example(transaction: AsyncTransaction):
    # These writes will be applied:
    db.update_by_transaction("users/1", {"points": 100}, transaction)
    db.update_by_transaction("users/2", {"points": 200}, transaction)

    # This raises an exception:
    raise HTTPException(status_code=400, detail="Validation failed")

    # All writes above are automatically rolled back! ✅
```

## Common Error Scenarios

### Validation Errors

```python
@db.transaction()
async def validated_operation(transaction: AsyncTransaction, user_id: str, action: str):
    """Transaction with business logic validation."""

    user = await db.retrieve(f"users/{user_id}", transaction=transaction)

    # Validation checks
    if user["status"] != "active":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=_("Usuário não está ativo")
        )

    if action not in user.get("allowed_actions", []):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=_("Ação não permitida")
        )

    # Proceed with operation
    db.update_by_transaction(f"users/{user_id}", {"last_action": action}, transaction)
```

### Document Not Found

```python
@db.transaction()
async def handle_not_found(transaction: AsyncTransaction, doc_id: str):
    """Handles missing documents gracefully."""

    try:
        doc = await db.retrieve(f"documents/{doc_id}", transaction=transaction)
        # Process document...
    except HTTPException as e:
        if e.status_code == status.HTTP_404_NOT_FOUND:
            # Document doesn't exist - handle appropriately
            logger.warning(f"Document {doc_id} not found")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=_("Documento não encontrado")
            )
        raise
```

### Contention and Retries

DatabaseEngine automatically retries transactions on contention:

```python
# Firestore automatically retries on conflict
# You don't need to implement retry logic manually

@db.transaction()
async def high_contention_operation(transaction: AsyncTransaction, counter_id: str):
    """Operation on frequently updated document."""

    # Firestore will retry this entire function if conflict occurs
    counter = await db.retrieve(f"counters/{counter_id}", transaction=transaction)
    new_value = counter["value"] + 1
    db.update_by_transaction(f"counters/{counter_id}", {"value": new_value}, transaction)

    # If another client updated this counter between read and write,
    # Firestore will retry this entire function automatically
```

## Best Practices

### ✅ DO

```python
@db.transaction()
async def good_error_handling(transaction: AsyncTransaction):
    try:
        # Transaction logic
        user = await db.retrieve("users/123", transaction=transaction)
        db.update_by_transaction("users/123", {"status": "active"}, transaction)
    except HTTPException:
        # Re-raise HTTPException (already internationalized)
        raise
    except Exception as e:
        # Log unexpected errors with context
        logger.error(f"Transaction failed: {e}", json_data={"user_id": "123"})
        raise
```

### ❌ DON'T

```python
@db.transaction()
async def bad_error_handling(transaction: AsyncTransaction):
    try:
        # Transaction logic
        user = await db.retrieve("users/123", transaction=transaction)
        db.update_by_transaction("users/123", {"status": "active"}, transaction)
    except Exception:
        # ❌ DON'T: Catch all exceptions and ignore
        pass  # Transaction state unclear!

    # ❌ DON'T: Swallow errors
    return {"success": True}  # Misleading!
```

## Logging Transaction Errors

```python
async def logged_transaction(db: DatabaseEngine, user_id: str):
    """Transaction with comprehensive logging."""

    logger.info("Starting transaction", json_data={"user_id": user_id})

    try:
        @db.transaction()
        async def _transaction(transaction: AsyncTransaction):
            user = await db.retrieve(f"users/{user_id}", transaction=transaction)

            # Validation
            if user["points"] < 10:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=_("Pontos insuficientes")
                )

            # Update
            db.update_by_transaction(
                f"users/{user_id}",
                {"points": user["points"] - 10},
                transaction
            )

        await _transaction()

        logger.info("Transaction completed successfully", json_data={"user_id": user_id})

    except HTTPException as e:
        logger.warning(
            f"Transaction validation failed: {e.detail}",
            json_data={
                "user_id": user_id,
                "status_code": e.status_code
            }
        )
        raise

    except Exception as e:
        logger.error(
            f"Transaction failed unexpectedly: {e}",
            json_data={"user_id": user_id}
        )
        raise
```

## Related

- [Basic Transaction Pattern](./transaction-basic.md)
- [Transaction Read-Write](./transaction-read-write.md)
- [Observability Skill](../../observability/SKILL.md)
