# Cursor-Based Pagination

## Use Case

Efficiently paginate through large collections using cursor-based navigation (recommended for UI pagination).

## Pattern

```python
from engines.database import DatabaseEngine

async def get_users_page(
    db: DatabaseEngine,
    page_size: int = 20,
    cursor: str | None = None
) -> tuple[list[dict], str | None]:
    """
    Retrieves a page of users.

    Args:
        page_size: Number of users per page
        cursor: Cursor from previous page (None for first page)

    Returns:
        tuple[list[dict], str | None]: Users and next page cursor
    """

    users, next_cursor = await db.list_paginated_documents(
        path="users",
        last_document_id=cursor,
        limit=page_size
    )

    return users, next_cursor
```

## Examples

### Basic Pagination

```python
# First page
users, next_cursor = await db.list_paginated_documents("users", limit=20)
print(f"Page 1: {len(users)} users")
print(f"Next cursor: {next_cursor}")

# Second page
if next_cursor:
    users, next_cursor = await db.list_paginated_documents(
        "users",
        last_document_id=next_cursor,
        limit=20
    )
    print(f"Page 2: {len(users)} users")
```

### Complete Pagination Flow

```python
async def fetch_all_pages(db: DatabaseEngine, collection: str, page_size: int = 50):
    """Fetches all pages from a collection."""
    all_docs = []
    cursor = None
    page_num = 1

    while True:
        docs, cursor = await db.list_paginated_documents(
            collection,
            last_document_id=cursor,
            limit=page_size
        )

        all_docs.extend(docs)
        print(f"Fetched page {page_num}: {len(docs)} documents")

        # cursor is None when no more pages
        if cursor is None:
            break

        page_num += 1

    return all_docs
```

### Pagination with Ordering

```python
from engines.database import OrderBy, OrderDirection

# Paginate users by creation date (newest first)
order_by = [OrderBy(field="created_at", direction=OrderDirection.DESCENDING)]

users, next_cursor = await db.list_paginated_documents(
    "users",
    order_by=order_by,
    limit=20
)
```

## Return Values

The method returns a tuple: `(documents, next_cursor)`

| Scenario | `documents` | `next_cursor` | Meaning |
|----------|-------------|---------------|---------|
| First page with more data | `[...20 items]` | `"abc123"` | More pages available |
| Last page (partial) | `[...15 items]` | `None` | No more pages |
| Empty collection | `[]` | `None` | No data at all |
| Exact page size, last page | `[...20 items]` | `None` | Last page exactly |

## Key Points

- ✅ Returns tuple: `(list[dict], str | None)`
- ✅ `next_cursor` is `None` when no more pages exist
- ✅ `next_cursor` contains last document ID of current page
- ✅ Automatically adds `__name__` ordering for unique cursors
- ✅ Memory efficient (doesn't load all documents)
- ✅ Consistent results even with concurrent writes

## REST API Implementation

```python
from fastapi import Query

@router.get("/users")
async def list_users(
    db: DatabaseEngine = Depends(get_db),
    limit: int = Query(default=20, ge=1, le=100),
    cursor: str | None = Query(default=None)
):
    """
    Lists users with pagination.

    Query Params:
        limit: Page size (default: 20, max: 100)
        cursor: Cursor for next page (from previous response)
    """

    users, next_cursor = await db.list_paginated_documents(
        "users",
        last_document_id=cursor,
        limit=limit
    )

    return {
        "data": users,
        "next_cursor": next_cursor,
        "has_more": next_cursor is not None
    }

# Usage:
# GET /users?limit=20              → First page
# GET /users?limit=20&cursor=abc123 → Next page
```

## Pagination with Filters

```python
from engines.database import Filter

# Paginate active users only
filters = [Filter(field="status", operator="==", value="active")]

users, next_cursor = await db.list_paginated_documents(
    "users",
    filters=filters,
    limit=20,
    last_document_id=cursor
)
```

## Performance Benefits

```python
# ❌ BAD: Load all documents into memory
users = []
async for user in db.list_documents_by("users"):
    users.append(user)
# Problem: If collection has 100k docs, all loaded at once!

# ✅ GOOD: Paginate through documents
cursor = None
while True:
    users, cursor = await db.list_paginated_documents("users", limit=100, last_document_id=cursor)
    process_batch(users)
    if cursor is None:
        break
```

## Important Considerations

### ⚠️ Cursor Invalidation

Cursors may become invalid if:
- The referenced document is deleted
- The collection structure changes significantly
- User attempts to use old cursor after schema changes

**Handle gracefully:**

```python
try:
    users, next_cursor = await db.list_paginated_documents(
        "users",
        last_document_id=cursor,
        limit=20
    )
except HTTPException as e:
    if e.status_code == 400:
        # Invalid cursor, restart from beginning
        users, next_cursor = await db.list_paginated_documents("users", limit=20)
    else:
        raise
```

### ⚠️ Consistency

Results are consistent at query time but don't reflect real-time changes:
- New documents may appear in next pages
- Deleted documents won't appear
- Updated documents show new values

This is expected behavior for cursor-based pagination.

## Related

- [List All Documents](./list-all.md)
- [Pagination with Filters](./pagination-advanced.md)
- [List with Ordering](./list-ordering.md)
- [List with Limit](./list-limit.md)
