# Retrieve Document in Transaction

## Use Case

Read a document within a transaction to ensure consistency with other operations.

## Pattern

```python
from engines.database import DatabaseEngine
from google.cloud.firestore_v1 import AsyncTransaction

async def get_user_balance_safely(
    db: DatabaseEngine,
    user_id: str
) -> float:
    """
    Retrieves user balance within transaction for consistency.
    """

    @db.transaction()
    async def _get_balance(transaction: AsyncTransaction) -> float:
        user = await db.retrieve(
            f"users/{user_id}",
            transaction=transaction
        )
        return user["balance"]

    return await _get_balance()
```

## Method Signature

```python
async def retrieve(
    path: str,
    transaction: AsyncTransaction = None,
    timeout: float = FIRESTORE_READ_TIMEOUT
) -> dict:
    """
    Retrieves document (optionally in transaction).

    Args:
        path: Complete document path
        transaction: Optional transaction for consistency
        timeout: Operation timeout

    Returns:
        dict: Document data with 'id' field
    """
```

## Key Points

- ✅ **Async method** (use `await`)
- ✅ Pass `transaction` parameter for transactional reads
- ✅ Must read **before** any writes in transaction
- ✅ Returns `dict` with `"id"` field
- ✅ Throws `HTTPException 404` if not found
- ✅ Ensures snapshot isolation within transaction

## Examples

### Read Before Write

```python
@db.transaction()
async def increment_counter(transaction: AsyncTransaction, counter_id: str):
    """Atomically increments counter."""

    # Read current value
    counter = await db.retrieve(
        f"counters/{counter_id}",
        transaction=transaction
    )

    # Calculate new value
    new_value = counter["value"] + 1

    # Write new value
    db.update_by_transaction(
        f"counters/{counter_id}",
        {"value": new_value},
        transaction
    )
```

### Read Multiple Documents

```python
@db.transaction()
async def transfer_funds(
    transaction: AsyncTransaction,
    from_account: str,
    to_account: str,
    amount: float
):
    """Transfers funds between accounts."""

    # Read both accounts in transaction
    from_acc = await db.retrieve(f"accounts/{from_account}", transaction=transaction)
    to_acc = await db.retrieve(f"accounts/{to_account}", transaction=transaction)

    # Validate
    if from_acc["balance"] < amount:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=_("Saldo insuficiente")
        )

    # Update both
    db.update_by_transaction(
        f"accounts/{from_account}",
        {"balance": from_acc["balance"] - amount},
        transaction
    )

    db.update_by_transaction(
        f"accounts/{to_account}",
        {"balance": to_acc["balance"] + amount},
        transaction
    )
```

## Related

- [Retrieve Document](./retrieve-document.md)
- [Check Existence](./check-existence.md)
- [Transaction Read-Write](./transaction-read-write.md)
- [Basic Transaction Pattern](./transaction-basic.md)
