# Batch Delete Operation

## Use Case

Delete multiple documents efficiently in a single batch operation.

## Pattern

```python
from engines.database import DatabaseEngine, BatchResult

async def delete_inactive_users(
    db: DatabaseEngine,
    user_ids: list[str]
) -> BatchResult:
    """
    Deletes multiple users in batch.

    Args:
        user_ids: List of user document IDs to delete

    Returns:
        BatchResult: Summary of batch operation
    """

    # Prepare delete list (must include 'id' field)
    deletes = [{"id": user_id} for user_id in user_ids]

    result = await db.delete_by_batch(
        collection="users",
        data=deletes
    )

    return result
```

## Examples

### Basic Batch Delete

```python
# Delete multiple documents
user_ids = ["user_1", "user_2", "user_3", "user_4", "user_5"]

# Convert to required format
deletes = [{"id": user_id} for user_id in user_ids]

# Delete in batch
result = await db.delete_by_batch("users", deletes)

print(f"Deleted: {result.total_succeeded}/{result.total_attempted} users")
```

### Delete Query Results

```python
async def delete_old_logs(db: DatabaseEngine, days_old: int = 30) -> BatchResult:
    """Deletes logs older than specified days."""

    # Calculate cutoff timestamp
    cutoff = int(time.time()) - (days_old * 24 * 60 * 60)

    # Query old logs
    filters = [Filter(field="created_at", operator="<", value=cutoff)]

    # Collect IDs
    deletes = []
    async for log in db.list_documents_by("logs", filters=filters):
        deletes.append({"id": log["id"]})

    # Batch delete
    result = await db.delete_by_batch("logs", deletes)

    logger.info(f"Deleted {result.total_succeeded} old logs")

    return result
```

### Delete with Validation

```python
async def delete_expired_sessions(db: DatabaseEngine) -> BatchResult:
    """Deletes all expired user sessions."""

    current_time = int(time.time())

    # Find expired sessions
    filters = [Filter(field="expires_at", operator="<", value=current_time)]

    # Collect session IDs
    deletes = []
    async for session in db.list_documents_by("sessions", filters=filters):
        # Additional validation
        if session.get("active") == False:
            deletes.append({"id": session["id"]})

    if not deletes:
        logger.info("No expired sessions to delete")
        return BatchResult(total_attempted=0, total_succeeded=0, total_failed=0)

    # Batch delete
    result = await db.delete_by_batch("sessions", deletes)

    return result
```

### Cleanup Operation

```python
async def cleanup_orphaned_data(db: DatabaseEngine, user_id: str) -> dict:
    """Deletes all data associated with a deleted user."""

    results = {}

    # Delete user's orders
    orders = []
    async for order in db.list_documents_by(
        "orders",
        filters=[Filter(field="user_id", operator="==", value=user_id)]
    ):
        orders.append({"id": order["id"]})

    if orders:
        results["orders"] = await db.delete_by_batch("orders", orders)

    # Delete user's sessions
    sessions = []
    async for session in db.list_documents_by(
        "sessions",
        filters=[Filter(field="user_id", operator="==", value=user_id)]
    ):
        sessions.append({"id": session["id"]})

    if sessions:
        results["sessions"] = await db.delete_by_batch("sessions", sessions)

    # Delete user's notifications
    notifications = []
    async for notif in db.list_documents_by(
        "notifications",
        filters=[Filter(field="user_id", operator="==", value=user_id)]
    ):
        notifications.append({"id": notif["id"]})

    if notifications:
        results["notifications"] = await db.delete_by_batch("notifications", notifications)

    return results
```

## Important: ID Field Required

**Every dict in the `data` list MUST include an `"id"` field:**

```python
# ✅ CORRECT
deletes = [
    {"id": "doc_1"},  # ✅ Has 'id'
    {"id": "doc_2"}   # ✅ Has 'id'
]

# ❌ WRONG
deletes = [
    {"name": "doc_1"},  # ❌ Missing 'id'
    {}                  # ❌ Missing 'id'
]

result = await db.delete_by_batch("collection", deletes)
# Documents without 'id' will be skipped and logged
```

## Key Points

- ✅ Efficient for deleting 10+ documents
- ✅ Automatically chunks requests (450 docs per chunk)
- ✅ Built-in retry logic for transient failures
- ✅ Each entry must have `"id"` field
- ✅ Idempotent (safe to delete non-existent documents)
- ⚠️ Partial failures possible (check `total_failed`)
- ⚠️ Not atomic (unlike transactions)
- ⚠️ Doesn't delete subcollections automatically

## Error Handling

```python
async def safe_batch_delete(
    db: DatabaseEngine,
    collection: str,
    document_ids: list[str]
) -> BatchResult:
    """Batch delete with validation and error handling."""

    # Validate input
    if not document_ids:
        logger.info("No documents to delete")
        return BatchResult(total_attempted=0, total_succeeded=0, total_failed=0)

    # Prepare delete list
    deletes = [{"id": doc_id} for doc_id in document_ids if doc_id]

    try:
        result = await db.delete_by_batch(collection, deletes)

        # Log results
        logger.info(
            f"Batch delete completed",
            json_data={
                "collection": collection,
                "attempted": result.total_attempted,
                "succeeded": result.total_succeeded,
                "failed": result.total_failed
            }
        )

        # Handle partial failures
        if result.total_failed > 0:
            logger.warning(f"{result.total_failed} documents failed to delete")

        return result

    except HTTPException as e:
        logger.error(f"Batch delete failed: {e.detail}")
        raise
```

## Performance Comparison

```python
# ❌ BAD: Loop delete (very slow)
for doc_id in document_ids:  # 100 documents
    await db.delete(f"collection/{doc_id}")
# Time: ~10 seconds (100 network calls)

# ✅ GOOD: Batch delete
deletes = [{"id": doc_id} for doc_id in document_ids]
result = await db.delete_by_batch("collection", deletes)
# Time: ~1 second (3 network calls with chunking)
```

## When to Use

### ✅ Use Batch Delete When:
- Deleting 10+ documents at once
- Cleanup operations
- Purging old data
- Removing query results
- Background maintenance tasks

### ❌ Use Regular Delete When:
- Deleting 1-5 documents
- Need to delete with subcollections
- Need atomic guarantee (use transactions)
- Deleting with complex dependencies

## Scheduled Cleanup Example

```python
async def scheduled_cleanup(db: DatabaseEngine):
    """Daily cleanup job to remove old data."""

    logger.info("Starting scheduled cleanup")

    # Delete old logs (>90 days)
    log_result = await delete_old_logs(db, days_old=90)

    # Delete expired sessions
    session_result = await delete_expired_sessions(db)

    # Delete soft-deleted users (>30 days)
    thirty_days_ago = int(time.time()) - (30 * 24 * 60 * 60)
    deleted_users = []
    async for user in db.list_documents_by(
        "users",
        filters=[
            Filter(field="deleted", operator="==", value=True),
            Filter(field="deleted_at", operator="<", value=thirty_days_ago)
        ]
    ):
        deleted_users.append({"id": user["id"]})

    user_result = await db.delete_by_batch("users", deleted_users)

    # Log summary
    logger.info(
        "Cleanup completed",
        json_data={
            "logs_deleted": log_result.total_succeeded,
            "sessions_deleted": session_result.total_succeeded,
            "users_deleted": user_result.total_succeeded
        }
    )
```

## Deleting with Subcollections

⚠️ **Batch delete doesn't delete subcollections automatically:**

```python
async def delete_user_with_subcollections(
    db: DatabaseEngine,
    user_id: str
):
    """Deletes user and all their subcollections."""

    # 1. Delete user's orders (subcollection)
    orders = []
    async for order in db.list_documents_by(f"users/{user_id}/orders"):
        orders.append({"id": order["id"]})

    if orders:
        await db.delete_by_batch(f"users/{user_id}/orders", orders)

    # 2. Delete user's sessions (subcollection)
    sessions = []
    async for session in db.list_documents_by(f"users/{user_id}/sessions"):
        sessions.append({"id": session["id"]})

    if sessions:
        await db.delete_by_batch(f"users/{user_id}/sessions", sessions)

    # 3. Finally, delete user document
    await db.delete(f"users/{user_id}")
```

## Best Practices

### ✅ DO

```python
# ✅ Validate IDs exist and are not empty
deletes = [{"id": id} for id in ids if id]

# ✅ Check results
result = await db.delete_by_batch("collection", deletes)
if result.total_failed > 0:
    logger.warning(f"Failed to delete {result.total_failed} documents")

# ✅ Log operations
logger.info(f"Deleting {len(deletes)} documents from collection")
result = await db.delete_by_batch("collection", deletes)
```

### ❌ DON'T

```python
# ❌ Don't forget subcollections
await db.delete_by_batch("users", user_deletes)  # Subcollections remain! ❌

# ❌ Don't use for small batches
if len(ids) < 5:
    await db.delete_by_batch("collection", [{"id": id} for id in ids])  # Overkill

# ❌ Don't ignore validation
await db.delete_by_batch("collection", [{"id": id} for id in ids])
# What if 'ids' contains None or empty strings? ❌
```

## Related

- [Batch Create](./batch-create.md)
- [Batch Update](./batch-update.md)
- [Handling Batch Results](./batch-results.md)
- [Delete Document](./delete-document.md)
- [Delete in Transaction](./delete-transaction.md)
