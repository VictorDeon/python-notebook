# Advanced Pagination with Filters and Ordering

## Use Case

Paginate through filtered and ordered query results efficiently.

## Pattern

```python
from engines.database import DatabaseEngine, Filter, OrderBy, OrderDirection

async def get_active_users_page(
    db: DatabaseEngine,
    page_size: int = 20,
    cursor: str | None = None
) -> tuple[list[dict], str | None]:
    """
    Retrieves active users ordered by points (descending) with pagination.

    Args:
        page_size: Number of users per page
        cursor: Cursor from previous page

    Returns:
        tuple[list[dict], str | None]: Users and next page cursor
    """

    filters = [Filter(field="status", operator="==", value="active")]
    order_by = [OrderBy(field="points", direction=OrderDirection.DESCENDING)]

    users, next_cursor = await db.list_paginated_documents(
        path="users",
        filters=filters,
        order_by=order_by,
        last_document_id=cursor,
        limit=page_size
    )

    return users, next_cursor
```

## Examples

### Filtered Pagination

```python
from engines.database import Filter

# Active users only
filters = [Filter(field="status", operator="==", value="active")]

page1, cursor = await db.list_paginated_documents(
    "users",
    filters=filters,
    limit=20
)

# Next page
page2, cursor = await db.list_paginated_documents(
    "users",
    filters=filters,
    last_document_id=cursor,
    limit=20
)
```

### Sorted Pagination

```python
from engines.database import OrderBy, OrderDirection

# Most recent first
order_by = [OrderBy(field="created_at", direction=OrderDirection.DESCENDING)]

recent_posts, cursor = await db.list_paginated_documents(
    "posts",
    order_by=order_by,
    limit=50
)
```

### Complex Query Pagination

```python
from engines.database import Filter, OrderBy, OrderDirection

# Active users with >100 points, sorted by points (descending)
filters = [
    Filter(field="status", operator="==", value="active"),
    Filter(field="points", operator=">", value=100)
]
order_by = [
    OrderBy(field="points", direction=OrderDirection.DESCENDING)
]

users, cursor = await db.list_paginated_documents(
    "users",
    filters=filters,
    order_by=order_by,
    limit=20
)
```

## REST API Implementation

```python
from fastapi import Query
from typing import Literal

@router.get("/users")
async def list_users_filtered(
    db: DatabaseEngine = Depends(get_db),
    status: Literal["active", "inactive", "banned"] | None = Query(default=None),
    min_points: int | None = Query(default=None, ge=0),
    sort_by: Literal["created_at", "points", "name"] = Query(default="created_at"),
    order: Literal["asc", "desc"] = Query(default="desc"),
    limit: int = Query(default=20, ge=1, le=100),
    cursor: str | None = Query(default=None)
):
    """
    Lists users with advanced filtering, sorting, and pagination.
    """

    # Build filters
    filters = []
    if status:
        filters.append(Filter(field="status", operator="==", value=status))
    if min_points is not None:
        filters.append(Filter(field="points", operator=">=", value=min_points))

    # Build ordering
    direction = OrderDirection.DESCENDING if order == "desc" else OrderDirection.ASCENDING
    order_by = [OrderBy(field=sort_by, direction=direction)]

    # Execute query
    users, next_cursor = await db.list_paginated_documents(
        "users",
        filters=filters if filters else None,
        order_by=order_by,
        last_document_id=cursor,
        limit=limit
    )

    return {
        "data": users,
        "pagination": {
            "limit": limit,
            "cursor": cursor,
            "next_cursor": next_cursor,
            "has_more": next_cursor is not None
        },
        "filters": {
            "status": status,
            "min_points": min_points,
            "sort_by": sort_by,
            "order": order
        }
    }

# Usage:
# GET /users?status=active&min_points=100&sort_by=points&order=desc&limit=20
# GET /users?status=active&cursor=abc123&limit=20
```

## Multiple Field Ordering

```python
# Order by status (asc), then points (desc)
order_by = [
    OrderBy(field="status", direction=OrderDirection.ASCENDING),
    OrderBy(field="points", direction=OrderDirection.DESCENDING)
]

users, cursor = await db.list_paginated_documents(
    "users",
    order_by=order_by,
    limit=20
)
```

## Time-Range Queries with Pagination

```python
import time

# Posts from last 7 days
seven_days_ago = int(time.time()) - (7 * 24 * 60 * 60)

filters = [
    Filter(field="created_at", operator=">=", value=seven_days_ago)
]
order_by = [
    OrderBy(field="created_at", direction=OrderDirection.DESCENDING)
]

posts, cursor = await db.list_paginated_documents(
    "posts",
    filters=filters,
    order_by=order_by,
    limit=50
)
```

## Search-Like Queries

```python
# Users with specific tags
filters = [
    Filter(field="tags", operator="array-contains", value="premium")
]
order_by = [
    OrderBy(field="created_at", direction=OrderDirection.DESCENDING)
]

users, cursor = await db.list_paginated_documents(
    "users",
    filters=filters,
    order_by=order_by,
    limit=20
)
```

## Important: Composite Indexes

Complex queries **require composite indexes** in `firestore.indexes.json`:

### Example Index Configuration

```json
{
  "indexes": [
    {
      "collectionGroup": "users",
      "queryScope": "COLLECTION",
      "fields": [
        { "fieldPath": "status", "order": "ASCENDING" },
        { "fieldPath": "points", "order": "DESCENDING" },
        { "fieldPath": "__name__", "order": "DESCENDING" }
      ]
    },
    {
      "collectionGroup": "posts",
      "queryScope": "COLLECTION",
      "fields": [
        { "fieldPath": "created_at", "order": "DESCENDING" },
        { "fieldPath": "__name__", "order": "DESCENDING" }
      ]
    }
  ]
}
```

**How to know which index you need:**
1. Run the query in development
2. Firestore will throw an error with a link to create the index
3. Add the index configuration to `firestore.indexes.json`
4. Deploy indexes: `firebase deploy --only firestore:indexes`

## Key Points

- ✅ Combine filters, ordering, and pagination seamlessly
- ✅ Requires composite indexes for complex queries
- ✅ Cursors are stable across filtered results
- ✅ Automatic `__name__` ordering ensures unique cursors
- ⚠️ Range filters and ordering have restrictions (see below)

## Limitations and Workarounds

### ⚠️ Range Filter + Ordering Rule

When using range filters, the first `order_by` must match the filter field:

```python
# ✅ CORRECT
filters = [Filter(field="points", operator=">", value=100)]
order_by = [
    OrderBy(field="points", direction=OrderDirection.DESCENDING),
    OrderBy(field="created_at", direction=OrderDirection.DESCENDING)
]

# ❌ WRONG
filters = [Filter(field="points", operator=">", value=100)]
order_by = [
    OrderBy(field="created_at", direction=OrderDirection.DESCENDING)  # ❌ Doesn't match filter
]
```

### ⚠️ Only One Range Filter

You can only use range operators (`<`, `>`, `<=`, `>=`) on **one field**:

```python
# ❌ WRONG: Multiple range filters
filters = [
    Filter(field="points", operator=">", value=100),   # Range filter
    Filter(field="created_at", operator=">", value=ts) # Another range filter ❌
]

# ✅ CORRECT: One range filter, one equality filter
filters = [
    Filter(field="status", operator="==", value="active"),  # Equality
    Filter(field="points", operator=">", value=100)         # Range
]
```

## Related

- [Cursor-Based Pagination](./pagination-cursor.md)
- [List with Filters](./list-filters.md)
- [List with Ordering](./list-ordering.md)
- [Firestore Optimization Skill](../../firestore-optimization/SKILL.md)
