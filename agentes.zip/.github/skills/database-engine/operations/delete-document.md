# Delete Document

## Use Case

Permanently remove a document from Firestore.

## Pattern

```python
from engines.database import DatabaseEngine

async def delete_user(db: DatabaseEngine, user_id: str) -> str:
    """
    Deletes a user document.

    Args:
        user_id: The user document ID

    Returns:
        str: The deleted document ID
    """

    doc_id = await db.delete(f"users/{user_id}")
    return doc_id
```

## Example

```python
# Delete user document
doc_id = await db.delete("users/abc123")
# Returns: "abc123"

# Document users/abc123 is permanently removed
```

## Key Points

- ✅ Use **document path** (e.g., `"users/abc123"`)
- ✅ Returns document ID on success
- ✅ **Does not throw error** if document doesn't exist
- ✅ Idempotent operation (safe to call multiple times)
- ⚠️ Doesn't delete subcollections (must be deleted separately)

## Custom Timeout

```python
# For potentially slow deletions
await db.delete("users/abc123", timeout=10.0)
```

## Within Transaction

```python
from google.cloud.firestore_v1 import AsyncTransaction

@db.transaction()
async def delete_user_and_sessions(transaction: AsyncTransaction, user_id: str):
    # Delete user document
    db.delete_by_transaction(f"users/{user_id}", transaction)

    # Delete related sessions
    sessions = await db.list_documents_by(
        f"users/{user_id}/sessions",
        transaction=transaction
    )
    async for session in sessions:
        db.delete_by_transaction(
            f"users/{user_id}/sessions/{session['id']}",
            transaction
        )

await delete_user_and_sessions(user_id="abc123")
```

## Soft Delete Pattern

Instead of permanent deletion, consider soft delete for audit trails:

```python
async def soft_delete_user(db: DatabaseEngine, user_id: str):
    """Marks user as deleted without removing data."""
    await db.update(
        f"users/{user_id}",
        {
            "deleted": True,
            "deleted_at": int(time.time())
        }
    )
```

## Bulk Delete

For deleting multiple documents, use batch operations:

```python
# ❌ BAD: Loop delete (slow)
for user_id in user_ids:
    await db.delete(f"users/{user_id}")

# ✅ GOOD: Batch delete
user_refs = [{"id": user_id} for user_id in user_ids]
result = await db.delete_by_batch("users", user_refs)
```

## Deleting Subcollections

```python
async def delete_user_with_subcollections(db: DatabaseEngine, user_id: str):
    """Deletes user and all their subcollections."""

    # 1. Delete orders subcollection
    orders = []
    async for order in db.list_documents_by(f"users/{user_id}/orders"):
        orders.append({"id": order["id"]})
    if orders:
        await db.delete_by_batch(f"users/{user_id}/orders", orders)

    # 2. Delete sessions subcollection
    sessions = []
    async for session in db.list_documents_by(f"users/{user_id}/sessions"):
        sessions.append({"id": session["id"]})
    if sessions:
        await db.delete_by_batch(f"users/{user_id}/sessions", sessions)

    # 3. Finally, delete user document
    await db.delete(f"users/{user_id}")
```

## Related

- [Delete in Transaction](./delete-transaction.md)
- [Batch Delete](./batch-delete.md)
- [Update Fields](./update-fields.md) (for soft delete)
