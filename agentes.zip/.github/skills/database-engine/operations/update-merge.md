# Merge New Fields (Upsert)

## Use Case

Update a document if it exists, or create it if it doesn't. Also useful for adding new fields to existing documents.

## Pattern

```python
from engines.database import DatabaseEngine

async def upsert_user_settings(db: DatabaseEngine, user_id: str, settings: dict) -> str:
    """
    Creates or updates user settings.

    Args:
        user_id: The user document ID
        settings: Settings to merge into document

    Returns:
        str: The document ID
    """

    doc_id = await db.update(
        path=f"users/{user_id}",
        data=settings,
        merge=True  # This enables upsert behavior
    )

    return doc_id
```

## Example

```python
# Scenario 1: Document doesn't exist
await db.update(
    "users/new123",
    {"theme": "dark", "language": "en"},
    merge=True
)
# Creates: { "id": "new123", "theme": "dark", "language": "en" }

# Scenario 2: Document exists
# Before: { "id": "abc123", "name": "John", "email": "john@example.com" }
await db.update(
    "users/abc123",
    {"theme": "dark", "notifications": True},
    merge=True
)
# After: { "id": "abc123", "name": "John", "email": "john@example.com",
#          "theme": "dark", "notifications": True }
```

## Key Points

- ✅ Creates document if it doesn't exist (upsert)
- ✅ Merges new fields into existing documents
- ✅ Doesn't remove existing fields
- ✅ Updates existing fields with new values
- ✅ Ideal for optional data that may be added later

## Difference from Regular Update

```python
# ❌ Regular update: Fails if document doesn't exist
await db.update("users/abc123", {"theme": "dark"})
# Throws HTTPException 404 if users/abc123 doesn't exist

# ✅ Merge update: Creates if doesn't exist
await db.update("users/abc123", {"theme": "dark"}, merge=True)
# Creates document if it doesn't exist
```

## Common Use Cases

### User Preferences

```python
async def save_user_preferences(db: DatabaseEngine, user_id: str, preferences: dict):
    """Saves user preferences, creating document if needed."""
    await db.update(
        f"user_preferences/{user_id}",
        preferences,
        merge=True
    )
```

### Incremental Data Collection

```python
async def add_user_metadata(db: DatabaseEngine, user_id: str, metadata: dict):
    """Adds metadata to user, preserving existing data."""
    await db.update(
        f"users/{user_id}",
        {"metadata": metadata},
        merge=True
    )
```

## Within Transaction

```python
@db.transaction()
async def upsert_in_transaction(transaction: AsyncTransaction, user_id: str, data: dict):
    db.update_by_transaction(
        path=f"users/{user_id}",
        data=data,
        transaction=transaction,
        merge=True
    )

await upsert_in_transaction(user_id="abc123", data={"theme": "dark"})
```

## Related

- [Update Existing Fields](./update-fields.md)
- [Create with Specific ID](./create-specific-id.md)
- [Update in Transaction](./update-transaction.md)
