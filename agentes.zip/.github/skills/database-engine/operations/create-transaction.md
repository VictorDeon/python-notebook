# Create Document in Transaction

## Use Case

Create a new document within a transaction to ensure atomicity with other operations.

## Pattern

```python
from engines.database import DatabaseEngine
from google.cloud.firestore_v1 import AsyncTransaction

async def create_order_with_stock_update(
    db: DatabaseEngine,
    product_id: str,
    user_id: str,
    quantity: int
) -> str:
    """
    Creates order and updates product stock atomically.

    Returns:
        str: The created order ID
    """

    @db.transaction()
    async def _create(transaction: AsyncTransaction) -> str:
        # Read product to validate stock
        product = await db.retrieve(f"products/{product_id}", transaction=transaction)

        if product["stock"] < quantity:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=_("Estoque insuficiente")
            )

        # Create order document
        order_id = db.create_by_transaction(
            path="orders",
            data={
                "user_id": user_id,
                "product_id": product_id,
                "quantity": quantity,
                "total_price": product["price"] * quantity,
                "status": "pending",
                "created_at": int(time.time())
            },
            transaction=transaction
        )

        # Update product stock
        db.update_by_transaction(
            f"products/{product_id}",
            {"stock": product["stock"] - quantity},
            transaction
        )

        return order_id

    return await _create()
```

## Method Signature

```python
def create_by_transaction(
    path: str,
    data: dict,
    transaction: AsyncTransaction
) -> str:
    """
    Creates document in transaction.

    Args:
        path: Collection path OR document path
        data: Document data
        transaction: Active transaction

    Returns:
        str: Document ID (generated or from path)
    """
```

## Examples

### Create with Auto-Generated ID

```python
@db.transaction()
async def create_notification(transaction: AsyncTransaction, user_id: str, message: str):
    """Creates notification in transaction."""

    # Pass collection path for auto ID
    notification_id = db.create_by_transaction(
        "notifications",
        {
            "user_id": user_id,
            "message": message,
            "read": False,
            "created_at": int(time.time())
        },
        transaction
    )

    return notification_id
```

### Create with Specific ID

```python
@db.transaction()
async def create_user_profile(transaction: AsyncTransaction, user_id: str, profile_data: dict):
    """Creates user profile with specific ID in transaction."""

    # Pass document path for specific ID
    doc_id = db.create_by_transaction(
        f"user_profiles/{user_id}",
        profile_data,
        transaction
    )

    return doc_id
```

### Create Multiple Documents

```python
@db.transaction()
async def create_campaign_with_metrics(transaction: AsyncTransaction, campaign_data: dict):
    """Creates campaign and initializes metrics."""

    # Create campaign
    campaign_id = db.create_by_transaction("campaigns", campaign_data, transaction)

    # Create campaign metrics
    db.create_by_transaction(
        f"campaign_metrics/{campaign_id}",
        {
            "campaign_id": campaign_id,
            "views": 0,
            "clicks": 0,
            "conversions": 0,
            "created_at": int(time.time())
        },
        transaction
    )

    return campaign_id
```

## Key Points

- ✅ Synchronous method (no `await`)
- ✅ Must be called within `@db.transaction()` decorator
- ✅ Auto-generates ID for collection paths
- ✅ Uses specified ID for document paths
- ✅ Automatically adds `"id"` field to document
- ✅ Returns document ID immediately (not awaited)
- ⚠️ Fails if document with specific ID already exists

## Path Behavior

### Collection Path (Auto ID)

```python
# Path with odd segments = collection path
order_id = db.create_by_transaction("orders", order_data, transaction)
# Creates: orders/{auto_generated_id}
```

### Document Path (Specific ID)

```python
# Path with even segments = document path
doc_id = db.create_by_transaction("users/abc123", user_data, transaction)
# Creates: users/abc123
```

## Complete Transaction Example

```python
async def transfer_with_history(
    db: DatabaseEngine,
    from_account: str,
    to_account: str,
    amount: float
) -> str:
    """Transfers money and creates transaction history."""

    @db.transaction()
    async def _transfer(transaction: AsyncTransaction) -> str:
        # Read accounts
        from_acc = await db.retrieve(f"accounts/{from_account}", transaction=transaction)
        to_acc = await db.retrieve(f"accounts/{to_account}", transaction=transaction)

        # Validate
        if from_acc["balance"] < amount:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=_("Saldo insuficiente")
            )

        # Update balances
        db.update_by_transaction(
            f"accounts/{from_account}",
            {"balance": from_acc["balance"] - amount},
            transaction
        )

        db.update_by_transaction(
            f"accounts/{to_account}",
            {"balance": to_acc["balance"] + amount},
            transaction
        )

        # Create transaction record
        tx_id = db.create_by_transaction(
            "transactions",
            {
                "from_account": from_account,
                "to_account": to_account,
                "amount": amount,
                "timestamp": int(time.time()),
                "type": "transfer"
            },
            transaction
        )

        return tx_id

    return await _transfer()
```

## Error Handling

```python
@db.transaction()
async def safe_create(transaction: AsyncTransaction, data: dict):
    """Creates document with validation."""

    try:
        # Check if duplicate
        if await db.exists(f"users/{data['email']}", transaction=transaction):
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=_("Email já cadastrado")
            )

        # Create user
        user_id = db.create_by_transaction("users", data, transaction)

        return user_id

    except HTTPException:
        # Re-raise HTTPException (transaction will rollback)
        raise
    except Exception as e:
        logger.error(f"Unexpected error creating document: {e}")
        raise
```

## Related

- [Create with Auto ID](./create-auto-id.md)
- [Create with Specific ID](./create-specific-id.md)
- [Basic Transaction Pattern](./transaction-basic.md)
- [Update in Transaction](./update-transaction.md)
- [Delete in Transaction](./delete-transaction.md)
