# List All Documents (Streaming)

## Use Case

Iterate through all documents in a collection using async streaming (memory efficient).

## Pattern

```python
from engines.database import DatabaseEngine

async def get_all_users(db: DatabaseEngine) -> list[dict]:
    """
    Retrieves all users from the collection.

    Returns:
        list[dict]: List of all user documents
    """

    users = []
    async for user in db.list_documents_by("users"):
        users.append(user)

    return users
```

## Example

```python
# Stream all users
async for user in db.list_documents_by("users"):
    print(f"User: {user['name']}, Email: {user['email']}")

# Or collect into list
users = [user async for user in db.list_documents_by("users")]
```

## Key Points

- ✅ Use **collection path** (e.g., `"users"`)
- ✅ Returns `AsyncGenerator[dict, None]` (async iterator)
- ✅ Memory efficient (streams documents one by one)
- ✅ Each document includes `"id"` field
- ✅ Can be used in transactions
- ⚠️ No pagination (use `list_paginated_documents` for large collections)

## Processing Documents

```python
async def process_active_users(db: DatabaseEngine):
    """Process all active users."""
    count = 0

    async for user in db.list_documents_by("users"):
        if user.get("status") == "active":
            # Process user
            await send_notification(user)
            count += 1

    return count
```

## With Limit

```python
# Limit to first 10 users
async for user in db.list_documents_by("users", limit=10):
    print(user["name"])
```

## Within Transaction

```python
from google.cloud.firestore_v1 import AsyncTransaction

@db.transaction()
async def count_users_in_transaction(transaction: AsyncTransaction):
    count = 0
    async for user in db.list_documents_by("users", transaction=transaction):
        count += 1
    return count

total_users = await count_users_in_transaction()
```

## When to Use vs Pagination

### Use `list_documents_by()` (streaming) when:
- ✅ Collection is small (<1000 documents)
- ✅ You need to process all documents
- ✅ Memory efficiency is important
- ✅ You're doing background processing

### Use `list_paginated_documents()` when:
- ✅ Collection is large (>1000 documents)
- ✅ You're building a paginated UI
- ✅ Users will navigate through pages
- ✅ You need cursor-based navigation

## Performance Considerations

```python
# ❌ BAD: Loading all documents into memory
users = [user async for user in db.list_documents_by("users")]
for user in users:
    process(user)

# ✅ GOOD: Stream processing
async for user in db.list_documents_by("users"):
    process(user)
```

## Related

- [List with Filters](./list-filters.md)
- [List with Ordering](./list-ordering.md)
- [List with Limit](./list-limit.md)
- [Cursor-Based Pagination](./pagination-cursor.md)
