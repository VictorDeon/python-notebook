# Delete Document in Transaction

## Use Case

Delete a document within a transaction to ensure atomicity with other operations.

## Pattern

```python
from engines.database import DatabaseEngine
from google.cloud.firestore_v1 import AsyncTransaction

async def delete_user_with_cleanup(
    db: DatabaseEngine,
    user_id: str
) -> None:
    """
    Deletes user and their associated data atomically.
    """

    @db.transaction()
    async def _delete(transaction: AsyncTransaction):
        # Verify user exists
        user = await db.retrieve(f"users/{user_id}", transaction=transaction)

        # Delete user statistics
        if await db.exists(f"user_stats/{user_id}", transaction=transaction):
            db.delete_by_transaction(f"user_stats/{user_id}", transaction)

        # Delete user preferences
        if await db.exists(f"user_preferences/{user_id}", transaction=transaction):
            db.delete_by_transaction(f"user_preferences/{user_id}", transaction)

        # Delete user document
        db.delete_by_transaction(f"users/{user_id}", transaction)

    await _delete()
```

## Method Signature

```python
def delete_by_transaction(
    path: str,
    transaction: AsyncTransaction
) -> str:
    """
    Deletes document in transaction.

    Args:
        path: Complete document path (e.g., "users/abc123")
        transaction: Active transaction

    Returns:
        str: Document ID
    """
```

## Examples

### Simple Delete

```python
@db.transaction()
async def delete_session(transaction: AsyncTransaction, session_id: str):
    """Deletes a user session."""

    db.delete_by_transaction(f"sessions/{session_id}", transaction)
```

### Delete with Validation

```python
@db.transaction()
async def delete_if_owner(
    transaction: AsyncTransaction,
    post_id: str,
    user_id: str
):
    """Deletes post only if user is the owner."""

    # Read post
    post = await db.retrieve(f"posts/{post_id}", transaction=transaction)

    # Validate ownership
    if post["owner_id"] != user_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=_("Você não tem permissão para deletar este post")
        )

    # Delete post
    db.delete_by_transaction(f"posts/{post_id}", transaction)
```

### Delete Multiple Documents

```python
@db.transaction()
async def cancel_order(transaction: AsyncTransaction, order_id: str):
    """Cancels order and restores product stock."""

    # Get order details
    order = await db.retrieve(f"orders/{order_id}", transaction=transaction)

    # Restore product stock
    product = await db.retrieve(f"products/{order['product_id']}", transaction=transaction)
    db.update_by_transaction(
        f"products/{order['product_id']}",
        {"stock": product["stock"] + order["quantity"]},
        transaction
    )

    # Delete order
    db.delete_by_transaction(f"orders/{order_id}", transaction)
```

### Delete with Counter Update

```python
@db.transaction()
async def delete_comment_and_update_count(
    transaction: AsyncTransaction,
    post_id: str,
    comment_id: str
):
    """Deletes comment and decrements post's comment count."""

    # Get post
    post = await db.retrieve(f"posts/{post_id}", transaction=transaction)

    # Delete comment
    db.delete_by_transaction(f"posts/{post_id}/comments/{comment_id}", transaction)

    # Update comment count
    new_count = max(0, post.get("comment_count", 1) - 1)
    db.update_by_transaction(
        f"posts/{post_id}",
        {"comment_count": new_count},
        transaction
    )
```

## Key Points

- ✅ Synchronous method (no `await`)
- ✅ Must be called within `@db.transaction()` decorator
- ✅ Requires **document path** (not collection path)
- ✅ Returns document ID immediately
- ✅ Idempotent (safe to delete non-existent documents)
- ✅ Doesn't delete subcollections automatically
- ⚠️ Must be complete document path (cannot delete collections)

## Complete Transaction Examples

### Archive and Delete

```python
async def archive_and_delete_user(
    db: DatabaseEngine,
    user_id: str
) -> None:
    """Archives user data then deletes original."""

    @db.transaction()
    async def _archive(transaction: AsyncTransaction):
        # Read user data
        user = await db.retrieve(f"users/{user_id}", transaction=transaction)

        # Create archive copy
        db.create_by_transaction(
            f"archived_users/{user_id}",
            {
                **user,
                "archived_at": int(time.time()),
                "original_id": user_id
            },
            transaction
        )

        # Delete original
        db.delete_by_transaction(f"users/{user_id}", transaction)

    await _archive()
```

### Conditional Delete

```python
async def delete_if_expired(
    db: DatabaseEngine,
    token_id: str
) -> bool:
    """Deletes token only if expired."""

    @db.transaction()
    async def _delete_if_expired(transaction: AsyncTransaction) -> bool:
        # Read token
        token = await db.retrieve(f"tokens/{token_id}", transaction=transaction)

        # Check expiration
        if token["expires_at"] > int(time.time()):
            return False  # Not expired yet

        # Delete token
        db.delete_by_transaction(f"tokens/{token_id}", transaction)

        return True

    return await _delete_if_expired()
```

### Delete with Audit Trail

```python
async def delete_with_audit(
    db: DatabaseEngine,
    collection: str,
    doc_id: str,
    deleted_by: str
) -> None:
    """Deletes document and creates audit record."""

    @db.transaction()
    async def _delete_with_audit(transaction: AsyncTransaction):
        # Read document before deletion
        doc = await db.retrieve(f"{collection}/{doc_id}", transaction=transaction)

        # Create audit record
        db.create_by_transaction(
            "audit_log",
            {
                "action": "delete",
                "collection": collection,
                "document_id": doc_id,
                "deleted_by": deleted_by,
                "document_data": doc,  # Backup of deleted data
                "timestamp": int(time.time())
            },
            transaction
        )

        # Delete document
        db.delete_by_transaction(f"{collection}/{doc_id}", transaction)

    await _delete_with_audit()
```

### Cascade Delete

```python
async def delete_campaign_with_ideas(
    db: DatabaseEngine,
    campaign_id: str
) -> int:
    """Deletes campaign and all its ideas."""

    @db.transaction()
    async def _cascade_delete(transaction: AsyncTransaction) -> int:
        # Get all ideas for this campaign
        idea_count = 0
        async for idea in db.list_documents_by(
            f"campaigns/{campaign_id}/ideas",
            transaction=transaction
        ):
            db.delete_by_transaction(
                f"campaigns/{campaign_id}/ideas/{idea['id']}",
                transaction
            )
            idea_count += 1

        # Delete campaign
        db.delete_by_transaction(f"campaigns/{campaign_id}", transaction)

        return idea_count

    deleted_ideas = await _cascade_delete()
    logger.info(f"Deleted campaign and {deleted_ideas} ideas")
```

## Error Handling

```python
@db.transaction()
async def safe_delete(transaction: AsyncTransaction, doc_id: str):
    """Deletes document with proper error handling."""

    try:
        # Optional: Check if exists first
        if not await db.exists(f"documents/{doc_id}", transaction=transaction):
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=_("Documento não encontrado")
            )

        # Delete
        db.delete_by_transaction(f"documents/{doc_id}", transaction)

        logger.info(f"Deleted document: {doc_id}")

    except HTTPException:
        # Re-raise HTTP exceptions
        raise
    except Exception as e:
        logger.error(f"Unexpected error deleting document: {e}")
        raise

await safe_delete(doc_id="abc123")
```

## Subcollections Handling

⚠️ **Important**: Delete does NOT automatically delete subcollections!

```python
@db.transaction()
async def delete_with_subcollections(transaction: AsyncTransaction, user_id: str):
    """Properly deletes document and its subcollections."""

    # ❌ WRONG: Only deletes parent
    # db.delete_by_transaction(f"users/{user_id}", transaction)
    # Subcollections remain!

    # ✅ CORRECT: Delete subcollections first

    # Delete orders subcollection
    async for order in db.list_documents_by(f"users/{user_id}/orders", transaction=transaction):
        db.delete_by_transaction(f"users/{user_id}/orders/{order['id']}", transaction)

    # Delete sessions subcollection
    async for session in db.list_documents_by(f"users/{user_id}/sessions", transaction=transaction):
        db.delete_by_transaction(f"users/{user_id}/sessions/{session['id']}", transaction)

    # Finally delete parent document
    db.delete_by_transaction(f"users/{user_id}", transaction)
```

## Performance Considerations

```python
# ✅ GOOD: Batch subcollection deletion
@db.transaction()
async def efficient_cascade_delete(transaction: AsyncTransaction, parent_id: str):
    # Collect all subcollection documents
    to_delete = []
    async for doc in db.list_documents_by(f"parents/{parent_id}/children", transaction=transaction):
        to_delete.append(doc["id"])

    # Delete all in transaction (up to transaction limit)
    for doc_id in to_delete:
        db.delete_by_transaction(f"parents/{parent_id}/children/{doc_id}", transaction)

    # Delete parent
    db.delete_by_transaction(f"parents/{parent_id}", transaction)

# ⚠️ Note: If subcollection has >500 docs, you'll hit transaction limit
# In that case, use batch operations instead
```

## Best Practices

### ✅ DO

```python
# ✅ Check existence before delete if needed
if await db.exists(f"docs/{doc_id}", transaction=transaction):
    db.delete_by_transaction(f"docs/{doc_id}", transaction)

# ✅ Delete subcollections first
# (delete children before parent)

# ✅ Create audit trail for important deletes
db.create_by_transaction("audit_log", audit_data, transaction)
db.delete_by_transaction(f"docs/{doc_id}", transaction)
```

### ❌ DON'T

```python
# ❌ Don't forget subcollections
db.delete_by_transaction(f"users/{user_id}", transaction)  # Subcollections remain!

# ❌ Don't use collection paths
db.delete_by_transaction("users", transaction)  # ❌ Invalid!

# ❌ Don't delete without validation for sensitive data
db.delete_by_transaction(f"orders/{order_id}", transaction)  # Check permissions first!
```

## Related

- [Delete Document](./delete-document.md)
- [Batch Delete](./batch-delete.md)
- [Create in Transaction](./create-transaction.md)
- [Update in Transaction](./update-transaction.md)
- [Basic Transaction Pattern](./transaction-basic.md)
