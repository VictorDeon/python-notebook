# Create Document with Auto-Generated ID

## Use Case

When you want Firestore to generate a unique document ID automatically.

## Pattern

```python
from engines.database import DatabaseEngine

async def create_user(db: DatabaseEngine, user_data: dict) -> str:
    """
    Creates a new user with auto-generated ID.

    Returns:
        str: The generated document ID
    """

    # Pass collection path (odd number of segments)
    user_id = await db.create(
        path="users",
        data=user_data
    )

    return user_id
```

## Example

```python
user_data = {
    "name": "John Doe",
    "email": "john@example.com",
    "created_at": 1704067200
}

user_id = await db.create("users", user_data)
# Returns: "abc123def456" (auto-generated)

# Document is created at: users/abc123def456
# Document contains: { "id": "abc123def456", "name": "John Doe", ... }
```

## Key Points

- ✅ Use **collection path** (e.g., `"users"`)
- ✅ DatabaseEngine automatically adds `"id"` field to the document
- ✅ Returns the generated document ID as string
- ✅ Throws `HTTPException` on error (already internationalized)

## Transaction Equivalent

```python
@db.transaction()
async def create_user_in_transaction(transaction: AsyncTransaction, user_data: dict):
    user_id = db.create_by_transaction(
        path="users",
        data=user_data,
        transaction=transaction
    )
    return user_id

user_id = await create_user_in_transaction(user_data)
```

## Related

- [Create with Specific ID](./create-specific-id.md)
- [Create in Transaction](./create-transaction.md)
- [Batch Create](./batch-create.md)
