# Create Document with Specific ID

## Use Case

When you need to specify the document ID yourself (e.g., using user's UID from Firebase Auth).

## Pattern

```python
from engines.database import DatabaseEngine

async def create_user_profile(db: DatabaseEngine, user_id: str, profile_data: dict) -> str:
    """
    Creates a user profile with specific user ID.

    Args:
        user_id: The Firebase Auth UID
        profile_data: User profile information

    Returns:
        str: The document ID (same as user_id)
    """

    # Pass complete document path (even number of segments)
    doc_id = await db.create(
        path=f"users/{user_id}",
        data=profile_data
    )

    return doc_id
```

## Example

```python
profile_data = {
    "name": "Jane Smith",
    "email": "jane@example.com",
    "created_at": 1704067200
}

# Using Firebase Auth UID
user_id = "firebase_uid_xyz789"

doc_id = await db.create(f"users/{user_id}", profile_data)
# Returns: "firebase_uid_xyz789"

# Document is created at: users/firebase_uid_xyz789
# Document contains: { "id": "firebase_uid_xyz789", "name": "Jane Smith", ... }
```

## Key Points

- ✅ Use **document path** (e.g., `"users/abc123"`)
- ✅ Document ID is extracted from the path
- ✅ DatabaseEngine automatically adds `"id"` field matching the document ID
- ✅ Throws `HTTPException` if document already exists
- ⚠️ Use `update()` with `merge=True` to overwrite if document might exist

## Error Handling

```python
from fastapi import HTTPException, status

try:
    await db.create(f"users/{user_id}", profile_data)
except HTTPException as e:
    if e.status_code == status.HTTP_409_CONFLICT:
        # Document already exists
        # Use update with merge instead
        await db.update(f"users/{user_id}", profile_data, merge=True)
    else:
        raise
```

## Related

- [Create with Auto ID](./create-auto-id.md)
- [Update with Merge](./update-merge.md)
- [Create in Transaction](./create-transaction.md)
