# List Documents with Filters

## Use Case

Query documents that match specific criteria.

## Pattern

```python
from engines.database import DatabaseEngine, Filter

async def get_active_users(db: DatabaseEngine) -> list[dict]:
    """
    Retrieves all active users.

    Returns:
        list[dict]: List of active users
    """

    filters = [
        Filter(field="status", operator="==", value="active")
    ]

    users = []
    async for user in db.list_documents_by("users", filters=filters):
        users.append(user)

    return users
```

## Examples

### Single Filter

```python
from engines.database import Filter

# Users with specific status
filters = [Filter(field="status", operator="==", value="active")]
async for user in db.list_documents_by("users", filters=filters):
    print(user["name"])
```

### Multiple Filters (AND)

```python
# Active users with more than 100 points
filters = [
    Filter(field="status", operator="==", value="active"),
    Filter(field="points", operator=">", value=100)
]

async for user in db.list_documents_by("users", filters=filters):
    print(f"{user['name']}: {user['points']} points")
```

### Range Filters

```python
# Users created in the last 30 days
thirty_days_ago = int(time.time()) - (30 * 24 * 60 * 60)

filters = [
    Filter(field="created_at", operator=">=", value=thirty_days_ago)
]

async for user in db.list_documents_by("users", filters=filters):
    print(f"Recent user: {user['name']}")
```

## Supported Operators

| Operator | Description | Example |
|----------|-------------|---------|
| `==` | Equal | `Filter(field="status", operator="==", value="active")` |
| `!=` | Not equal | `Filter(field="status", operator="!=", value="deleted")` |
| `<` | Less than | `Filter(field="age", operator="<", value=18)` |
| `<=` | Less or equal | `Filter(field="points", operator="<=", value=100)` |
| `>` | Greater than | `Filter(field="points", operator=">", value=0)` |
| `>=` | Greater or equal | `Filter(field="created_at", operator=">=", value=timestamp)` |
| `array-contains` | Array contains value | `Filter(field="tags", operator="array-contains", value="vip")` |
| `array-contains-any` | Array contains any | `Filter(field="tags", operator="array-contains-any", value=["vip", "premium"])` |
| `in` | Field in list | `Filter(field="status", operator="in", value=["active", "pending"])` |
| `not-in` | Field not in list | `Filter(field="status", operator="not-in", value=["deleted", "banned"])` |

## Array Operations

```python
# Users with "premium" tag
filters = [
    Filter(field="tags", operator="array-contains", value="premium")
]

# Users with any of these roles
filters = [
    Filter(field="roles", operator="array-contains-any", value=["admin", "moderator"])
]
```

## IN Queries

```python
# Users with specific IDs
user_ids = ["abc123", "def456", "ghi789"]
filters = [
    Filter(field="id", operator="in", value=user_ids)
]

async for user in db.list_documents_by("users", filters=filters):
    print(user["name"])
```

## Important Limitations

### ⚠️ Range Filters

Only **one field** can have range filters (`<`, `<=`, `>`, `>=`):

```python
# ❌ BAD: Multiple fields with range filters
filters = [
    Filter(field="age", operator=">", value=18),      # Range filter on 'age'
    Filter(field="points", operator=">", value=100)   # Range filter on 'points' ❌
]

# ✅ GOOD: Range filter on one field only
filters = [
    Filter(field="age", operator="==", value=25),     # Equality filter
    Filter(field="points", operator=">", value=100)   # Range filter on one field
]
```

### ⚠️ Composite Indexes Required

Complex queries require composite indexes in `firestore.indexes.json`:

```python
# This query requires composite index
filters = [
    Filter(field="status", operator="==", value="active"),
    Filter(field="created_at", operator=">", value=timestamp)
]
```

Add to `firestore.indexes.json`:
```json
{
  "collectionGroup": "users",
  "queryScope": "COLLECTION",
  "fields": [
    { "fieldPath": "status", "order": "ASCENDING" },
    { "fieldPath": "created_at", "order": "DESCENDING" }
  ]
}
```

## Combining with Other Options

```python
from engines.database import Filter, OrderBy, OrderDirection

# Filtered, ordered, and limited
filters = [Filter(field="status", operator="==", value="active")]
order_by = [OrderBy(field="points", direction=OrderDirection.DESCENDING)]

async for user in db.list_documents_by(
    "users",
    filters=filters,
    order_by=order_by,
    limit=10
):
    print(f"Top user: {user['name']} with {user['points']} points")
```

## Related

- [List with Ordering](./list-ordering.md)
- [List with Limit](./list-limit.md)
- [Pagination with Filters](./pagination-advanced.md)
- [Firestore Optimization Skill](../../firestore-optimization/SKILL.md)
