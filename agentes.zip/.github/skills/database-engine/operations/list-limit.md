# List Documents with Limit

## Use Case

Retrieve only a specific number of documents from a collection.

## Pattern

```python
from engines.database import DatabaseEngine

async def get_recent_posts(db: DatabaseEngine, count: int = 10) -> list[dict]:
    """
    Retrieves the most recent posts.

    Args:
        count: Number of posts to retrieve

    Returns:
        list[dict]: List of recent posts
    """

    from engines.database import OrderBy, OrderDirection

    order_by = [OrderBy(field="created_at", direction=OrderDirection.DESCENDING)]

    posts = []
    async for post in db.list_documents_by("posts", order_by=order_by, limit=count):
        posts.append(post)

    return posts
```

## Examples

### Simple Limit

```python
# Get first 10 users
users = []
async for user in db.list_documents_by("users", limit=10):
    users.append(user)
```

### Limit with Ordering

```python
from engines.database import OrderBy, OrderDirection

# Top 5 users by points
order_by = [OrderBy(field="points", direction=OrderDirection.DESCENDING)]

async for user in db.list_documents_by("users", order_by=order_by, limit=5):
    print(f"#{len(users)+1}: {user['name']} - {user['points']} points")
```

### Limit with Filters

```python
from engines.database import Filter

# First 20 active users
filters = [Filter(field="status", operator="==", value="active")]

async for user in db.list_documents_by("users", filters=filters, limit=20):
    print(user["name"])
```

## Key Points

- ✅ Use `limit` parameter to restrict result count
- ✅ Improves performance by fetching only needed documents
- ✅ Reduces data transfer and processing time
- ✅ Essential for "top N" queries
- ⚠️ For pagination, use `list_paginated_documents` instead

## Common Use Cases

### Top N Items

```python
async def get_leaderboard(db: DatabaseEngine, top_n: int = 10) -> list[dict]:
    """Gets top N users by score."""
    order_by = [OrderBy(field="score", direction=OrderDirection.DESCENDING)]

    leaderboard = []
    async for user in db.list_documents_by("users", order_by=order_by, limit=top_n):
        leaderboard.append(user)

    return leaderboard
```

### Recent Items

```python
async def get_recent_activities(db: DatabaseEngine, limit: int = 50) -> list[dict]:
    """Gets recent user activities."""
    order_by = [OrderBy(field="timestamp", direction=OrderDirection.DESCENDING)]

    activities = []
    async for activity in db.list_documents_by("activities", order_by=order_by, limit=limit):
        activities.append(activity)

    return activities
```

### Sample Data

```python
async def get_sample_users(db: DatabaseEngine, sample_size: int = 5) -> list[dict]:
    """Gets a sample of users for testing."""
    users = []
    async for user in db.list_documents_by("users", limit=sample_size):
        users.append(user)

    return users
```

## Limit vs Pagination

### Use `limit` when:
- ✅ You need top N results (leaderboards, recent items)
- ✅ You want a fixed-size sample
- ✅ Results will fit in memory
- ✅ No user navigation needed

### Use `list_paginated_documents` when:
- ✅ Results may be large (>100 items)
- ✅ Users will navigate through pages
- ✅ You need "next page" functionality
- ✅ Better UX with cursor-based navigation

```python
# ❌ BAD: Using limit for large result sets
users = []
async for user in db.list_documents_by("users", limit=1000):  # Too many!
    users.append(user)

# ✅ GOOD: Use pagination instead
users, next_cursor = await db.list_paginated_documents("users", limit=50)
```

## Performance Considerations

```python
# ✅ GOOD: Limit reduces data transfer
async for post in db.list_documents_by("posts", limit=10):
    process(post)

# ❌ BAD: No limit, processes all documents
async for post in db.list_documents_by("posts"):  # Potentially thousands!
    process(post)
```

## Combining All Query Options

```python
from engines.database import Filter, OrderBy, OrderDirection

# Complex query: filtered, ordered, and limited
filters = [
    Filter(field="status", operator="==", value="active"),
    Filter(field="points", operator=">", value=100)
]
order_by = [
    OrderBy(field="points", direction=OrderDirection.DESCENDING)
]

top_users = []
async for user in db.list_documents_by(
    "users",
    filters=filters,
    order_by=order_by,
    limit=10
):
    top_users.append(user)

# Returns: Top 10 active users with more than 100 points
```

## Related

- [List All Documents](./list-all.md)
- [List with Filters](./list-filters.md)
- [List with Ordering](./list-ordering.md)
- [Cursor-Based Pagination](./pagination-cursor.md)
