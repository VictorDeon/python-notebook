# Batch Update Operation

## Use Case

Update multiple existing documents efficiently in a single batch operation.

## Pattern

```python
from engines.database import DatabaseEngine, BatchResult

async def update_products_price(
    db: DatabaseEngine,
    updates: list[dict]
) -> BatchResult:
    """
    Updates prices for multiple products in batch.

    Args:
        updates: List of dicts with 'id' and fields to update

    Returns:
        BatchResult: Summary of batch operation
    """

    result = await db.update_by_batch(
        collection="products",
        data=updates
    )

    return result
```

## Examples

### Basic Batch Update

```python
# Prepare updates (must include 'id' field)
updates = [
    {"id": "prod_1", "price": 39.99, "stock": 150},
    {"id": "prod_2", "price": 59.99, "stock": 75},
    {"id": "prod_3", "price": 29.99, "stock": 200},
]

# Update in batch
result = await db.update_by_batch("products", updates)

print(f"Updated: {result.total_succeeded}/{result.total_attempted} products")
```

### Bulk Status Update

```python
async def activate_users(db: DatabaseEngine, user_ids: list[str]) -> BatchResult:
    """Activates multiple users at once."""

    # Prepare updates
    updates = []
    current_time = int(time.time())

    for user_id in user_ids:
        updates.append({
            "id": user_id,
            "status": "active",
            "activated_at": current_time
        })

    # Batch update
    result = await db.update_by_batch("users", updates)

    logger.info(f"Activated {result.total_succeeded} users")

    return result

# Usage
user_ids = ["user_1", "user_2", "user_3", "user_4"]
await activate_users(db, user_ids)
```

### Update from Query Results

```python
async def update_expired_subscriptions(db: DatabaseEngine) -> BatchResult:
    """Updates all expired subscriptions to inactive status."""

    # Find expired subscriptions
    current_time = int(time.time())
    filters = [Filter(field="expires_at", operator="<", value=current_time)]

    # Collect IDs and prepare updates
    updates = []
    async for sub in db.list_documents_by("subscriptions", filters=filters):
        updates.append({
            "id": sub["id"],
            "status": "inactive",
            "updated_at": current_time
        })

    # Batch update
    result = await db.update_by_batch("subscriptions", updates)

    return result
```

### Partial Field Update

```python
async def update_user_preferences(
    db: DatabaseEngine,
    preferences_updates: dict[str, dict]
) -> BatchResult:
    """Updates preferences for multiple users.

    Args:
        preferences_updates: Dict mapping user_id to preference changes

    Example:
        {
            "user_1": {"theme": "dark", "language": "en"},
            "user_2": {"theme": "light", "notifications": True}
        }
    """

    # Convert to batch format
    updates = []
    for user_id, prefs in preferences_updates.items():
        updates.append({
            "id": user_id,
            **prefs,
            "updated_at": int(time.time())
        })

    # Batch update (only updates specified fields)
    result = await db.update_by_batch("users", updates)

    return result
```

## Important: ID Field Required

**Every dict in the `data` list MUST include an `"id"` field:**

```python
# ✅ CORRECT
updates = [
    {"id": "doc_1", "field": "value"},  # ✅ Has 'id'
    {"id": "doc_2", "field": "value"}   # ✅ Has 'id'
]

# ❌ WRONG
updates = [
    {"field": "value"},  # ❌ Missing 'id'
    {"field": "value"}   # ❌ Missing 'id'
]

result = await db.update_by_batch("collection", updates)
# Documents without 'id' will be skipped and logged
```

## Key Points

- ✅ Efficient for updating 10+ documents
- ✅ Automatically chunks requests (450 docs per chunk)
- ✅ Built-in retry logic for transient failures
- ✅ Only updates specified fields (partial update)
- ✅ Each document must have `"id"` field
- ⚠️ `"id"` field is not written to document (automatically removed)
- ⚠️ Partial failures possible (check `total_failed`)
- ⚠️ Not atomic (unlike transactions)

## Field Update Behavior

```python
# Before update
# Document: { "id": "user_1", "name": "John", "email": "john@example.com", "points": 100 }

updates = [{"id": "user_1", "email": "newemail@example.com"}]

await db.update_by_batch("users", updates)

# After update
# Document: { "id": "user_1", "name": "John", "email": "newemail@example.com", "points": 100 }
# Only 'email' changed, other fields remain unchanged
```

## Error Handling

```python
async def safe_batch_update(
    db: DatabaseEngine,
    collection: str,
    updates: list[dict]
) -> BatchResult:
    """Batch update with validation and error handling."""

    # Validate all updates have 'id'
    valid_updates = []
    for update in updates:
        if "id" not in update:
            logger.warning(f"Update missing 'id', skipping: {update}")
            continue
        valid_updates.append(update)

    if not valid_updates:
        return BatchResult(total_attempted=0, total_succeeded=0, total_failed=0)

    try:
        result = await db.update_by_batch(collection, valid_updates)

        # Check for failures
        if result.total_failed > 0:
            logger.warning(
                f"Partial batch update failure",
                json_data={
                    "collection": collection,
                    "succeeded": result.total_succeeded,
                    "failed": result.total_failed
                }
            )

        return result

    except HTTPException as e:
        logger.error(f"Batch update failed: {e.detail}")
        raise
```

## Performance Comparison

```python
# ❌ BAD: Loop update (slow)
for user_id in user_ids:  # 100 users
    await db.update(f"users/{user_id}", {"status": "active"})
# Time: ~10 seconds (100 network calls)

# ✅ GOOD: Batch update
updates = [{"id": user_id, "status": "active"} for user_id in user_ids]
result = await db.update_by_batch("users", updates)
# Time: ~1 second (3 network calls with chunking)
```

## When to Use

### ✅ Use Batch Update When:
- Updating 10+ documents at once
- Bulk status changes
- Mass field updates
- Background data processing
- Syncing external data changes

### ❌ Use Regular Update When:
- Updating 1-5 documents
- Need atomic guarantee (use transactions)
- Updates depend on current values (use transactions)
- Individual validation required

## Complex Example: Conditional Batch Update

```python
async def update_active_high_score_users(db: DatabaseEngine, bonus_points: int) -> BatchResult:
    """Adds bonus points to active users with high scores."""

    # Step 1: Query users
    filters = [
        Filter(field="status", operator="==", value="active"),
        Filter(field="score", operator=">", value=1000)
    ]

    # Step 2: Collect current scores
    updates = []
    async for user in db.list_documents_by("users", filters=filters):
        updates.append({
            "id": user["id"],
            "score": user["score"] + bonus_points,  # ⚠️ Race condition possible!
            "bonus_applied_at": int(time.time())
        })

    # Step 3: Batch update
    result = await db.update_by_batch("users", updates)

    return result

# ⚠️ Note: This has a race condition. For accurate counters, use transactions!
```

## Best Practices

### ✅ DO

```python
# ✅ Validate IDs exist
updates = [u for u in updates if "id" in u]

# ✅ Check results
result = await db.update_by_batch("collection", updates)
if result.total_failed > 0:
    handle_failures()

# ✅ Add timestamps
updates = [
    {"id": doc_id, "updated_at": int(time.time()), **data}
    for doc_id, data in changes.items()
]
```

### ❌ DON'T

```python
# ❌ Don't use for counter updates (use transactions)
updates = [{"id": uid, "points": user["points"] + 10} for uid, user in users.items()]
await db.update_by_batch("users", updates)  # Race condition! ❌

# ❌ Don't ignore missing IDs
await db.update_by_batch("collection", updates)  # Some may be missing 'id' ❌

# ❌ Don't use for small batches
if len(updates) < 5:
    await db.update_by_batch("collection", updates)  # Use regular update instead
```

## Related

- [Batch Create](./batch-create.md)
- [Batch Delete](./batch-delete.md)
- [Handling Batch Results](./batch-results.md)
- [Update Fields](./update-fields.md)
- [Transaction Read-Write](./transaction-read-write.md)
