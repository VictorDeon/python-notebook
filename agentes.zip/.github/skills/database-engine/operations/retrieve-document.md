# Retrieve Single Document

## Use Case

Fetch a single document by its full path.

## Pattern

```python
from engines.database import DatabaseEngine

async def get_user(db: DatabaseEngine, user_id: str) -> dict:
    """
    Retrieves a user document.

    Args:
        user_id: The user document ID

    Returns:
        dict: User data with 'id' field included

    Raises:
        HTTPException 404: User not found
    """

    user = await db.retrieve(f"users/{user_id}")
    return user
```

## Example

```python
user = await db.retrieve("users/abc123")

# Returns:
# {
#     "id": "abc123",
#     "name": "John Doe",
#     "email": "john@example.com",
#     "created_at": 1704067200
# }
```

## Key Points

- ✅ Use **document path** (e.g., `"users/abc123"`)
- ✅ Returns `dict` with `"id"` field automatically added
- ✅ Throws `HTTPException 404` if document doesn't exist
- ✅ Automatically logged with execution time

## Custom Timeout

```python
# For potentially slow operations
user = await db.retrieve(
    "users/abc123",
    timeout=10.0  # 10 seconds instead of default
)
```

## Within Transaction

```python
@db.transaction()
async def get_user_in_transaction(transaction: AsyncTransaction, user_id: str):
    user = await db.retrieve(f"users/{user_id}", transaction=transaction)
    return user

user = await get_user_in_transaction(user_id="abc123")
```

## Handling Not Found

```python
from fastapi import HTTPException, status

async def get_user_or_none(db: DatabaseEngine, user_id: str) -> dict | None:
    """Returns user or None if not found."""
    try:
        return await db.retrieve(f"users/{user_id}")
    except HTTPException as e:
        if e.status_code == status.HTTP_404_NOT_FOUND:
            return None
        raise
```

## Related

- [Check Document Existence](./check-existence.md)
- [Retrieve in Transaction](./retrieve-transaction.md)
- [List Documents](./list-all.md)
