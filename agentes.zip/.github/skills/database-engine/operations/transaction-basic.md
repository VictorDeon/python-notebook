# Basic Transaction Pattern

## Use Case

Perform atomic operations that must all succeed or all fail (e.g., transferring points between users).

## Pattern

```python
from engines.database import DatabaseEngine
from google.cloud.firestore_v1 import AsyncTransaction

async def transfer_points(
    db: DatabaseEngine,
    from_user_id: str,
    to_user_id: str,
    points: int
) -> None:
    """
    Transfers points from one user to another atomically.

    Args:
        from_user_id: Source user ID
        to_user_id: Destination user ID
        points: Number of points to transfer

    Raises:
        HTTPException 400: Insufficient points
    """

    @db.transaction()
    async def _transfer(transaction: AsyncTransaction):
        # Read phase: Get current values
        from_user = await db.retrieve(f"users/{from_user_id}", transaction=transaction)
        to_user = await db.retrieve(f"users/{to_user_id}", transaction=transaction)

        # Validation
        if from_user["points"] < points:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=_("Pontos insuficientes para transferência")
            )

        # Write phase: Update both users
        db.update_by_transaction(
            path=f"users/{from_user_id}",
            data={"points": from_user["points"] - points},
            transaction=transaction
        )

        db.update_by_transaction(
            path=f"users/{to_user_id}",
            data={"points": to_user["points"] + points},
            transaction=transaction
        )

    # Execute transaction
    await _transfer()
```

## Key Concepts

### Transaction Decorator

The `@db.transaction()` decorator handles:
- ✅ Transaction creation and management
- ✅ Automatic retries on conflicts
- ✅ Commit/rollback logic
- ✅ Error propagation

### Transaction Phases

1. **Read Phase**: Fetch all needed documents
2. **Business Logic**: Validate and calculate new values
3. **Write Phase**: Apply all changes

**Important**: All reads must come **before** any writes in a transaction.

## Examples

### Increment Counter

```python
@db.transaction()
async def increment_post_views(transaction: AsyncTransaction, post_id: str):
    """Atomically increments post view count."""

    # Read current value
    post = await db.retrieve(f"posts/{post_id}", transaction=transaction)

    # Calculate new value
    new_views = post.get("views", 0) + 1

    # Write new value
    db.update_by_transaction(
        f"posts/{post_id}",
        {"views": new_views},
        transaction
    )

await increment_post_views(post_id="abc123")
```

### Create with Validation

```python
@db.transaction()
async def create_order_if_available(
    transaction: AsyncTransaction,
    product_id: str,
    user_id: str,
    quantity: int
):
    """Creates order only if product has sufficient stock."""

    # Read product
    product = await db.retrieve(f"products/{product_id}", transaction=transaction)

    # Validate stock
    if product["stock"] < quantity:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=_("Estoque insuficiente")
        )

    # Create order
    order_id = db.create_by_transaction(
        "orders",
        {
            "user_id": user_id,
            "product_id": product_id,
            "quantity": quantity,
            "created_at": int(time.time())
        },
        transaction
    )

    # Update stock
    db.update_by_transaction(
        f"products/{product_id}",
        {"stock": product["stock"] - quantity},
        transaction
    )

    return order_id

order_id = await create_order_if_available(
    product_id="prod_123",
    user_id="user_456",
    quantity=2
)
```

### Delete with Dependencies

```python
@db.transaction()
async def delete_user_with_stats(transaction: AsyncTransaction, user_id: str):
    """Deletes user and their statistics atomically."""

    # Verify user exists
    user = await db.retrieve(f"users/{user_id}", transaction=transaction)

    # Delete user stats
    if await db.exists(f"user_stats/{user_id}", transaction=transaction):
        db.delete_by_transaction(f"user_stats/{user_id}", transaction)

    # Delete user
    db.delete_by_transaction(f"users/{user_id}", transaction)

await delete_user_with_stats(user_id="abc123")
```

## Transaction Methods

| Method | Purpose | Returns |
|--------|---------|---------|
| `create_by_transaction(path, data, transaction)` | Create document | `str` (doc ID) |
| `update_by_transaction(path, data, transaction)` | Update document | `str` (doc ID) |
| `delete_by_transaction(path, transaction)` | Delete document | `str` (doc ID) |
| `retrieve(path, transaction=transaction)` | Read document | `dict` |
| `exists(path, transaction=transaction)` | Check existence | `bool` |

## Key Points

- ✅ All operations are atomic (all succeed or all fail)
- ✅ Automatic retries on contention
- ✅ Reads must come before writes
- ✅ Maximum 500 operations per transaction
- ✅ Use for operations requiring consistency
- ⚠️ Don't use for long-running operations
- ⚠️ Don't make external API calls inside transactions

## Best Practices

### ✅ DO

```python
@db.transaction()
async def good_transaction(transaction: AsyncTransaction):
    # 1. Read all data first
    user = await db.retrieve("users/123", transaction=transaction)
    config = await db.retrieve("configs/default", transaction=transaction)

    # 2. Perform calculations
    new_value = calculate_something(user, config)

    # 3. Write all changes
    db.update_by_transaction("users/123", {"value": new_value}, transaction)
```

### ❌ DON'T

```python
@db.transaction()
async def bad_transaction(transaction: AsyncTransaction):
    # ❌ DON'T: Mix reads and writes
    user = await db.retrieve("users/123", transaction=transaction)
    db.update_by_transaction("users/123", {"points": 100}, transaction)
    other = await db.retrieve("users/456", transaction=transaction)  # ❌ Read after write

    # ❌ DON'T: Make external API calls
    await send_email(user["email"])  # ❌ External call in transaction

    # ❌ DON'T: Long computations
    time.sleep(10)  # ❌ Blocking operation
```

## Error Handling

Transactions automatically handle retries and rollbacks:

```python
@db.transaction()
async def my_transaction(transaction: AsyncTransaction):
    try:
        user = await db.retrieve("users/123", transaction=transaction)

        # Custom validation
        if user["status"] == "banned":
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=_("Usuário banido")
            )

        db.update_by_transaction("users/123", {"last_login": int(time.time())}, transaction)

    except HTTPException:
        # HTTPException is propagated (transaction rolls back automatically)
        raise
    except Exception as e:
        # Log unexpected errors
        logger.error(f"Transaction failed: {e}")
        raise

# If transaction fails, all changes are rolled back automatically
await my_transaction()
```

## Related

- [Transaction Read-Modify-Write](./transaction-read-write.md)
- [Transaction Error Handling](./transaction-errors.md)
- [Create in Transaction](./create-transaction.md)
- [Update in Transaction](./update-transaction.md)
