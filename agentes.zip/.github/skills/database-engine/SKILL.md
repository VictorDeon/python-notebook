---
name: database-engine
description: Essential skill for interacting with Cloud Firestore through the DatabaseEngine abstraction. Covers CRUD operations, queries with filters and pagination, transactions, batch operations, error handling, and best practices for efficient and safe database access. Use this skill when implementing controllers that need to read, write, update, or delete data in Firestore, ensuring proper abstraction, observability, and error handling.
---

# Skill: DatabaseEngine Usage

## Purpose

Ensure correct and efficient usage of the `DatabaseEngine` abstraction for all Firestore operations, avoiding direct use of raw Firestore client.

## When to Use

- When implementing controllers that interact with Firestore
- When reviewing database access patterns
- When validating error handling for database operations
- When implementing queries, pagination, transactions, or batch operations
- When troubleshooting database-related issues

## Severity

🔴 **HIGH** — Incorrect database access patterns can lead to data inconsistency, poor performance, and hard-to-debug issues

---

## Core Principles

### ✅ Always Use DatabaseEngine

**NEVER** use the raw Firestore client (`AsyncClient`) directly in controllers. Always use the `DatabaseEngine` abstraction.

**Why?**
- Centralized error handling with internationalized messages
- Automatic logging and observability
- Consistent timeout configuration
- Simplified API with clear semantics
- Transaction and batch operation support

### ✅ Path Conventions

DatabaseEngine uses two types of paths:

1. **Collection Path** (odd segments): `"users"`, `"campaigns/123/ideas"`
2. **Document Path** (even segments): `"users/abc123"`, `"campaigns/123"`

Methods behavior varies based on path type:
- `create()` with collection path → generates auto ID
- `create()` with document path → uses specified ID
- `update()`, `delete()` → **require document path**

---

## DatabaseEngine Operations

### 1. Basic CRUD Operations

#### 1.1 Create Document

* [Create with Auto-Generated ID](./operations/create-auto-id.md)
* [Create with Specific ID](./operations/create-specific-id.md)
* [Create in Transaction](./operations/create-transaction.md)

#### 1.2 Retrieve Document

* [Retrieve Single Document](./operations/retrieve-document.md)
* [Check Document Existence](./operations/check-existence.md)
* [Retrieve in Transaction](./operations/retrieve-transaction.md)

#### 1.3 Update Document

* [Update Existing Fields](./operations/update-fields.md)
* [Merge New Fields](./operations/update-merge.md)
* [Update in Transaction](./operations/update-transaction.md)

#### 1.4 Delete Document

* [Delete Document](./operations/delete-document.md)
* [Delete in Transaction](./operations/delete-transaction.md)

---

### 2. Query Operations

#### 2.1 List Documents (Streaming)

* [List All Documents](./operations/list-all.md)
* [List with Filters](./operations/list-filters.md)
* [List with Ordering](./operations/list-ordering.md)
* [List with Limit](./operations/list-limit.md)
* [Count Documents](./operations/count.md)

#### 2.2 Paginated Listing

* [Cursor-Based Pagination](./operations/pagination-cursor.md)
* [Pagination with Filters and Ordering](./operations/pagination-advanced.md)

---

### 3. Transactions

Transactions ensure atomicity: either all operations succeed or all fail.

* [Basic Transaction Pattern](./operations/transaction-basic.md)
* [Transaction with Read-Modify-Write](./operations/transaction-read-write.md)
* [Transaction Error Handling](./operations/transaction-errors.md)

**When to Use Transactions:**
- Updating counters
- Transferring values between documents
- Enforcing business rules that require consistency
- Any operation where you need to read before writing

---

### 4. Batch Operations

Batch operations allow multiple writes in a single commit, improving performance.

* [Batch Create](./operations/batch-create.md)
* [Batch Update](./operations/batch-update.md)
* [Batch Delete](./operations/batch-delete.md)
* [Handling Batch Results](./operations/batch-results.md)

**Batch Limits:**
- Maximum 450 operations per batch (safe limit below Firestore's 500)
- Automatic chunking for larger operations
- Built-in retry logic for transient errors

---

## Error Handling

DatabaseEngine automatically converts Firestore exceptions to appropriate HTTP exceptions:

| Firestore Error | HTTP Status | User Message |
|----------------|-------------|--------------|
| `NotFound` | 404 | Resource not found |
| `BadRequest` | 400 | Database server error |
| `GatewayTimeout` | 504 | Database timeout |
| `BadGateway` | 502 | Database communication error |
| `InternalServerError` | 500 | Unexpected database error |
| `TooManyRequests` | 503 | Service temporarily unavailable |

All error messages are internationalized using `fastapi_babel`.

**Best Practices:**
- Let DatabaseEngine handle Firestore errors
- Only catch specific exceptions if you need custom behavior
- Always log context before operations fail

---

## Filter and OrderBy Usage

### Filter Object

```python
from engines.database import Filter

# Equality
Filter(field="status", operator="==", value="active")

# Comparison
Filter(field="created_at", operator=">=", value=1704067200)
Filter(field="points", operator="<", value=100)

# Array operations
Filter(field="tags", operator="array-contains", value="featured")
Filter(field="categories", operator="in", value=["tech", "business"])
```

### OrderBy Object

```python
from engines.database import OrderBy, OrderDirection

# Ascending order (default)
OrderBy(field="created_at", direction=OrderDirection.ASCENDING)

# Descending order
OrderBy(field="points", direction=OrderDirection.DESCENDING)
```

**Important:**
- Filters and ordering require composite indexes in `firestore.indexes.json`
- Range filters (`<`, `>`, `>=`, `<=`) can only be used on one field
- Always order by `__name__` last for unique pagination cursors (automatic in `list_paginated_documents`)

---

## Observability and Logging

DatabaseEngine automatically logs:
- All operations with path and parameters
- Execution time (duration_ms)
- Transaction/batch context
- Query details (filters, ordering, limits)
- Pagination cursors

**Custom Logger:**
```python
from engines.logger import Logger

# Create custom logger for specific context
logger = Logger(endpoint="MyController", user_id=user.id)
db.change_logger(logger)

# Now all operations will include user_id in logs
await db.retrieve("users/123")
```

---

## Best Practices Checklist

- [ ] Use `DatabaseEngine` instead of raw Firestore client
- [ ] Use correct path type (collection vs document)
- [ ] Handle 404 errors appropriately (when document might not exist)
- [ ] Use transactions for read-modify-write operations
- [ ] Use batch operations for bulk writes (>10 documents)
- [ ] Add appropriate filters and ordering
- [ ] Configure composite indexes for complex queries
- [ ] Use cursor-based pagination for large result sets
- [ ] Set appropriate timeouts for long-running operations
- [ ] Let DatabaseEngine handle error translation
- [ ] Use custom logger for enhanced observability when needed

---

## Common Pitfalls

### ❌ Don't Use Raw Firestore

```python
# ❌ BAD: Direct Firestore access
from engines.connectors import firestore_db
doc = await firestore_db.document("users/123").get()
```

```python
# ✅ GOOD: Use DatabaseEngine
user = await db.retrieve("users/123")
```

### ❌ Don't Ignore Path Types

```python
# ❌ BAD: Wrong path for update
await db.update("users", {"name": "John"})  # Missing document ID
```

```python
# ✅ GOOD: Complete document path
await db.update("users/123", {"name": "John"})
```

### ❌ Don't Forget Transactions for Counters

```python
# ❌ BAD: Race condition possible
user = await db.retrieve("users/123")
new_points = user["points"] + 10
await db.update("users/123", {"points": new_points})
```

```python
# ✅ GOOD: Atomic update with transaction
@db.transaction()
async def add_points(transaction: AsyncTransaction, user_id: str):
    user = await db.retrieve(f"users/{user_id}", transaction=transaction)
    new_points = user["points"] + 10
    db.update_by_transaction(f"users/{user_id}", {"points": new_points}, transaction)

await add_points(user_id="123")
```

### ❌ Don't Use Loop for Bulk Operations

```python
# ❌ BAD: Slow and inefficient
for item in items:
    await db.create("products", item)
```

```python
# ✅ GOOD: Batch operation
result = await db.create_by_batch("products", items)
logger.info(f"Created {result.total_succeeded}/{result.total_attempted} products")
```

---

## Quick Reference

| Operation | Method | Path Type | Returns |
|-----------|--------|-----------|---------|
| Create (auto ID) | `create(collection, data)` | Collection | `str` (doc ID) |
| Create (specific ID) | `create(doc_path, data)` | Document | `str` (doc ID) |
| Retrieve | `retrieve(doc_path)` | Document | `dict` |
| Check exists | `exists(doc_path)` | Document | `bool` |
| Update | `update(doc_path, data)` | Document | `str` (doc ID) |
| Merge | `update(doc_path, data, merge=True)` | Document | `str` (doc ID) |
| Delete | `delete(doc_path)` | Document | `str` (doc ID) |
| List (streaming) | `list_documents_by(collection)` | Collection | `AsyncGenerator[dict]` |
| List (paginated) | `list_paginated_documents(collection)` | Collection | `tuple[list[dict], str\|None]` |
| Batch create | `create_by_batch(collection, data)` | Collection | `BatchResult` |
| Batch update | `update_by_batch(collection, data)` | Collection | `BatchResult` |
| Batch delete | `delete_by_batch(collection, data)` | Collection | `BatchResult` |

---

## Related Skills

- [Firestore Optimization](../firestore-optimization/SKILL.md) - Performance and cost optimization
- [Mock Patterns](../mock-patterns/SKILL.md) - Testing DatabaseEngine operations
- [Observability](../observability/SKILL.md) - Logging and monitoring best practices
