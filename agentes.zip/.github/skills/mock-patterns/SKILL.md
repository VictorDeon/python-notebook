---
name: mock-patterns
description: Mock patterns for FastAPI integration tests that isolate external dependencies (Firestore/DatabaseEngine, authentication, Stripe, Slack, GCS, Cloud Tasks, etc.), showing how to create MagicMock/AsyncMock with descriptive names, side_effect, ANY, and dependency overrides, as well as patterns for transactions, batches, and UploadFile; use whenever it is necessary to ensure deterministic, fast tests without accessing real services.
---

# Skill: Mock Patterns

This skill provides complete mock patterns for creating isolated and deterministic tests.

## When to Use This Skill

* When implementing tests that depend on external services
* When mocking Firestore operations (DatabaseEngine)
* When mocking authentication and authorization
* When mocking integrations with external APIs (Stripe, Slack, GCP, etc.) and their respective Engines

---

## Core Principles

### ✅ Always Use

* `MagicMock` for synchronous objects
* `AsyncMock` for asynchronous operations
* Descriptive names: `name="mock-name"` to facilitate debugging
* `side_effect` to simulate different responses
* `ANY` from `unittest.mock` for dynamic values (timestamps, UUIDs)

### ✅ Always Validate

* `assert_called_once_with()` for single calls
* `assert_awaited_once_with()` for single async calls
* `assert_any_call()` for multiple calls
* `assert_not_called()` to ensure it wasn't called
* `call_count` when appropriate
* Order of operations when relevant

---

## Mock Patterns

### 1. Firestore (DatabaseEngine) Mock

The `DatabaseEngine` is the abstraction used to access Firestore. Mock only the methods necessary for the test.

* [Firestore Mock Basic Pattern](./patterns/firestore-basic-mock.md)
* [Firestore Multiple Calls With Side Effects](./patterns/firestore-multiple-calls-with-side-effect-mock.md)
* [Firestore Async Iterator Mock](./patterns/firestore-async-iterator-mock.md)
* [Firestore Cursor Based Pagination Mock](./patterns/firestore-cursor-based-mock.md)
* [Firestore Transactions Mock](./patterns/firestore-transaction-mock.md)
* [Firestore Batches Mock](./patterns/firestore-batch-mock.md)
* [Firestore Decorator Mock](./patterns/firestore-decorator-mock.md)

### 2. Authentication Mock

For the authenticated user, create a mock of the `User` model with only the data necessary for the test.

* [Authentication User Mock](./patterns/authentication_user_mock.md)
* [Authentication User Mock with Subscription](./patterns/authentication_user_mock_with_subscription.md)

### 3. API Key Mock

* [API Key Mock](./patterns/api-key-mock.md)

### 4. External Services Mock

Always validate the calls and arguments of external service mocks with their corresponding engines.

* [External Services Mock](./patterns/external-services-mock.md)
* [Slack Engine Mock](./patterns/slack-engine-mock.md)
* [Brevo (Email) Engine Mock](./patterns/brevo-engine-mock.md)
* [Google Cloud Storage Mock](./patterns/google-cloud-storage-mock.md)
* [Google Cloud Tasks Mock](./patterns/google-cloud-tasks-mock.md)
* [UploadFile (FastAPI) Mock](./patterns/uploadfile-fastapi-mock.md)

---

## Validation Patterns

* [Basic Validation](./validations/basic-validation.md)
* [Multiple Calls Validation](./validations/multiple-calls-validation.md)
* [Validation with ANY](./validations/validation-with-any.md)

---

## Cleanup and Best Practices

* [Always Clean Overrides](./best-practices/always-clean-overrides.md)
* [Use Context Managers](./best-practices/use-context-managers.md)
* [Organize Mocks in Fixtures](./best-practices/organize-mocks-in-fixtures.md)

---

## Mock Checklist

When creating mocks for a test:

- [ ] Identified all external dependencies
- [ ] Created mocks with descriptive names (`name=`)
- [ ] Used `AsyncMock` for async methods
- [ ] Configured `return_value` or `side_effect`
- [ ] Applied dependency overrides when necessary
- [ ] Added validations with `assert_called_*`
- [ ] Validated call arguments
- [ ] Used `ANY` for dynamic values
- [ ] Cleaned overrides with `app.dependency_overrides.clear()`
- [ ] Mocks are isolated (don't share state)
