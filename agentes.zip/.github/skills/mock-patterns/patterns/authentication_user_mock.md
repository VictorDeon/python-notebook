## Authentication User Mock

```python
from api.authentication.models import User, Address
from api.utils import now
from engines.security import get_current_user

user_mock = User(
    uid="test-uid-123",
    email="test@example.com",
    name="Test User",
    referral_code="REF123",
    phone="+5511999999999",
    document="12345678900",
    created_at=now(),
    updated_at=now(),
    address=Address(
        street="Rua Teste",
        number="123",
        complement="Apto 45",
        neighborhood="Centro",
        city="São Paulo",
        state="SP",
        zip_code="01234567",
        country="BR"
    ),
    tico_coins=1000,
    subscription=None
)

# Override
app.dependency_overrides[get_current_user] = lambda: user_mock
```
