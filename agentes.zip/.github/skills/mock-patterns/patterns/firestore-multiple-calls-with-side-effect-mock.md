## Firestore Mock (Multiple Calls with `side_effect`)

```python
# Simulate multiple calls returning different values
db_engine_mock = MagicMock(
    name="db-engine-mock",
    retrieve=AsyncMock(
        name="db-retrieve-mock",
        side_effect=[
            {"id": "1", "name": "First"},
            {"id": "2", "name": "Second"},
            None  # Third call returns None
        ]
    )
)

# Validate multiple calls
assert db_engine_mock.retrieve.call_count == 3
db_engine_mock.retrieve.assert_any_call("users/1")
db_engine_mock.retrieve.assert_any_call("users/2")
```
