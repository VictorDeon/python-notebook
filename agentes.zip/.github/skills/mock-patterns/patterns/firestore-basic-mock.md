## Firestore Mock (Basic Pattern)

```python
from unittest.mock import MagicMock, AsyncMock, ANY
from api.main import app
from engines.connectors import connect_db

# Mock data
user_data = {
    "uid": "test-uid-123",
    "email": "test@example.com",
    "name": "Test User"
}

# DatabaseEngine mock
db_engine_mock = MagicMock(
    name="db-engine-mock",
    retrieve=AsyncMock(name="db-retrieve-mock", return_value=user_data),
    create=AsyncMock(name="db-create-mock", return_value=None),
    update=AsyncMock(name="db-update-mock", return_value=None),
    delete=AsyncMock(name="db-delete-mock", return_value=None)
)

# Dependency override
app.dependency_overrides[connect_db] = lambda: MagicMock(name="firestore-db-mock")

# Usage in test with patch
with patch("api.module.controller.DatabaseEngine", return_value=db_engine_mock):
    # ... your test here

# Validations
db_engine_mock.retrieve.assert_called_once_with("users/test-uid-123")
db_engine_mock.create.assert_called_once_with(
    path="users",
    data={"uid": "test-uid-123", "email": "test@example.com"},
    transaction=ANY
)
```
