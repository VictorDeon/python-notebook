## Google Cloud Storage Mock

```python
from unittest.mock import MagicMock, AsyncMock, patch

storage_engine_mock = MagicMock(
    name="storage-engine-mock",
    upload_file=AsyncMock(name="upload-file-mock", return_value="https://storage.url/file.jpg"),
    delete_file=AsyncMock(name="delete-file-mock", return_value=None)
)

with patch("api.module.controller.StorageEngine", return_value=storage_engine_mock):
    # ... your test here

storage_engine_mock.upload_file.assert_awaited_once_with(
    file=ANY,
    bucket="test-bucket",
    path="uploads/test.jpg"
)
```
