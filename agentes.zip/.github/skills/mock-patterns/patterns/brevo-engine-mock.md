## Brevo (Email) Engine Mock

```python
from unittest.mock import MagicMock, AsyncMock, patch

brevo_engine_mock = MagicMock(
    name="brevo-engine-mock",
    send_email=AsyncMock(name="send-email-mock", return_value={"messageId": "msg_123"})
)

with patch("api.module.controller.BrevoEngine", return_value=brevo_engine_mock):
    # ... your test here

brevo_engine_mock.send_email.assert_awaited_once_with(
    to="test@example.com",
    subject="Email Subject",
    html_content="<p>HTML Content</p>"
)
```
