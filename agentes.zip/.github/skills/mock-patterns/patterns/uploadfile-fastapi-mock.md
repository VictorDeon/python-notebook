## UploadFile (FastAPI) Mock

```python
from fastapi import UploadFile
from io import BytesIO
from unittest.mock import MagicMock, AsyncMock

# File mock
file_content = b"fake file content"
file_mock = UploadFile(
    filename="test.jpg",
    file=BytesIO(file_content)
)

# For UploadFile async methods
file_mock.read = AsyncMock(return_value=file_content)
file_mock.seek = AsyncMock(return_value=None)
```
