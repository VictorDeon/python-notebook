## Firestore Mock (List Mock with Async Iterator)

```python
# Mock for list_documents_by (returns iterator)
documents = [
    {"id": "1", "name": "Item 1"},
    {"id": "2", "name": "Item 2"}
]

db_engine_mock = MagicMock(name="db-engine-mock")
db_engine_mock.list_documents_by.return_value.__aiter__.return_value = documents

# Usage
async for doc in db_engine_mock.list_documents_by("collection", field="value"):
    print(doc)
```
