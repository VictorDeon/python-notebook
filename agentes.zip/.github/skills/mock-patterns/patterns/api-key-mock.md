## API Key Mock

Mock the `get_api_key` dependency to return a fixed API key for testing purposes.

```python
from engines.security import get_api_key

app.dependency_overrides[get_api_key] = lambda: "test-api-key"
```
