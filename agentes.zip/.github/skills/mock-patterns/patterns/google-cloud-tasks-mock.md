## Google Cloud Tasks Mock

```python
from unittest.mock import MagicMock, AsyncMock, patch

tasks_engine_mock = MagicMock(
    name="tasks-engine-mock",
    create_task=AsyncMock(name="create-task-mock", return_value={"name": "task_123"})
)

with patch("api.module.controller.TasksEngine", return_value=tasks_engine_mock):
    # ... your test here

tasks_engine_mock.create_task.assert_awaited_once_with(
    queue="test-queue",
    payload={"key": "value"},
    schedule_time=ANY
)
```
