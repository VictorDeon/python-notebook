## Firestore Mock (Batch Mock)

```python
user_data = {
    "id": "test-uid",
    "name": "Test User"
}

db_engine_mock = MagicMock(
    name="db-engine-mock",
    retrieve=AsyncMock(return_value=user_data),
    list_paginated_documents=AsyncMock(return_value=([user_data], None)),
    create_by_batch=MagicMock(return_value=None),
    update_by_batch=MagicMock(return_value=None)
)

# Validate that operations were performed within the batch
db_engine_mock.update_by_batch.assert_called_once_with(
    collection="users",
    data=[{"id": "test-uid", "name": "Updated Name"}]
)

# Validate that operations were performed within the batch
db_engine_mock.create_by_batch.assert_called_once_with(
    collection="users",
    data=[{"id": "test-uid", "name": "New Name"}]
)
```
