## Slack Engine Mock

```python
from unittest.mock import MagicMock, AsyncMock, patch

slack_engine_mock = MagicMock(
    name="slack-engine-mock",
    send_message=AsyncMock(name="send-message-mock", return_value=None)
)

with patch("api.module.controller.SlackEngine", return_value=slack_engine_mock):
    # ... your test here

slack_engine_mock.send_message.assert_awaited_once_with(
    text="Expected message",
    channel="#test-channel"
)
```
