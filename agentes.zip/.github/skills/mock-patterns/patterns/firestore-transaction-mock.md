## Firestore Mock (Transaction Mock)

```python
# Transaction context manager mock
transaction_instance_mock = MagicMock(name="transaction-instance-mock")

db_engine_mock = MagicMock(
    name="db-engine-mock",
    retrieve=AsyncMock(return_value=user_data),
    list_documents_by=AsyncMock(return_value=[]),
    update_by_transaction=MagicMock(return_value=None),
    create_by_transaction=MagicMock(return_value=None),
    delete_by_transaction=MagicMock(return_value=None)
)
db_engine_mock.transaction.return_value.__aenter__.return_value = transaction_instance_mock

# Validate that operations were performed within the transaction
db_engine_mock.update_by_transaction.assert_called_once_with(
    path="users/test-uid",
    data={"updated_at": ANY},
    transaction=transaction_instance_mock
)
```
