## Firestore Mock (List Mock with Cursor-based Pagination)

```python
# Mock for list_paginated_documents (returns iterator)
documents = [
    {"id": "1", "name": "Item 1"},
    {"id": "2", "name": "Item 2"}
]

db_engine_mock = MagicMock(name="db-engine-mock")
db_engine_mock.list_paginated_documents.return_value = documents

# Usage
all_docs = await db_engine_mock.list_paginated_documents("collection", last_document_id="1", limit=1)
for doc in all_docs:
    print(doc)
```
