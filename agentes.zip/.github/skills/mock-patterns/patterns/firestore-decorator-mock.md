## Firestore Mock (@async_transactional Decorator Mock)

```python
# Mock for @async_transactional decorator
with patch("api.module.controller.file.async_transactional", lambda func: lambda transaction, *args, **kwargs: func(transaction, *args, **kwargs)):
    # ... your test here

# Usage
@async_transactional
async def your_function(transaction, other_args):
    ...
```
