## Stripe Payment Engine Mock

```python
from unittest.mock import MagicMock, AsyncMock, patch

# Stripe objects mock
checkout_session_mock = MagicMock(
    name="checkout-session-mock",
    id="cs_test_abc123",
    mode="subscription",
    amount_total=5990,
    currency="brl",
    url="https://checkout.stripe.com/c/pay/cs_test_abc123",
    metadata={"type": "subscription"},
    client_reference_id="test-uid-123",
    subscription=MagicMock(id="sub_test_123"),
    customer=MagicMock(id="cus_test_123")
)

price_mock = MagicMock(
    name="price-mock",
    id="price_test_123",
    type="recurring",
    unit_amount=5990,
    currency="brl"
)

customer_mock = MagicMock(
    name="customer-mock",
    id="cus_test_123",
    email="test@example.com"
)

# StripeEngine mock
stripe_engine_mock = MagicMock(
    name="stripe-engine-mock",
    create_customer=AsyncMock(name="create-customer-mock", return_value=customer_mock),
    create_checkout_session=AsyncMock(name="create-checkout-mock", return_value=checkout_session_mock),
    retrieve_price=AsyncMock(name="retrieve-price-mock", return_value=price_mock),
    retrieve_subscription=AsyncMock(name="retrieve-subscription-mock"),
    cancel_subscription=AsyncMock(name="cancel-subscription-mock")
)

# Usage in test
with patch("api.payments.controllers.checkout.StripeEngine", return_value=stripe_engine_mock):
    # ... your test here

# Validations
stripe_engine_mock.create_customer.assert_called_once_with(
    email="test@example.com",
    name="Test User",
    metadata=ANY
)
stripe_engine_mock.create_checkout_session.assert_called_once_with(
    customer_id="cus_test_123",
    price_id="price_test_123",
    mode="subscription",
    success_url=ANY,
    cancel_url=ANY
)
```
