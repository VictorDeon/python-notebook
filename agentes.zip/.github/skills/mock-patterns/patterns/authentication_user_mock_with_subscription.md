## Authentication User Mock with Subscription

```python
from api.payments.models import Subscription
from api.payments.enums import SubscriptionPlan, SubscriptionStatus

subscription_mock = Subscription(
    stripe_subscription_id="sub_test_123",
    stripe_customer_id="cus_test_123",
    stripe_price_id="price_test_123",
    plan=SubscriptionPlan.DIGITAL_HIGHLIGHT,
    status=SubscriptionStatus.ACTIVE,
    created_at=now(),
    updated_at=now()
)

user_mock = User(
    uid="test-uid-123",
    email="test@example.com",
    name="Premium User",
    subscription=subscription_mock,
    # ... other fields
)
```
