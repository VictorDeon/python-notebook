## Organize Mocks in Fixtures

```python
import pytest
from unittest.mock import MagicMock

@pytest.fixture
def db_engine_mock():
    """Reusable fixture for DatabaseEngine."""
    return MagicMock(
        name="db-engine-mock",
        retrieve=AsyncMock(return_value=None),
        create=AsyncMock(return_value=None)
    )

def test_example(db_engine_mock):
    # Use the fixture
    with patch("module.DatabaseEngine", return_value=db_engine_mock):
        # ... test
```
