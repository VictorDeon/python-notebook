## Use Context Managers

```python
# Patches are automatically cleaned when exiting the context
with patch("module.Class", return_value=mock):
    # ... test here
# Patch is automatically undone
```
