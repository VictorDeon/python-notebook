## Validation with ANY

```python
from unittest.mock import ANY

# Useful for timestamps, UUIDs, complex objects
mock.create.assert_called_once_with(
    path="users",
    data={
        "uid": "test-123",
        "created_at": ANY,  # Dynamic timestamp
        "id": ANY  # Generated UUID
    }
)
```
