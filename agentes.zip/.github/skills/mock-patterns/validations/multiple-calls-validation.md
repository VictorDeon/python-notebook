## Multiple Calls Validation

```python
# Check number of calls
assert mock.method.call_count == 3

# Check any call with specific arguments
mock.method.assert_any_call(arg="value1")
mock.method.assert_any_call(arg="value2")

# Check call order
assert mock.method_calls == [
    call(arg="first"),
    call(arg="second"),
    call(arg="third")
]
```
