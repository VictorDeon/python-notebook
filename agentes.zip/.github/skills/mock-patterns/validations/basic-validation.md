## Basic Validation

```python
# Status code
assert response.status_code == status.HTTP_200_OK

# JSON response
response_data = response.json()
assert "expected_field" in response_data
assert response_data["field"] == "expected value"

# Mock called once
mock.method.assert_called_once()

# Mock called with specific arguments
mock.method.assert_called_once_with(arg1="value1", arg2=ANY)

# Mock not called
mock.method.assert_not_called()
```
