## Pattern: Strategic Denormalization

**When:** Related data is always accessed together

```python
# ❌ Normalized model (2 reads)
user = await db.collection('users').document(user_id).get()
profile = await db.collection('profiles').document(user_id).get()

# ✅ Denormalized (1 read)
user = await db.collection('users').document(user_id).get()
# user already contains profile_data as a field
```

**Trade-off:** Space for speed/cost
