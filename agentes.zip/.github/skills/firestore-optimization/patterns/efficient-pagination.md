## Pattern: Efficient Pagination

```python
# ✅ Cursor-based pagination
class PaginatedResponse(BaseModel):
    items: list
    next_cursor: Optional[str] = None
    has_more: bool

async def fetch_paginated(
    collection: str,
    page_size: int = 20,
    cursor: Optional[str] = None
):
    query = db.collection(collection).limit(page_size)

    if cursor:
        # Decode cursor and continue from where it stopped
        last_doc = await db.collection(collection).document(cursor).get()
        query = query.start_after(last_doc)

    docs = await query.get()

    return PaginatedResponse(
        items=[doc.to_dict() for doc in docs],
        next_cursor=docs[-1].id if len(docs) == page_size else None,
        has_more=len(docs) == page_size
    )
```

```python
# ✅ Cursor-based pagination using DatabaseEngine
class PaginatedResponse(BaseModel):
    items: list
    next_cursor: Optional[str] = None
    has_more: bool

async def fetch_paginated(
    collection: str,
    page_size: int = 20,
    cursor: Optional[str] = None
):

    items, new_cursor = await self.db.list_paginated_documents(
        collection,
        limit=page_size,
        last_document_id=cursor
    )

    return PaginatedResponse(
        items=items,
        next_cursor=new_cursor,
        has_more=len(items) == page_size
    )
```
