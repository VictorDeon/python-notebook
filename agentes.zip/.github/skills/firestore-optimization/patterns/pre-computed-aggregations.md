## Pattern: Pre-computed Aggregations

**When:** Complex calculations over many documents

```python
# ❌ Calculating on every request
posts = await db.collection('posts').where('author_id', '==', user_id).get()
total_likes = sum(post.get('likes', 0) for post in posts)

# ✅ Maintaining aggregated counter
user = await db.collection('users').document(user_id).get()
total_likes = user.get('total_likes', 0)
# Updated via Cloud Functions when posts receive likes
```
