### [Title] — `file.py:line`

**Category:** Firestore - Costs and Performance

**Location:** `api/module/controller.py:45` (function `fetch_user_posts`)

**Description:**

Loop executing individual Firestore queries (N+1 problem), resulting in excessive reads.

**Evidence:**

```python
users = await db.collection('users').get()
for user in users:
    posts = await db.collection('posts').where('user_id', '==', user.id).get()
```

**Impact:**

- Cost: 1 query + N document reads
- For 1000 users = 1001 reads
- Estimated monthly cost: $X (assuming Y requests/day)
- **Estimated risk:** High - Costs can scale rapidly

**Suggested Solution:**

```python
# Batch query with 'in' operator
users = await db.collection('users').get()
user_ids = [user.id for user in users]

all_posts = []
for i in range(0, len(user_ids), 10):
    batch = user_ids[i:i+10]
    posts = await db.collection('posts').where('user_id', 'in', batch).get()
    all_posts.extend(posts)
```

**Savings:** From 1001 reads to ~101 reads (90% reduction)

**References:**

- [Firestore Best Practices](https://firebase.google.com/docs/firestore/best-practices)
