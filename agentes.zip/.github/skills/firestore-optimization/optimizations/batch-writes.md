## Batch Writes

### ❌ Common Problem:

```python
# ❌ HIGH: Individual writes in a loop
for user_id in user_ids:
    await db.collection('users').document(user_id).update({
        'notification_sent': True
    })
# N individual writes (slow and expensive)
```

### ❌ Problem using DatabaseEngine:

```python
# ❌ HIGH: Individual writes in a loop
for user_id in user_ids:
    await self.db.update(
        path=f'users/{user_id}',
        data={'notification_sent': True}
    )
# N individual writes (slow and expensive)
```

**Cost:** N writes + N network round-trips

### ✅ Solution:

```python
# ✅ Batch write - up to 500 operations per batch
batch = db.batch()
for user_id in user_ids:
    user_ref = db.collection('users').document(user_id)
    batch.update(user_ref, {'notification_sent': True})

await batch.commit()  # 1 atomic commit, 1 round-trip
```

### ✅ Solution using DatabaseEngine:

```python
# ✅ Batch write - can send more than 500 operations, the method itself handles chunks
batch = self.db.batch()
users_to_update = [...]
await self.db.update_by_batch(
    collection=f'users',
    data=users_to_update
)
```

**Savings:** Same write cost, but much faster (1 round-trip vs N)
