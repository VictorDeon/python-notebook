## Caching for Static Data

### ❌ Common Problem:

```python
# ❌ MEDIUM: Reading config on every request
@router.get("/settings")
async def get_settings():
    settings = await db.collection('config').document('app_settings').get()
    return settings.to_dict()
# Unnecessary reads for data that rarely changes
```

### ❌ Problem with DatabaseEngine:

```python
# ❌ MEDIUM: Reading config on every request
@router.get("/settings")
async def get_settings():
    settings = await self.db.retrieve("config/app_settings")
    return settings
# Unnecessary reads for data that rarely changes
```

### ✅ Solution:

```python
# ✅ Cache with TTL
from functools import lru_cache
import time

@lru_cache(maxsize=1)
def get_cached_settings(cache_key: int):
    """Cache settings for 5 minutes."""
    settings = await db.collection('config').document('app_settings').get()
    return settings.to_dict()

@router.get("/settings")
async def get_settings():
    # Cache key changes every 5 minutes
    cache_key = int(time.time() // 300)
    return get_cached_settings(cache_key)
```

### ✅ Solution with DatabaseEngine:

```python
# ✅ Cache with TTL
from functools import lru_cache
import time

@lru_cache(maxsize=1)
def get_cached_settings(cache_key: int):
    """Cache settings for 5 minutes."""
    settings = await self.db.retrieve("config/app_settings")
    return settings

@router.get("/settings")
async def get_settings():
    # Cache key changes every 5 minutes
    cache_key = int(time.time() // 300)
    return get_cached_settings(cache_key)
```

**Savings:** From 1 read per request to 1 read every 5 minutes
