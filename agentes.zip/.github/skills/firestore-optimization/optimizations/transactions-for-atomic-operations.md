## Transactions for Atomic Operations

Transactions in Firestore allow you to perform multiple read and write operations atomically. This means that either all operations in the transaction succeed, or none do. Transactions are particularly useful when you need to ensure data consistency, such as when updating counters or performing operations that depend on previous reads.

### ✅ When to Use Transactions:

- Operations that depend on previous reads
- Counters that need atomicity
- Operations that must be all-or-nothing

```python
from google.cloud.firestore_v1 import AsyncClient, async_transactional, AsyncTransaction, AsyncDocumentReference

# ✅ Transaction for atomic counter
@async_transactional
async def increment_counter(transaction: AsyncTransaction, counter_ref: AsyncDocumentReference):
    snapshot = await counter_ref.get(transaction=transaction)
    new_count = snapshot.get('count') + 1
    transaction.update(counter_ref, {'count': new_count})

transaction = db.transaction()
counter_ref = db.collection('stats').document('views')
await increment_counter(transaction, counter_ref)
```

```python
# ✅ Transaction for atomic counter with DatabaseEngine
@async_transactional
async def increment_counter(transaction: AsyncTransaction, path: str):
    await self.db.update_by_transaction(
        path=path,
        data={'count': Increment(1)},
        transaction=transaction
    )

transaction = self.db.transaction()
await increment_counter(transaction, 'stats/views')
```

**Cost:** 1 read + 1 write (guarantees atomicity)
