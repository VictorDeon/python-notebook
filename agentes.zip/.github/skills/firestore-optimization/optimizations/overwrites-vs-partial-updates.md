## Overwrites vs Partial Updates

### ❌ Common Problem:

```python
# ❌ MEDIUM: Complete document overwrite
user_ref = db.collection('users').document(user_id)
user_data = await user_ref.get()
user_data = user_data.to_dict()
user_data['last_login'] = datetime.now()
await user_ref.set(user_data)  # Overwrites everything!
```

**Cost:** 1 read + 1 complete write (may lose other concurrently updated fields)

### ✅ Solution:

```python
# ✅ Partial update - more efficient and safe
user_ref = db.collection('users').document(user_id)
await user_ref.update({
    'last_login': datetime.now()
})  # Only 1 write, no read needed
```

### ✅ Solution using DatabaseEngine:

```python
# ✅ Partial update - more efficient and safe
await self.db.update(
    path=f'users/{user_id}',
    data={'last_login': datetime.now()}
)  # Only 1 write, no read needed
```

**Savings:** Eliminates 1 read + writes only necessary fields
