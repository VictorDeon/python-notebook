## Queries Without Limit

### ❌ Common Problem:

```python
# ❌ HIGH: Reading entire collection
all_users = await db.collection('users').get()  # Thousands of reads!
for user in all_users:
    print(user.id)
```

### ❌ Problem using DatabaseEngine:

```python
# ❌ HIGH: Reading entire collection
all_users = await self.db.list_paginated_documents('users')  # Thousands of reads!
for user in all_users:
    print(user.id)
```

**Cost:** If there are 10,000 users = 10,000 document reads

### ✅ Solution:

```python
# ✅ Solution 1: Pagination with limit
def fetch_users_paginated(page_size: int = 100, last_doc=None):
    query = db.collection('users').order_by('created_at').limit(page_size)
    if last_doc:
        query = query.start_after(last_doc)
    return await query.get()

# ✅ Solution 2: Stream to process incrementally
users_ref = db.collection('users')
async for user in users_ref.stream():
    process_user(user)
    # Processes incrementally, but still reads all
```


### ✅ Solution with DatabaseEngine:

```python
# ✅ Solution 1: Pagination with limit
def fetch_users_paginated(page_size: int = 100, last_doc=None) -> tuple[list[dict], DocumentSnapshot | None]:
    items, last_document = await self.db.list_paginated_documents(
        'users',
        order_by='created_at',
        limit=page_size,
        document_snapshot=last_doc
    )
    return items, last_document

# ✅ Solution 2: Stream to process incrementally
async for user in self.db.list_documents_by('users', limit=100):
    process_user(user)
    # Processes incrementally, but still reads all
```

**Savings:** From 10,000 reads to 100 reads per page
