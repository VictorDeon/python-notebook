## N+1 Problem (Loops with Reads)

### ❌ Common Problem:

```python
# ❌ HIGH: N+1 reads - expensive operation
users = await db.collection('users').get()  # 1 query read
for user in users:
    # N additional reads!
    posts = await db.collection('posts').where('user_id', '==', user.id).get()
    user_posts[user.id] = posts
```

### ❌ Problem using DatabaseEngine:

```python
# ❌ HIGH: N+1 reads - expensive operation
users = await self.db.list_paginated_documents('users')  # 1 query read
for user in users:
    # N additional reads!
    posts = await self.db.list_paginated_documents('posts', filters=[Filter(field='user_id', operator='==', value=user.id)])
    user_posts[user.id] = posts
```

**Cost:** 1 query + N document reads = potentially thousands of reads

### ✅ Solution:

```python
# ✅ Solution 1: Batch get with 'in' operator
users = await db.collection('users').get()
user_ids = [user.id for user in users]

# Firestore allows up to 10 values in the 'in' operator
all_posts = []
for i in range(0, len(user_ids), 10):
    batch = user_ids[i:i+10]
    posts = await db.collection('posts').where('user_id', 'in', batch).get()
    all_posts.extend(posts)

# ✅ Solution 2: Denormalization (if posts are small)
# Store posts directly in the user document
users = await db.collection('users').get()  # Only 1 read per user
```

### ✅ Solution using DatabaseEngine:

```python
# ✅ Solution 1: Batch get with 'in' operator
users =  await self.db.list_paginated_documents('users')
user_ids = [user.id for user in users]

# Firestore allows up to 10 values in the 'in' operator
all_posts = []
for i in range(0, len(user_ids), 10):
    batch = user_ids[i:i+10]
    posts = await self.db.list_paginated_documents('posts', filters=[Filter(field='user_id', operator='in', value=batch)])
    all_posts.extend(posts)

# ✅ Solution 2: Denormalization (if posts are small)
# Store posts directly in the user document
users = await self.db.list_paginated_documents('users')  # Only 1 read per user
```

**Savings:** From N+1 reads to (N/10)+1 reads or just N reads
