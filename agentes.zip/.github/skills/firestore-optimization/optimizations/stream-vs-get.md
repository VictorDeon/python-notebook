## Stream vs Get

### ❌ Common Problem:

```python
# ❌ Using .get() for large datasets
large_dataset = await db.collection('logs').where('date', '>=', start_date).get()
# Loads everything into memory at once
```

### ❌ Problem with DatabaseEngine:

```python
# ❌ Using .get() for large datasets
large_dataset = await self.db.list_paginated_documents(
    "logs",
    filters=[Filter(field='date', operator='>=', value=start_date)]
)
# Loads everything into memory at once
```

### ✅ Solution:

```python
# ✅ Stream to process incrementally
logs_ref = db.collection('logs').where('date', '>=', start_date)
async for log in logs_ref.stream():
    process_log(log)
    # Processes one at a time, without overloading memory
```

### ✅ Solution with DatabaseEngine:

```python
# ✅ Stream to process incrementally
async for log in self.db.list_documents_by(
    "logs",
    filters=[Filter(field='date', operator='>=', value=start_date)]
):
    process_log(log)
    # Processes one at a time, without overloading memory
```

**Benefit:** Lower memory usage, same number of reads
