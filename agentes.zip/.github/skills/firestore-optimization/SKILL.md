---
name: firestore-optimization
description: A set of practices and recommendations to reduce latency and costs and improve the scalability of applications using Cloud Firestore; how to use: apply during data schema modeling and refactoring (intentional denormalization when convenient, appropriate collection structure), create necessary composite indexes, prefer queries with bounds and cursors for pagination, use collectionGroup when appropriate, employ batched writes/transactions for atomic operations, adjust security rules to avoid unnecessary reads, and monitor usage and cost metrics; when to use: when designing or scaling applications in production, when investigating performance or cost issues, before critical deployments, and always in conjunction with load testing and a rollback plan.
---

# Skill: Firestore Optimization

## Objective

Identify and fix cost and performance issues in Google Firestore operations, minimizing unnecessary reads/writes and optimizing queries. Always prioritize using the `engines/database.py` engine for Firestore interactions. It already includes several recommended optimizations and methods. If you find any limitations, suggest improvements to the engine.

```py
# Controller constructor example
def __init__(self, db: DatabaseEngine, user: User) -> None:
    """
    Construtor.
    """

    self.user = user
    self.logger = Logger(endpoint="...", method="POST", user_id=user.uid)
    self.db = db
    self.db.change_logger(self.logger)
```

## When to Use

- During code reviews that manipulate Firestore
- When creating new features that interact with Firestore
- When analyzing query costs
- When reviewing loops that access the database
- When validating pagination and caching strategies

## Severity

🟠 **HIGH** — Cost issues must be optimized before production

---

## Firestore Pricing Model

### Free Tier

- 50,000 document reads per day
- 20,000 document writes per day
- 20,000 document deletes per day
- 1 GB of storage

### Billable Operations

- **Document reads**: 1 read = $0.045 per 100k documents
- **Document writes**: 1 write = $0.135 per 100k documents
- **Document deletes**: 1 delete = $0.015 per 100k documents
- **Storage**: $0.135 per GB/month
- **Network egress**: Charged per GB transferred

### Implications

- Unnecessary reads accumulate quickly
- Loops with `.get()` are extremely expensive
- Queries without `.limit()` can read thousands of documents
- Complete document overwrites cost more than partial updates

---

## Optimization Checklist

Always prioritize using the [DatabaseEngine](../../../engines/database.py) engine for Firestore interactions.

1. [N+1 Problem (Loops with Reads)](./optimizations/n1-problem-loops-with-reads.md)
2. [Queries Without Limit](./optimizations/queries-without-limit.md)
3. [Overwrites vs Partial Updates](./optimizations/overwrites-vs-partial-updates.md)
4. [Batch Writes](./optimizations/batch-writes.md)
5. [Transactions for Atomic Operations](./optimizations/transactions-for-atomic-operations.md)
6. [Caching for Static Data](./optimizations/caching-for-static-data.md)
7. [Stream vs Get](./optimizations/stream-vs-get.md)

---

## Optimization Patterns

1. [Strategic Denormalization](./patterns/strategic-denormalization.md)
2. [Pre-computed Aggregations](./patterns/pre-computed-aggregations.md)
3. [Efficient Pagination](./patterns/efficient-pagination.md)

---

## Cost Monitoring

### Metrics to Track

```python
from engines.logger import logger

# Log Firestore operations
logger.info(
    "Firestore operation",
    json_data={
        "operation": "query",
        "collection": "users",
        "estimated_reads": len(results),
        "query_filters": query_params
    }
)
```

### Recommended Alerts

- Number of reads > 1000 in a single request
- Queries without `.limit()` on large collections
- Loops with read/write operations

---

## Finding Template

When reviewing Firestore code, use this [template](./template.md) to identify common issues and suggest improvements.

---

## References

- [Firestore Pricing](https://firebase.google.com/pricing)
- [Best Practices for Firestore](https://firebase.google.com/docs/firestore/best-practices)
- [Query Optimization](https://firebase.google.com/docs/firestore/query-data/queries)
- [Transactions and Batched Writes](https://firebase.google.com/docs/firestore/manage-data/transactions)
