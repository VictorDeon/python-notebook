# Importar router do módulo
from fastapi import FastAPI
from .modules.routes import router as operation_router

app = FastAPI()

# Incluir router no app
app.include_router(
    operation_router,
    prefix="/api/v1",
    tags=["Module Name"]
)
