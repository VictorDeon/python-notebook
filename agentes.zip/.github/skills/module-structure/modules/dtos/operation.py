"""
DTOs para operação [Operation] do módulo [Module].

Este módulo define os Data Transfer Objects (DTOs) utilizados
para validação de entrada e formatação de saída da operação [operation].
"""

from typing import Optional
from pydantic import BaseModel, Field
from ..enums import Status


class OperationRequest(BaseModel):
    """
    DTO de requisição para [operation].

    Valida os dados de entrada fornecidos pelo cliente.
    """

    name: str = Field(
        ...,
        description="Nome da entidade",
        min_length=1,
        max_length=100,
        examples=["Exemplo"]
    )

    description: Optional[str] = Field(
        None,
        description="Descrição opcional",
        max_length=500
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "name": "Exemplo",
                "description": "Descrição opcional"
            }
        }
    }


class OperationResponse(BaseModel):
    """
    DTO de resposta para [operation].

    Formata os dados de retorno ao cliente.
    """

    id: str = Field(
        ...,
        description="Identificador único da entidade criada"
    )

    name: str = Field(
        ...,
        description="Nome da entidade"
    )

    status: Status = Field(
        ...,
        description="Status da entidade"
    )

    message: str = Field(
        ...,
        description="Mensagem de confirmação"
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "id": "abc123",
                "name": "Exemplo",
                "status": "active",
                "message": "Operação realizada com sucesso"
            }
        }
    }
