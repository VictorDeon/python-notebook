"""
Modelos de dados para [Module Name].

Este módulo define os modelos Pydantic que representam a estrutura
de documentos no Firestore para a coleção [collection_name].
"""

from typing import Optional
from fastapi_babel import _
from api.models import RootModel
from pydantic import Field, field_validator
from ..enums import Status


class EntityModel(RootModel):
    """
    Modelo de dados para [Entity].

    Representa um documento na coleção '[collection_name]' do Firestore.
    """

    id: Optional[str] = Field(
        None,
        description="Identificador único do documento no Firestore"
    )

    name: str = Field(
        ...,
        description="Nome descritivo da entidade",
        min_length=1,
        max_length=100
    )

    status: Status = Field(
        Status.ACTIVE,
        description="Status atual da entidade"
    )

    @field_validator('name')
    @classmethod
    def validate_name(cls, v: str) -> str:
        """
        Valida e normaliza o nome.
        """

        if not v or not v.strip():
            raise ValueError(_("O nome não pode ser vazio"))

        return v.strip()

    model_config = {
        "json_schema_extra": {
            "example": {
                "id": "abc123",
                "name": "Exemplo",
                "status": "active"
            }
        }
    }
