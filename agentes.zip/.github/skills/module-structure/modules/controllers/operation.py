"""
Controller para operação [Operation] do módulo [Module].

Este módulo contém a lógica de negócio para [operation],
incluindo validações, interações com o Firestore e tratamento de erros.
"""

from fastapi import HTTPException, status
from api.authentication.models import User
from engines.database import DatabaseEngine
from engines.logger import Logger
from engines.i18n import _
from api.utils import now
from ..models.entity import EntityModel
from ..dtos.operation import OperationRequest, OperationResponse


class OperationController:
    """
    Controller para [operation].

    Responsável por executar a lógica de negócio da operação [operation],
    coordenando validações, persistência de dados e formatação de resposta.
    """

    def __init__(
        self,
        payload: OperationRequest,
        user: User,
        db: DatabaseEngine
    ) -> None:
        """
        Inicializa o controller.

        Args:
            db: Instância do DatabaseEngine para acesso ao Firestore
        """

        self.db = db
        self.user = user
        self.payload = payload
        self.logger = Logger(endpoint="/module.endpoint", method="OPERATION", trace_id=None, user_id=user.uid)
        self.collection = "collection_name"

    async def execute(self) -> OperationResponse:
        """
        Executa a operação [operation].

        Args:
            request: Dados validados da requisição
            user: Usuário autenticado que está executando a operação

        Returns:
            OperationResponse com os dados da operação executada

        Raises:
            HTTPException: Em caso de erro de validação ou operação
        """

        try:
            self.logger.info(
                "operation_started",
                json_data={
                    "operation": "operation_name",
                    "user_id": self.user.uid,
                    "request_data": self.payload.model_dump(exclude_none=True)
                }
            )

            # 1. Validações de negócio
            await self._validate_business_rules()

            # 2. Preparar dados
            entity_data = self._prepare_entity_data()

            # 3. Persistir no Firestore
            entity_id = await self._save_to_firestore(entity_data)

            # 4. Log de sucesso
            self.logger.info(
                "operation_completed",
                json_data={
                    "operation": "operation_name",
                    "user_id": self.user.uid,
                    "entity_id": entity_id
                }
            )

            # 5. Retornar resposta
            return OperationResponse(
                id=entity_id,
                name=self.payload.name,
                status=entity_data.status,
                message=_("Operação realizada com sucesso")
            )

        except HTTPException:
            raise
        except Exception as e:
            self.logger.error(
                "operation_failed",
                json_data={
                    "operation": "operation_name",
                    "user_id": self.user.uid,
                    "error": str(e)
                }
            )

            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=_("Erro ao executar operação")
            )

    async def _validate_business_rules(self) -> None:
        """
        Valida regras de negócio específicas.

        Raises:
            HTTPException: Se alguma regra de negócio for violada
        """

        # Implementar validações específicas aqui
        pass

    def _prepare_entity_data(self) -> EntityModel:
        """
        Prepara os dados da entidade para persistência.

        Returns:
            EntityModel com dados formatados para o Firestore
        """

        return EntityModel(
            name=self.payload.name,
            status="active",
            created_at=now(),
            updated_at=None
        )

    async def _save_to_firestore(
        self,
        entity_data: EntityModel
    ) -> str:
        """
        Persiste a entidade no Firestore.

        Args:
            entity_data: Dados da entidade a serem salvos

        Returns:
            ID do documento criado

        Raises:
            HTTPException: Em caso de erro ao salvar
        """

        try:
            entity_id = await self.db.create(
                path=self.collection,
                data=entity_data.model_dump(exclude_none=True)
            )
            return entity_id
        except Exception as e:
            self.logger.error(
                "firestore_save_failed",
                json_data={
                    "collection": self.collection,
                    "error": str(e)
                }
            )

            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=_("Erro ao salvar dados")
            )
