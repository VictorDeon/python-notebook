from enum import Enum


class Status(str, Enum):
    """
    Enum para representar o status de uma entidade.
    """

    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"
    DELETED = "deleted"
