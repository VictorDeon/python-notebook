from fastapi import APIRouter

router = APIRouter(prefix="module-name")

from .operation import operation_endpoint

__all__ = [
    "operation_endpoint"
]
