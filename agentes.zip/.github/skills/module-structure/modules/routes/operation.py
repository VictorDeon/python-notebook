"""
Rota para operação [Operation] do módulo [Module].

Este módulo define o endpoint FastAPI para [operation],
incluindo documentação OpenAPI completa.
"""

from fastapi import Depends, status, Request, Security
from engines.database import DatabaseEngine
from engines.security import get_current_user, get_api_key
from engines.connectors import connect_db
from api.authentication.models import User
from api.constants import LIMITER
from api.utils import user_rate_limit
from ..dtos.operation import OperationRequest, OperationResponse
from ..controllers.operation import OperationController
from . import router


@router.post(
    "/operation",
    response_model=OperationResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Executa operação [Operation]",
    responses={
        201: {
            "description": "Operação executada com sucesso",
            "content": {
                "application/json": {
                    "example": {
                        "id": "abc123",
                        "name": "Exemplo",
                        "status": "active",
                        "message": "Operação realizada com sucesso"
                    }
                }
            }
        },
        400: {"description": "Dados de entrada inválidos"},
        401: {"description": "Não autenticado"},
        403: {"description": "Sem permissão"},
        500: {"description": "Erro interno do servidor"}
    },
    tags=["Module Name"]
)
@LIMITER.limit("10/minute")
@user_rate_limit("operation_endpoint", max_requests=5, window_seconds=60)
async def operation_endpoint(
    request: Request,
    payload: OperationRequest,
    key: str = Security(get_api_key),
    user: User = Depends(get_current_user),
    db: DatabaseEngine = Depends(connect_db)
) -> OperationResponse:
    """
    Executa a operação [operation] para o usuário autenticado.

    **Requisitos:**
    - Usuário deve estar autenticado
    - Dados devem ser válidos conforme schema

    **Comportamento:**
    - Valida dados de entrada
    - Executa regras de negócio
    - Persiste no Firestore
    - Retorna confirmação com ID gerado
    """

    return await OperationController(payload, user, db).execute()
