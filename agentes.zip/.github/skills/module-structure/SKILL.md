---
name: module-structure
description: This skill defines the mandatory architectural pattern for creating/refactor and organizing modules in the TicoBackend project, ensuring consistency, testability, and maintainability through a well-defined modular structure with a clear separation of responsibilities between Models, DTOs, Controllers, Routes, and Tests. It should ALWAYS be used when creating new functional modules, reviewing the structure of existing modules, refactoring legacy code to conform to project standards, and guiding developers on the system architecture. This skill is CRITICAL to the project because it establishes the organizational foundations, facilitates the onboarding of new developers, prevents architectural inconsistencies, and ensures that all modules follow the same design principles, making the code predictable, testable, and easy to maintain in the long term.
---

# Module Structure Skill

## 🎯 Purpose

This skill defines the standard structure and conventions for creating new modules in the TicoBackend project, ensuring consistency, maintainability, and code organization.

---

## 📁 Mandatory Module Structure

All modules MUST follow this exact structure:

```
api/<module_name>/
├── __init__.py              # Empty file or with module exports
├── models/
│   ├── __init__.py
│   └── <entity>.py          # Pydantic models for Firestore documents
├── dtos/
│   ├── __init__.py
│   └── <operation>.py       # Request/Response DTOs for validation
├── controllers/
│   ├── __init__.py
│   └── <operation>.py       # Business logic (one file per operation)
├── routes/
│   ├── __init__.py
│   └── <operation>.py       # FastAPI routes (one file per endpoint)
└── tests/
    ├── __init__.py
    └── test_<operation>.py  # Integration tests
```

---

## 📋 Naming Conventions

### Module Name

- **Format:** Plural, snake_case, singular only if plural doesn't make sense
- **Examples:**
  - ✅ `campaigns`, `users`, `stickers`, `payments`
  - ❌ `Campaign`, `user_module`, `Stickers`

### File Names

| Type | Pattern | Example |
|------|---------|---------|
| **Model** | `<entity>.py` | `campaign.py`, `user.py` |
| **DTO** | `<operation>.py` | `create_campaign.py`, `update_user.py` |
| **Controller** | `<operation>.py` | `create_campaign.py`, `fetch_campaigns.py` |
| **Route** | `<operation>.py` | `create_campaign.py`, `fetch_campaigns.py` |
| **Test** | `test_<operation>.py` | `test_create_campaign.py` |

### Class Naming

| Type | Pattern | Example |
|------|---------|---------|
| **Model** | `<Entity>Model` | `CampaignModel`, `UserModel` |
| **Request DTO** | `<Operation>Request` | `CreateCampaignRequest` |
| **Response DTO** | `<Operation>Response` | `CreateCampaignResponse` |
| **Controller** | `<Operation>Controller` | `CreateCampaignController` |

---

## 🔧 File Creation Order

Follow this EXACT order when creating a new module:

### 1️⃣ Directory Structure

```bash
mkdir -p api/<module_name>/{models,dtos,controllers,routes,tests}
touch api/<module_name>/__init__.py
touch api/<module_name>/models/__init__.py
touch api/<module_name>/dtos/__init__.py
touch api/<module_name>/controllers/__init__.py
touch api/<module_name>/routes/__init__.py
touch api/<module_name>/tests/__init__.py
```

### 2️⃣ Models (`models/<entity>.py`)

Create Pydantic data models that represent Firestore documents:

Example defined in:

* [modules/models/__init__.py](./modules/models/__init__.py)
* [modules/models/entity.py](./modules/models/entity.py)

### 3️⃣ DTOs (`dtos/<operation>.py`)

Create Request and Response DTOs:

Example defined in:

* [modules/dtos/__init__.py](./modules/dtos/__init__.py)
* [modules/dtos/operation.py](./modules/dtos/operation.py)

### 4️⃣ Controllers (`controllers/<operation>.py`)

Implement business logic

Example defined in:

* [modules/controllers/__init__.py](./modules/controllers/__init__.py)
* [modules/controllers/operation.py](./modules/controllers/operation.py)

### 5️⃣ Routes (`routes/<operation>.py`)

Define FastAPI endpoints

Example defined in:

* [modules/routes/__init__.py](./modules/routes/__init__.py)
* [modules/routes/operation.py](./modules/routes/operation.py)

### 6️⃣ Register in `api/main.py`

Add routes to the main application

Example defined in:

* [main.py](./main.py)

---

## ✅ Module Creation Checklist

Use this checklist when creating a new module:

### Structure

- [ ] Folder `api/<module_name>/` created
- [ ] Subfolders `models/`, `dtos/`, `controllers/`, `routes/`, `tests/` created
- [ ] All `__init__.py` files created
- [ ] Folder `tests/` created

### Models

- [ ] File `models/<entity>.py` created
- [ ] Class inherits from `BaseModel` or `RootModel`
- [ ] All fields have `Field(...)` with `description`
- [ ] Complete type hints
- [ ] Custom validators implemented (if necessary)
- [ ] `model_config` with example configured

### DTOs

- [ ] Files `dtos/<operation>.py` created
- [ ] Classes `<Operation>Request` and `<Operation>Response` defined
- [ ] All fields have `Field(...)` with `description`
- [ ] Appropriate validations configured
- [ ] Examples in `model_config` defined

### Controllers

- [ ] Files `controllers/<operation>.py` created
- [ ] Class `<Operation>Controller` defined
- [ ] Method `execute()` implemented
- [ ] Business validations implemented
- [ ] Error handling with `HTTPException`
- [ ] Structured logs at key points
- [ ] Complete docstrings

### Routes

- [ ] Files `routes/<operation>.py` created
- [ ] FastAPI Router configured
- [ ] Endpoint with `@router.post/get/put/delete`
- [ ] `response_model` defined
- [ ] Explicit `status_code`
- [ ] Complete OpenAPI documentation (`summary`, `responses`)
- [ ] Appropriate tags
- [ ] Dependency injection configured

### Integration
- [ ] Router registered in `api/main.py`
- [ ] Correct prefix and tags
- [ ] Endpoint accessible via Swagger UI

### Tests

- [ ] File `tests/test_<operation>.py` created
- [ ] Success test implemented
- [ ] 401 error test (unauthenticated) implemented
- [ ] 422 error test (invalid data) implemented
- [ ] 500 error test (internal failure) implemented
- [ ] Mocks configured
- [ ] 100% coverage achieved

### Quality

- [ ] `make flake8` without errors
- [ ] `make coverage` with 100%
- [ ] User-facing strings with `_()`
- [ ] Structured JSON logs
- [ ] Adequate inline documentation

---

## ⚠️ Common Mistakes to Avoid

### ❌ DON'T DO THIS

```python
# ❌ Field without Field()
name: str

# ❌ Without description
name: str = Field(...)

# ❌ Business logic in route
@router.post("/operation")
async def operation(request: Request):
    # validation here
    # persistence here
    # direct return

# ❌ Controller without separation of concerns
class Controller:
    async def execute(self, request):
        # everything in one giant method

# ❌ Test without mocking external dependencies
def test_operation():
    response = client.post("/operation")  # Will access real Firestore!

# ❌ Hardcoded message
raise HTTPException(detail="Error saving")
```

### ✅ DO THIS

```python
# ✅ Field with Field() and description
name: str = Field(..., description="Entity name")

# ✅ Business logic in controller
@router.post("/operation")
async def operation(
    request: Request,
    user: User = Depends(get_current_user),
    db: DatabaseEngine = Depends(get_db)
):
    controller = OperationController(db)
    return await controller.execute(request, user)

# ✅ Controller with separate private methods
class Controller:
    async def execute(self, request):
        await self._validate(request)
        data = self._prepare(request)
        return await self._save(data)

# ✅ Test with mock
def test_operation(mocker):
    mock_db = mocker.patch("path.to.get_db")
    response = client.post("/operation")

# ✅ i18n message
raise HTTPException(detail=_("Error saving"))
```

---

## 📚 Additional Resources

- [FastAPI Best Practices](../fastapi-best-practices/SKILL.md)
- [Pydantic Validation](../pydantic-validation/SKILL.md)
- [Test Planning](../test-planning/SKILL.md)
- [Mock Patterns](../mock-patterns/SKILL.md)

---

## 🎯 When to Use This Skill

- **ALWAYS** when creating a new module
- When reviewing or refactoring existing module structure
- When guiding other developers
- When documenting project patterns

**Importance:** 🔴 CRITICAL - Consistent structure is fundamental for project maintainability.
