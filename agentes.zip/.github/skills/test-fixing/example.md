## Scenario: Purchase Test Failing

### 1. Failure Capture

```bash
$ make coverage path=api/store/tests/test_purchase.py

FAILED api/store/tests/test_purchase.py::test_purchase_success
AssertionError: assert 500 == 200
```

### 2. Stack Trace

```python
api/store/tests/test_purchase.py:45: AssertionError
    assert response.status_code == 200
    E       assert 500 == 200
    E        +  where 500 = <Response>.status_code

api/store/controllers/purchase_product.py:67: HTTPException
    raise HTTPException(status_code=500, detail=_("product.not_found"))
```

### 3. Analysis

**Current test**:

```python
def test_purchase_success(client, mock_db, mock_user):
    app.dependency_overrides[get_current_user] = lambda: mock_user
    app.dependency_overrides[get_database] = lambda: mock_db

    # Mock configured incorrectly
    mock_doc = MagicMock()
    mock_doc.exists = False  # ❌ ERROR HERE
    mock_db.collection().document().get.return_value = mock_doc

    response = client.post("/store/purchase", json={"product_id": "123"})
    assert response.status_code == 200  # FAILS
```

**Controller**:

```python
def purchase_product(product_id: str, db):
    doc = db.collection("products").document(product_id).get()

    if not doc.exists:  # This condition is True because of the mock
        raise HTTPException(status_code=500, detail=_("product.not_found"))

    # ...rest of code
```

**Root cause**: Mock returning `exists=False` makes controller throw exception

### 4. Fix

```python
def test_purchase_success(client, mock_db, mock_user):
    app.dependency_overrides[get_current_user] = lambda: mock_user
    app.dependency_overrides[get_database] = lambda: mock_db

    # ✅ FIX: Mock returns valid document
    mock_doc = MagicMock()
    mock_doc.exists = True
    mock_doc.to_dict.return_value = {
        "id": "123",
        "name": "Test Product",
        "price": 100,
        "stock": 10
    }
    mock_db.collection().document().get.return_value = mock_doc

    try:
        response = client.post("/store/purchase", json={"product_id": "123"})
        assert response.status_code == 200
        assert response.json()["status"] == "success"
    finally:
        app.dependency_overrides.clear()
```

### 5. Validation

```bash
$ make coverage path=api/store/tests/test_purchase.py::test_purchase_success
✅ PASSED

$ make coverage
✅ ALL PASSED (100%)

$ make report
✅ Coverage: 100%
```
