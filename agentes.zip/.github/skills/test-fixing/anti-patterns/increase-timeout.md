## ❌ Anti-Pattern: Increase Timeout

```python
# NEVER DO THIS
@pytest.mark.timeout(300)  # 5 minutes!
def test_slow_operation(client):
    response = client.get("/slow")
```

**Why?**: Masks performance issue or poorly configured async
