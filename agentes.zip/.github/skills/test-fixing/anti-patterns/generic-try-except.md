## ❌ Anti-Pattern : Generic Try-Except

```python
# NEVER DO THIS
def test_something(client):
    try:
        response = client.post("/endpoint")
        assert response.status_code == 200
    except:
        pass  # Silences the error
```

**Why?**: Hides real failures
