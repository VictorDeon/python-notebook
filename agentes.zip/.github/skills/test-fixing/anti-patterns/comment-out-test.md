## ❌ Anti-Pattern : Comment Out Test

```python
# NEVER DO THIS
# def test_purchase_success(client):
#     response = client.post("/purchase")
#     assert response.status_code == 200
```

**Why?**: Reduces coverage and hides the problem
