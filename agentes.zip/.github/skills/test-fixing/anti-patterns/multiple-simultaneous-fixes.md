## ❌ Anti-Pattern: Multiple Simultaneous Fixes

```python
# NEVER DO THIS
# Fixing 5 different problems at the same time
# without validating each one individually
```

**Why?**: Impossible to know which fix solved which problem
