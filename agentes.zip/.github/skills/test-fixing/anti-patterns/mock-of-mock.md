## ❌ Anti-Pattern: Mock of Mock

```python
# NEVER DO THIS
mock_obj = MagicMock()
mock_obj.method = MagicMock()
mock_obj.method.return_value = MagicMock()
```

**Why?**: Unnecessary complexity, makes debugging difficult
