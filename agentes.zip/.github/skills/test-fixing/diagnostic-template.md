# Test Failure Diagnostic

> **Diagnostic Date**: [YYYY-MM-DD]
> **Analyst**: [Agent name or ID]

---

## 📊 Failure Information

| Field | Value |
|-------|-------|
| **Test** | `test_function_name` |
| **File** | `api/module/tests/test_file.py` |
| **Line** | 123 |
| **Failure Type** | 🔴 Assertion Error / 🟡 Mock Error / 🟠 Import Error / 🔵 Runtime Error / 🟣 Timeout Error / ⚫ Setup/Teardown Error |
| **Scope** | ✅ Isolated test / ⚠️ Multiple tests / 🚨 Regression |

## 🔍 Complete Stack Trace

```
[Paste here the complete stack trace captured from terminal]

Example:
FAILED api/store/tests/test_purchase.py::test_purchase_success
api/store/tests/test_purchase.py:45: AssertionError
    assert response.status_code == 200
    E       assert 500 == 200
    E        +  where 500 = <Response>.status_code

api/store/controllers/purchase_product.py:67: HTTPException
    raise HTTPException(status_code=500, detail=_("product.not_found"))
```

## 📝 Failure Description

### Expected Behavior

[What the test expects to happen]

Example:
- Endpoint `/store/purchase` should return status 200
- Response should contain `{"status": "success", "order_id": "123"}`
- Product should be marked as sold in Firestore

### Observed Behavior

[What is actually happening]

Example:
- Endpoint is returning status 500
- Response contains `{"detail": "Product not found"}`
- HTTPException being thrown in controller

### Discrepancy

[Exact difference between expected and observed]

Example:
```
Expected: response.status_code == 200
Actual:   response.status_code == 500

Expected: product found in Firestore
Actual:   product not found (mock returning exists=False)
```

## 🔬 Code Analysis

### Test Code

**File**: `api/module/tests/test_file.py`

```python
[Paste the failing test code]

Example:
def test_purchase_success(client, mock_db, mock_user):
    app.dependency_overrides[get_current_user] = lambda: mock_user
    app.dependency_overrides[get_database] = lambda: mock_db

    mock_doc = MagicMock()
    mock_doc.exists = False  # ❌ PROBLEM HERE
    mock_db.collection().document().get.return_value = mock_doc

    response = client.post("/store/purchase", json={"product_id": "123"})
    assert response.status_code == 200  # FAILS HERE
```

### Related Production Code

**File**: `api/module/controllers/controller.py`

```python
[Paste the controller/route code being tested]

Example:
def purchase_product(product_id: str, db):
    doc = db.collection("products").document(product_id).get()

    if not doc.exists:  # This condition is True because of the mock
        raise HTTPException(status_code=500, detail=_("product.not_found"))

    product = doc.to_dict()
    # ...rest of code
```

### Execution Flow

**Trace of the flow leading to failure**:

```
1. Test calls: client.post("/store/purchase")
   ↓
2. Route calls: purchase_product(product_id, db)
   ↓
3. Controller fetches: db.collection("products").document(product_id).get()
   ↓
4. Mock returns: document with exists=False
   ↓
5. Condition if not doc.exists: → True
   ↓
6. Controller throws: HTTPException(500, "product.not_found")
   ↓
7. Test receives: status_code = 500
   ↓
8. Assertion fails: assert 500 == 200 ❌
```

## 🎯 Root Cause

### Identification

[Clear and concise root cause description]

Example:
The Firestore mock is configured to return a document with `exists=False`, simulating that the product doesn't exist. This makes the controller throw an HTTP 500 exception, when the test expects success (200).

### Category

- [ ] Mock configured incorrectly
- [ ] Production code changed, test outdated
- [ ] Incorrect assertion
- [ ] Dependency not mocked
- [ ] Inadequate cleanup (contamination between tests)
- [ ] i18n message changed
- [ ] Response format changed
- [ ] Other: _____________

### Cause Analysis

**Why did it happen?**
[Explanation of how the problem arose]

Example:
The test was written assuming a success scenario, but the mock wasn't configured correctly to simulate an existing product in Firestore. The `exists` field is set to `False` by default, causing the error flow instead of the success flow.

**Impact**:
- [ ] Only this test
- [ ] Multiple tests in the same file
- [ ] Multiple tests in different files
- [ ] Regression (affects tests that passed before)

## 🔧 Fix Plan

### Strategy

- [ ] Surgical Fix (change only 1 line/block)
- [ ] Batch Fix (same problem in multiple tests)
- [ ] Contract Update (response format changed)
- [ ] Test Isolation (shared state)

### Detailed Fix

**What will be changed**:

[Specific description of the change]

Example:
Configure the Firestore document mock to return `exists=True` and include valid product data via `to_dict()`.

**Code Before**:

```python
mock_doc = MagicMock()
mock_doc.exists = False
mock_db.collection().document().get.return_value = mock_doc
```

**Code After**:

```python
mock_doc = MagicMock()
mock_doc.exists = True  # ✅ FIX
mock_doc.to_dict.return_value = {  # ✅ ADDED
    "id": "123",
    "name": "Test Product",
    "price": 100,
    "stock": 10
}
mock_db.collection().document().get.return_value = mock_doc
```

### Justification

[Why this fix solves the problem]

Example:
With `exists=True`, the controller won't enter the error block `if not doc.exists`. With `to_dict()` returning valid data, the success flow can proceed normally, resulting in status 200 as expected by the test.

### Expected Impact

**Tests positively affected**:
- ✅ `test_purchase_success` - will pass after fix

**Regression risk**:
- ⚠️ None (isolated fix in test mock)
- 🚨 Possible impact on [list of tests if there's risk]

### Fix Validation

**Commands to validate**:

```bash
# 1. Test specific fix
make coverage path=api/module/tests/test_file.py::test_function_name

# 2. Check for regression
make coverage

# 3. Validate coverage maintained
make report

# 4. Validate formatting
make flake8
```

**Success checklist**:

- [ ] Specific test passes
- [ ] No regression (all tests pass)
- [ ] Coverage maintained at 100%
- [ ] Correct formatting
- [ ] Root cause completely resolved

## 📊 Additional Context

### Recent Changes

[List recent code changes that may have caused the failure]

Example:
- Commit abc123: Change in controller to validate stock
- Commit def456: Product model refactoring
- No changes identified (test always failed)

### Dependencies Involved

**Configured mocks**:
- `mock_db` (DatabaseEngine / Firestore)
- `mock_user` (get_current_user dependency)
- `mock_slack` (SlackEngine)

**Engines involved**:
- `engines.database.DatabaseEngine`
- `engines.slack.SlackEngine`

**Routes/Controllers**:
- Route: `api/store/routes/purchase.py::purchase_route`
- Controller: `api/store/controllers/purchase_product.py::purchase_product`

### Execution History

**Previous executions**:
- [ ] Test always failed since creation
- [ ] Test passed before, started failing on [date/commit]
- [ ] Test is flaky (passes sometimes)

**Failure frequency**:
- [ ] Always fails (100%)
- [ ] Fails frequently (> 50%)
- [ ] Fails occasionally (< 50%)

## 🔄 Next Steps

1. [ ] Apply fix according to plan above
2. [ ] Run specific test
3. [ ] Validate it passed
4. [ ] Run complete suite (make coverage)
5. [ ] Validate coverage (make report)
6. [ ] Validate formatting (make flake8)
7. [ ] Delete this diagnostic

## 🗒️ Additional Notes

[Any additional relevant information]

Example:
- This test is part of the purchase test suite
- Related to GitHub issue #456
- Similar mock pattern used in test_purchase_out_of_stock.py

---

**Status**: 🔴 Awaiting Fix / 🟡 In Progress / ✅ Resolved

**Last Updated**: [YYYY-MM-DD HH:MM]
