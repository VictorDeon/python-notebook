## Pattern: Fix Dependency Mock

### Problem

```python
# Dependency not mocked - accesses real service
def test_send_email(client):
    response = client.post("/send-email")
    # BrevoEngine tries to access real API
```

### Fix

```python
# Correctly mocking dependency
@pytest.fixture
def mock_brevo(monkeypatch):
    mock = MagicMock()
    mock.send_email.return_value = {"id": "email_123"}
    monkeypatch.setattr("engines.brevo.BrevoEngine", lambda: mock)
    return mock

def test_send_email(client, mock_brevo):
    response = client.post("/send-email")
    assert response.status_code == 200
    mock_brevo.send_email.assert_called_once()
```
