## Pattern: Fix Collection Mock

### Problem

```python
# Mock doesn't return iterable
mock_db.collection().stream.return_value = None
```

### Fix

```python
# Mock returns list of documents
mock_docs = [mock_doc1, mock_doc2]
mock_db.collection().stream.return_value = iter(mock_docs)
```
