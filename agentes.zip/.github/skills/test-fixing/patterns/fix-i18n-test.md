## Pattern: Fix i18n Test

### Problem

```python
# Hardcoded message
assert response.json()["message"] == "Product not found"
```

### Fix

```python
# Using correct translation
from engines.i18n import _

# For pt-BR
assert response.json()["message"] == _("product.not_found")

# For en-US (with Accept-Language header)
headers = {"Accept-Language": "en-US"}
response = client.get("/product/999", headers=headers)
assert response.json()["message"] == _("product.not_found")
```
