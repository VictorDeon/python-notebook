## Pattern: Fix Firestore Mock

### Problem

```python
# Incorrect mock - document doesn't exist
mock_doc = MagicMock()
mock_doc.exists = False
```

### Fix

```python
# Correct mock - document exists with data
mock_doc = MagicMock()
mock_doc.exists = True
mock_doc.to_dict.return_value = {
    "id": "product_123",
    "name": "Test Product",
    "stock": 10
}
```
