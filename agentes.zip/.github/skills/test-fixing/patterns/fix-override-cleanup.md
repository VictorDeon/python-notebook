## Pattern: Fix Override Cleanup

### Problem

```python
# Override not cleaned - contaminates next test
def test_user_authenticated(client):
    app.dependency_overrides[get_current_user] = mock_user
    response = client.get("/protected")
    # Missing cleanup
```

### Fix

```python
def test_user_authenticated(client):
    app.dependency_overrides[get_current_user] = mock_user
    try:
        response = client.get("/protected")
        assert response.status_code == 200
    finally:
        app.dependency_overrides.clear()
```
