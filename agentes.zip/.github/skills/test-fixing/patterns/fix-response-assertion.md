## Pattern: Fix Response Assertion

### Problem

```python
# Expecting old format
assert response.json() == {
    "success": True,
    "data": {"id": "123"}
}
```

### Fix

```python
# Updated to new format
assert response.json() == {
    "status": "success",
    "result": {"id": "123"},
    "timestamp": "2026-01-22T10:00:00Z"
}
```
