## 4. Diagnostic Documentation

Create report using template in [diagnostic-template.md](../diagnostic-template.md).
