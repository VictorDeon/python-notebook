## 2. Failure Classification

| Type | Symptom | Likely Cause |
|------|---------|-------------|
| 🔴 **Assertion Error** | `assert X == Y` fails | Expectation not aligned with behavior |
| 🟡 **Mock Error** | `AttributeError` on mock | Mock not configured correctly |
| 🟠 **Import Error** | Cannot import module | Wrong path or missing dependency |
| 🔵 **Runtime Error** | Unexpected exception | Code threw unhandled exception |
| 🟣 **Timeout Error** | Test doesn't complete | Async not awaited, deadlock |
| ⚫ **Setup/Teardown Error** | Failure before/after test | Fixture or cleanup issue |
