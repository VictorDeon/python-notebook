## 3. Root Cause Analysis

### Investigation Checklist

**For Assertion Errors:**

- [ ] What does the test expect?
- [ ] What is the code returning?
- [ ] Did production code change recently?
- [ ] Did i18n messages change?
- [ ] Did response format change?

**For Mock Errors:**

- [ ] Was the mock created?
- [ ] Was the mock configured (`return_value` or `side_effect`)?
- [ ] Is the mock being applied in the right place?
- [ ] Is the mock path correct?
- [ ] Is the mock being cleaned up in teardown?

**For Runtime Errors:**

- [ ] Which line threw the exception?
- [ ] Is the exception expected and should be handled?
- [ ] Is a mock missing for some dependency?
- [ ] Is the code accessing a real external resource?

### Diagnostic Example

```
Test: test_purchase_success
Failure: AssertionError: assert 500 == 200

Stack trace shows:
  File "api/store/controllers/purchase_product.py", line 45
    raise HTTPException(status_code=500, detail="Product not found")

Root cause:
Firestore mock returning document with exists=False
instead of valid document with exists=True.

Controller doesn't find product and throws 500 exception,
but test expects success (200).
```
