## 1. Failure Capture

### Get Complete Output

```bash
make coverage path=api/module/tests/test_file.py
```

**Capture**:

- Name of the failed test
- Error type (AssertionError, MockError, etc.)
- Complete stack trace
- Expected vs actual values

### Output Example

```
FAILED api/store/tests/test_purchase.py::test_purchase_success
AssertionError: assert 500 == 200
 +  where 500 = <Response>.status_code
```
