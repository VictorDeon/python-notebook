---
name: test-fixing
description: Comprehensive methodology for diagnosing and correcting failed FastAPI tests, maintaining 100% coverage and preventing regressions. Use this skill when one or more tests break after changes to production code, mocks don't work as expected, or assertions fail. The process follows a structured flow: complete capture of the failure with stack trace, classification of the error type (assertion, mock, import, runtime, timeout, or setup), root cause analysis, diagnostic documentation, surgical correction application, correction validation, and post-fix checklist to ensure there are no regressions and coverage remains at 100%.
---

# 🩺 Skill: Test Fixing - Broken Test Remediation

## 📋 Overview

This skill provides a comprehensive methodology for diagnosing and fixing failed FastAPI integration tests while maintaining 100% coverage and avoiding regressions.

## 🎯 When to Use This Skill

Use this skill when:

- ✅ One or more tests are failing
- ✅ A test that previously passed now fails
- ✅ After production code changes, tests broke
- ✅ Mocks aren't working as expected
- ✅ Assertions are failing
- ✅ Test exhibits flaky behavior

---

## 🔍 Diagnostic Methodology

1. [Failure Capture](./methodology/1-failure-capture.md)
2. [Failure Classification](./methodology/2-failure-classification.md)
3. [Root Cause Analysis](./methodology/3-root-cause-analysis.md)
4. [Diagnostic Documentation](./methodology/4-diagnostic-documentation.md)

---

## 🔧 Fix Patterns

* [Fix Firestore Mock](./patterns/fix-firestore-mock.md)
* [Fix Collection Mock](./patterns/fix-collection-mock.md)
* [Fix Response Assertion](./patterns/fix-response-assertion.md)
* [Fix Dependency Mock](./patterns/fix-dependency-mock.md)
* [Fix Override Cleanup](./patterns/fix-override-cleanup.md)
* [Fix i18n Test](./patterns/fix-i18n-test.md)

---

## 🎯 Fix Strategies

### Strategy 1: Surgical Fix

**When to use**: Isolated failure in one test

**Approach**:

1. Identify the exact line of the problem
2. Fix only that line
3. Don't refactor surrounding code
4. Validate test passes
5. Validate no regression

### Strategy 2: Batch Fix

**When to use**: Multiple tests failing for the same reason

**Approach**:

1. Identify the common pattern
2. Fix the root cause once
3. Validate all affected tests pass
4. Check for side effects

### Strategy 3: Contract Update

**When to use**: Production code changed (new response format)

**Approach**:

1. Identify the new contract
2. Update all affected tests
3. Maintain 100% coverage
4. Document the change

### Strategy 4: Test Isolation

**When to use**: Flaky test or order-dependent test

**Approach**:

1. Identify shared state
2. Add appropriate setup/teardown
3. Use isolated fixtures
4. Run test multiple times to validate

---

## 🚫 Anti-Patterns - What NOT to Do

* [Comment Out Test](./anti-patterns/comment-out-test.md)
* [Increase Timeout](./anti-patterns/increase-timeout.md)
* [Generic Try-Except](./anti-patterns/generic-try-except.md)
* [Mock of Mock](./anti-patterns/mock-of-mock.md)
* [Multiple Simultaneous Fixes](./anti-patterns/multiple-simultaneous-fixes.md)

---

## ✅ Post-Fix Validation Checklist

After each fix, validate:

#### 1. Specific test passes

```bash
make coverage path=api/module/tests/test_file.py::test_name
```

#### 2. No regression

```bash
make coverage
```

100% of tests must pass

#### 3. Coverage maintained

```bash
make report
```

Coverage must be 100%

#### 4. Correct formatting

```bash
make flake8
```

No lint errors

#### 5. Fix is minimal

Diff shows only necessary change

#### 6. Root cause resolved

Problem won't return

---

## 📊 Complete Diagnostic and Fix Example

You can find a complete diagnostic and fix example [here](./example.md).

## 🔄 Workflow Iterativo

```
┌─────────────────────────────────────────┐
│  1. Capturar falha e stack trace        │
└────────────┬────────────────────────────┘
             │
             ▼
┌─────────────────────────────────────────┐
│  2. Classificar tipo de falha           │
└────────────┬────────────────────────────┘
             │
             ▼
┌─────────────────────────────────────────┐
│  3. Analyze root cause                  │
└────────────┬────────────────────────────┘
             │
             ▼
┌─────────────────────────────────────────┐
│  4. Document diagnostic                 │
└────────────┬────────────────────────────┘
             │
             ▼
┌─────────────────────────────────────────┐
│  5. Apply surgical fix                  │
└────────────┬────────────────────────────┘
             │
             ▼
┌─────────────────────────────────────────┐
│  6. Run fixed test                      │
└────────────┬────────────────────────────┘
             │
         ┌───┴────┐
         │ Passed?│
         └───┬────┘
    ┌────────┴────────┐
    │ No              │ Yes
    ▼                 ▼
┌──────────┐    ┌──────────────────┐
│ Adjust   │    │ 7. Validate      │
│ fix      │    │    regression    │
└────┬─────┘    └────────┬─────────┘
     │                   │
     └──────┐       ┌────┘
            │       │
            ▼       ▼
    ┌─────────────────────────────┐
    │  8. Validate 100% coverage  │
    └──────────┬──────────────────┘
               │
               ▼
    ┌─────────────────────────────┐
    │  9. Delete diagnostic       │
    └─────────────────────────────┘
```

## 📚 References

- [Test Guidelines](../../instructions/test-guidelines.instructions.md)
- [Mock Patterns](../mock-patterns/SKILL.md)
- [Coverage Analysis](../coverage-analysis/SKILL.md)
- [Diagnostic Template](./diagnostic-template.md)

---

**Remember**: An accurate diagnosis is more valuable than a quick fix. Invest time understanding the problem before fixing it.
