## External Service Mocks

### ❌ Common Problem:

```python
# ❌ CRITICAL: Test accesses real services
def test_send_email():
    # Sends real email!
    send_welcome_email("user@example.com")
    # Don't use real services in tests!
```

### ✅ Solution with Mocks:

```python
# conftest.py
import pytest
from unittest.mock import Mock, patch

@pytest.fixture
def mock_brevo_client(mocker):
    """Mock of Brevo client for sending emails."""
    mock = mocker.patch('engines.brevo.brevo_client')
    mock.send_transactional_email.return_value = {
        "messageId": "msg_123"
    }
    return mock

@pytest.fixture
def mock_firestore(mocker):
    """Mock of Firestore client."""
    mock = mocker.patch('engines.database.db')
    return mock

@pytest.fixture
def mock_storage(mocker):
    """Mock of Google Cloud Storage client."""
    mock = mocker.patch('engines.storage.storage_client')
    return mock

# tests/test_email.py
def test_send_welcome_email(mock_brevo_client):
    """Tests sending welcome email."""
    # Arrange
    email = "user@example.com"
    name = "João Silva"

    # Act
    send_welcome_email(email, name)

    # Assert
    mock_brevo_client.send_transactional_email.assert_called_once()
    call_args = mock_brevo_client.send_transactional_email.call_args
    assert call_args[1]["to"] == [{"email": email, "name": name}]
    assert call_args[1]["template_id"] == WELCOME_EMAIL_TEMPLATE_ID
```
