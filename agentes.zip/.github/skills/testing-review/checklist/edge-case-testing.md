## Edge Case Testing

### ❌ Common Problem:

```python
# ❌ LOW: Only happy path
def test_create_user():
    """Tests only success case."""
    user = create_user(valid_data)
    assert user.id is not None
```

### ✅ Solution with Edge Cases:

```python
def test_create_user_with_valid_data_succeeds():
    """Tests creation with valid data."""
    ...

def test_create_user_with_invalid_email_raises_validation_error():
    """Tests that invalid email generates validation error."""
    with pytest.raises(ValidationError):
        create_user(CreateUserDTO(
            email="invalid_email",  # No @
            name="João Silva",
            age=25
        ))

def test_create_user_with_age_below_18_raises_validation_error():
    """Tests that age < 18 generates error."""
    with pytest.raises(ValidationError) as exc_info:
        create_user(CreateUserDTO(
            email="user@example.com",
            name="João Silva",
            age=17
        ))
    assert "age_must_be_18_or_older" in str(exc_info.value)

def test_create_user_with_duplicate_email_raises_conflict():
    """Tests that duplicate email generates HTTP 409."""
    # First user
    create_user(valid_data)

    # Duplication attempt
    with pytest.raises(HTTPException) as exc_info:
        create_user(valid_data)

    assert exc_info.value.status_code == 409

def test_create_user_with_empty_name_raises_validation_error():
    """Tests that empty name generates error."""
    with pytest.raises(ValidationError):
        create_user(CreateUserDTO(
            email="user@example.com",
            name="",  # Empty
            age=25
        ))

def test_create_user_with_very_long_name_truncates():
    """Tests behavior with very long name."""
    long_name = "a" * 200
    user = create_user(CreateUserDTO(
        email="user@example.com",
        name=long_name,
        age=25
    ))
    assert len(user.name) <= 100  # Max length
```
