## Reusable Fixtures

### ✅ Fixtures in conftest.py:

```python
# conftest.py
import pytest
from datetime import datetime

@pytest.fixture
def sample_user():
    """User fixture for tests."""
    return {
        "id": "user123",
        "email": "user@example.com",
        "name": "João Silva",
        "age": 25,
        "created_at": datetime.now()
    }

@pytest.fixture
def sample_order():
    """Order fixture for tests."""
    return {
        "id": "order123",
        "user_id": "user123",
        "total": 199.90,
        "status": "pending",
        "items": [
            {"product_id": "prod1", "quantity": 2, "price": 99.95}
        ]
    }

@pytest.fixture
def authenticated_client(client, sample_user):
    """Authenticated HTTP client."""
    token = generate_test_token(sample_user)
    client.headers = {
        "Authorization": f"Bearer {token}"
    }
    return client

# Usage in tests
def test_get_user_profile(authenticated_client, sample_user):
    """Tests getting authenticated profile."""
    response = authenticated_client.get(f"/users/{sample_user['id']}")
    assert response.status_code == 200
    assert response.json()["email"] == sample_user["email"]
```
