## Descriptive Test Naming

### ❌ Common Problem:

```python
# ❌ LOW: Vague names
def test_user():
    ...

def test_create():
    ...

def test_error():
    ...
```

### ✅ Solution:

```python
# ✅ Descriptive names following pattern:
# test_<function>_<scenario>_<expected_result>

def test_create_user_with_valid_data_returns_user_model():
    """Tests user creation with valid data."""
    ...

def test_create_user_with_duplicate_email_raises_conflict_error():
    """Tests that duplicate email generates 409 error."""
    ...

def test_get_user_with_nonexistent_id_returns_404():
    """Tests that non-existent ID returns 404."""
    ...

def test_update_user_without_authentication_returns_401():
    """Tests that update without auth returns 401."""
    ...
```
