## Parameterized Tests

### ✅ Pytest Parametrize:

```python
import pytest

@pytest.mark.parametrize(
    "email,expected_valid",
    [
        ("user@example.com", True),
        ("user+tag@example.co.uk", True),
        ("invalid.email", False),
        ("@example.com", False),
        ("user@", False),
        ("", False),
    ]
)
def test_email_validation(email, expected_valid):
    """Tests email validation with multiple cases."""
    if expected_valid:
        # Should pass validation
        user = CreateUserDTO(
            email=email,
            name="Test User",
            age=25
        )
        assert user.email == email
    else:
        # Should fail validation
        with pytest.raises(ValidationError):
            CreateUserDTO(
                email=email,
                name="Test User",
                age=25
            )

@pytest.mark.parametrize(
    "age,should_pass",
    [
        (17, False),  # Under 18
        (18, True),   # Lower limit
        (25, True),   # Normal
        (120, True),  # Upper limit
        (121, False), # Above limit
        (-1, False),  # Negative
    ]
)
def test_age_validation(age, should_pass):
    """Tests age validation."""
    if should_pass:
        user = CreateUserDTO(
            email="user@example.com",
            name="Test User",
            age=age
        )
        assert user.age == age
    else:
        with pytest.raises(ValidationError):
            CreateUserDTO(
                email="user@example.com",
                name="Test User",
                age=age
            )
```
