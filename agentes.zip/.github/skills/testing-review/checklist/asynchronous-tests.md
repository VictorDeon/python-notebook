## Asynchronous Tests

### ✅ Pytest Asyncio:

```python
import pytest

@pytest.mark.asyncio
async def test_async_endpoint(mock_firestore):
    """Tests asynchronous endpoint."""
    # Arrange
    user_id = "user123"

    mock_doc = Mock()
    mock_doc.exists = True
    mock_doc.to_dict.return_value = {
        "email": "user@example.com",
        "name": "João Silva"
    }

    mock_firestore.collection.return_value.document.return_value.get.return_value = mock_doc

    # Act
    result = await get_user_async(user_id)

    # Assert
    assert result.email == "user@example.com"
    assert result.name == "João Silva"

@pytest.mark.asyncio
async def test_async_error_handling(mock_external_api):
    """Tests error handling in asynchronous operation."""
    # Arrange
    mock_external_api.get.side_effect = httpx.TimeoutException("Timeout")

    # Act & Assert
    with pytest.raises(ExternalAPIError) as exc_info:
        await fetch_external_data()

    assert "timeout" in str(exc_info.value).lower()
```
