## Critical Code Coverage

### ❌ Common Problem:

```python
# ❌ LOW: Critical code without tests
# controllers/payment.py
async def process_payment(order_id: str, payment_data: PaymentDTO):
    """Processes payment - critical code without tests!"""
    order = await get_order(order_id)
    result = await stripe_client.charge(
        amount=order.total,
        currency="BRL",
        source=payment_data.token
    )
    return result

# No tests in tests/
```

### ✅ Solution:

```python
# tests/test_payment.py
import pytest
from unittest.mock import Mock, patch, AsyncMock

@pytest.mark.asyncio
async def test_process_payment_success(mock_stripe_client):
    """Tests successful payment processing."""
    # Arrange
    order_id = "order123"
    payment_data = PaymentDTO(token="tok_123", amount=100.0)

    mock_stripe_client.charge.return_value = AsyncMock(
        return_value={
            "id": "ch_123",
            "status": "succeeded",
            "amount": 10000
        }
    )

    # Act
    result = await process_payment(order_id, payment_data)

    # Assert
    assert result["status"] == "succeeded"
    assert result["amount"] == 10000
    mock_stripe_client.charge.assert_called_once_with(
        amount=100.0,
        currency="BRL",
        source="tok_123"
    )

@pytest.mark.asyncio
async def test_process_payment_failure(mock_stripe_client):
    """Tests payment processing failure."""
    # Arrange
    order_id = "order123"
    payment_data = PaymentDTO(token="tok_invalid", amount=100.0)

    mock_stripe_client.charge.side_effect = StripeError("Card declined")

    # Act & Assert
    with pytest.raises(PaymentError) as exc_info:
        await process_payment(order_id, payment_data)

    assert "Card declined" in str(exc_info.value)
```
