## Integration Tests with FastAPI

### ✅ FastAPI TestClient:

```python
# tests/test_users_routes.py
from fastapi.testclient import TestClient
from api.main import app

client = TestClient(app)

def test_create_user_endpoint_returns_201(mock_firestore):
    """Tests POST /users endpoint returns 201."""
    # Arrange
    user_data = {
        "email": "user@example.com",
        "name": "João Silva",
        "password": "secure123",
        "age": 25
    }

    mock_firestore.collection.return_value.where.return_value.get.return_value = []
    mock_firestore.collection.return_value.add.return_value = ("doc_ref", "new_user_id")

    # Act
    response = client.post("/users", json=user_data)

    # Assert
    assert response.status_code == 201
    response_data = response.json()
    assert response_data["email"] == user_data["email"]
    assert response_data["name"] == user_data["name"]
    assert "id" in response_data
    assert "password" not in response_data  # Password should not be returned

def test_create_user_with_invalid_data_returns_422(mock_firestore):
    """Tests that invalid data returns 422."""
    invalid_data = {
        "email": "invalid_email",  # No @
        "name": "",  # Empty
        "age": 15  # Under 18
    }

    response = client.post("/users", json=invalid_data)

    assert response.status_code == 422
    errors = response.json()["detail"]
    assert any("email" in str(e) for e in errors)

def test_get_user_without_auth_returns_401():
    """Tests that access without authentication returns 401."""
    response = client.get("/users/user123")
    assert response.status_code == 401
```
