## Code Coverage

### ✅ Coverage Configuration:

```python
# pytest.ini
[pytest]
testpaths = tests
addopts =
    --cov=api
    --cov-report=html
    --cov-report=term-missing
    --cov-fail-under=80

# .coveragerc
[run]
source = api
omit =
    */tests/*
    */migrations/*
    */__init__.py

[report]
exclude_lines =
    pragma: no cover
    def __repr__
    raise AssertionError
    raise NotImplementedError
    if __name__ == "__main__":
    if TYPE_CHECKING:
```

### Command:

```bash
# Run tests with coverage
make coverage

# View HTML report
open htmlcov/index.html
```
