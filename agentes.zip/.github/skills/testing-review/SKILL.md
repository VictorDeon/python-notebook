---
name: testing-review
description: Evaluates the adequacy of test coverage with appropriate mocks for external services and significant test cases, ensuring that critical code is tested, that external dependencies are correctly mocked, and that tests follow clear and reusable standards.
---

# Skill: Testing Review

## Objective

Ensure adequate test coverage with appropriate mocks for external services and meaningful test cases.

## When to Use

- During code reviews with new functionality
- When adding tests to existing code
- When validating test files
- When reviewing test coverage
- When analyzing mock strategies

## Severity

🟢 **LOW** — Tests are essential for quality, but typically don't block merges

---

## Testing Checklist

* [Critical Code Coverage](./checklist/critical-code-coverage.md)
* [External Service Mocks](./checklist/external-service-mocks.md)
* [Descriptive Test Naming](./checklist/descriptive-test-naming.md)
* [Arrange-Act-Assert Pattern](./checklist/arrange-act-assert-pattern.md)
* [Edge Case Testing](./checklist/edge-case-testing.md)
* [Reusable Fixtures](./checklist/reusable-fixtures.md)
* [Integration Tests with FastAPI](./checklist/integration-tests-with-fastapi.md)
* [Parameterized Tests](./checklist/parameterized-tests.md)
* [Code Coverage](./checklist/code-coverage.md)
* [Asynchronous Tests](./checklist/asynchronous-tests.md)

---

## Mock Patterns

* [Firestore Mock](./patterns/firestore-mock.md)
* [HTTP Client Mock](./patterns/http-client-mock.md)

---

## Finding Template

You can find the complete testing review skill template [here](./template.md).

---

## References

- [Pytest Documentation](https://docs.pytest.org/)
- [FastAPI Testing](https://fastapi.tiangolo.com/tutorial/testing/)
- [pytest-asyncio](https://pytest-asyncio.readthedocs.io/)
- [pytest-mock](https://pytest-mock.readthedocs.io/)
- [Coverage.py](https://coverage.readthedocs.io/)
