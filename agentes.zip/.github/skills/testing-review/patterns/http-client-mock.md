## Pattern: HTTP Client Mock

```python
@pytest.fixture
def mock_http_client(mocker):
    """Mock of asynchronous HTTP client."""
    mock_response = Mock()
    mock_response.status_code = 200
    mock_response.json.return_value = {"data": "success"}

    mock_client = AsyncMock()
    mock_client.get.return_value = mock_response
    mock_client.post.return_value = mock_response

    mocker.patch('api.utils.get_http_client', return_value=mock_client)

    return mock_client
```
