## Pattern: Firestore Mock

```python
@pytest.fixture
def mock_firestore_document(mocker):
    """Complete Firestore document mock."""
    mock_doc = Mock()
    mock_doc.id = "doc123"
    mock_doc.exists = True
    mock_doc.to_dict.return_value = {
        "email": "user@example.com",
        "name": "João Silva"
    }

    mock_ref = Mock()
    mock_ref.get.return_value = mock_doc
    mock_ref.update = Mock()
    mock_ref.delete = Mock()

    mock_collection = Mock()
    mock_collection.document.return_value = mock_ref
    mock_collection.add.return_value = (mock_ref, "new_doc_id")

    mock_db = mocker.patch('engines.database.db')
    mock_db.collection.return_value = mock_collection

    return mock_db
```
