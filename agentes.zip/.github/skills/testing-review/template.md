### [Title] — `file.py:line`

**Category:** Testing

**Location:** `api/orders/tests/test_orders.py` (or missing file)

**Description:**

Critical payment processing code without adequate test coverage.

**Evidence:**

```python
# controllers/payment.py - Critical code
async def process_payment(order_id: str):
    # Complex logic without tests
    ...

# tests/ - No corresponding test found
```

**Impact:**

- Risk of bugs in production
- Hinders future refactoring
- No guarantee of correct behavior
- **Estimated risk:** Medium - Compromised quality

**Suggested Solution:**

```python
# tests/test_payment.py
import pytest
from unittest.mock import Mock

@pytest.mark.asyncio
async def test_process_payment_success(mock_stripe):
    """Tests successful payment processing."""
    # Arrange
    order_id = "order123"
    mock_stripe.charge.return_value = {"status": "succeeded"}

    # Act
    result = await process_payment(order_id)

    # Assert
    assert result["status"] == "succeeded"
    mock_stripe.charge.assert_called_once()

@pytest.mark.asyncio
async def test_process_payment_card_declined(mock_stripe):
    """Tests failure due to declined card."""
    order_id = "order123"
    mock_stripe.charge.side_effect = CardError("declined")

    with pytest.raises(PaymentError):
        await process_payment(order_id)
```

**References:**

- [Pytest Documentation](https://docs.pytest.org/)
- [FastAPI Testing](https://fastapi.tiangolo.com/tutorial/testing/)
