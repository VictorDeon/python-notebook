## Response Compression

### ✅ Compression Middleware:

```python
from fastapi.middleware.gzip import GZipMiddleware

app = FastAPI()

# Compresses responses > 1KB
app.add_middleware(GZipMiddleware, minimum_size=1000)

@router.get("/large-data")
async def get_large_data():
    # Returns large list
    data = db.collection('items').limit(1000).get()
    # Response will be compressed automatically
    return [item.to_dict() for item in data]
```

### ✅ Benefit:

Reduces size of large payloads by ~70-90%
