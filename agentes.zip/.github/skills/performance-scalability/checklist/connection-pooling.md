## Connection Pooling

### ✅ Pool Configuration:

```python
import httpx

# HTTP client with connection pooling
http_client = httpx.AsyncClient(
    timeout=10.0,
    limits=httpx.Limits(
        max_connections=100,        # Maximum simultaneous connections
        max_keepalive_connections=20,  # Keepalive connections
        keepalive_expiry=30.0      # Keepalive time
    )
)

# For database (example with asyncpg)
from asyncpg import create_pool

db_pool = await create_pool(
    dsn=DATABASE_URL,
    min_size=10,
    max_size=100,
    command_timeout=60
)
```
