## Streaming for Large Files

### ❌ Common Problem:

```python
# ❌ HIGH: Loading entire file into memory
@router.get("/files/{file_id}")
async def download_file(file_id: str):
    file_content = storage.download_file(file_id)  # Could be 100MB+!
    return Response(content=file_content, media_type="application/octet-stream")
```

### ✅ Solution with Streaming:

```python
from fastapi.responses import StreamingResponse
import io

@router.get("/files/{file_id}")
async def download_file(file_id: str):
    """Streams file without loading into memory."""

    # Storage returns generator or async generator
    file_stream = storage.download_file_stream(file_id)

    return StreamingResponse(
        file_stream,
        media_type="application/octet-stream",
        headers={
            "Content-Disposition": f"attachment; filename={file_id}"
        }
    )
```
