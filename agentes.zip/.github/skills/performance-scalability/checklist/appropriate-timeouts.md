## Appropriate Timeouts

### ✅ Timeout Configuration:

```python
import httpx

# Granular timeouts
timeout = httpx.Timeout(
    connect=5.0,    # Time to establish connection
    read=10.0,      # Time to read response
    write=5.0,      # Time to send request
    pool=5.0        # Time to get connection from pool
)

client = httpx.AsyncClient(timeout=timeout)

# Or simple timeout
client = httpx.AsyncClient(timeout=10.0)
```
