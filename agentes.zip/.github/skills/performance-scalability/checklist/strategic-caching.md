## Strategic Caching

### ❌ Common Problem:

```python
# ❌ MEDIUM: Recalculating static data on every request
@router.get("/stats/global")
async def get_global_stats():
    # Heavy calculation executed on every request
    total_users = db.collection('users').count().get()
    total_posts = db.collection('posts').count().get()
    # ... more costly calculations
    return {"users": total_users, "posts": total_posts}
```

### ✅ Solution with Cache:

```python
from functools import lru_cache
import time

@lru_cache(maxsize=1)
def _get_cached_stats(cache_key: int):
    """Cache stats for 5 minutes."""
    total_users = db.collection('users').count().get()[0][0].value
    total_posts = db.collection('posts').count().get()[0][0].value
    return {"users": total_users, "posts": total_posts}

@router.get("/stats/global")
async def get_global_stats():
    # Cache key changes every 5 minutes (300 seconds)
    cache_key = int(time.time() // 300)

    loop = asyncio.get_event_loop()
    stats = await loop.run_in_executor(
        None,
        _get_cached_stats,
        cache_key
    )

    return stats
```

### ✅ Alternative with Redis:

```python
import aioredis

redis = await aioredis.create_redis_pool('redis://localhost')

@router.get("/stats/global")
async def get_global_stats():
    # Try cache first
    cached = await redis.get('stats:global')
    if cached:
        return json.loads(cached)

    # Calculate if not in cache
    loop = asyncio.get_event_loop()
    stats = await loop.run_in_executor(None, calculate_stats)

    # Save to cache for 5 minutes
    await redis.setex(
        'stats:global',
        300,
        json.dumps(stats)
    )

    return stats
```
