## Async/Await for I/O Operations

### ❌ Common Problem:

```python
# ❌ LOW: Blocking calls in async route
@router.get("/data")
async def get_data():
    # Firestore client is synchronous - blocks!
    users = db.collection('users').get()

    # Synchronous HTTP request - blocks!
    response = requests.get("https://api.example.com/data")

    return {"users": users, "external": response.json()}
```

### ✅ Solution:

```python
import asyncio
import httpx
from functools import partial

@router.get("/data")
async def get_data():
    loop = asyncio.get_event_loop()

    # Firestore in thread pool
    users_task = loop.run_in_executor(
        None,
        lambda: db.collection('users').limit(100).get()
    )

    # Asynchronous HTTP client
    async with httpx.AsyncClient(timeout=10.0) as client:
        external_task = client.get("https://api.example.com/data")

        # Execute both in parallel
        users, external = await asyncio.gather(
            users_task,
            external_task
        )

    return {
        "users": [u.to_dict() for u in users],
        "external": external.json()
    }
```

### ✅ Benefit:

Operations execute in parallel instead of sequentially
