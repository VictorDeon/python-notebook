## Serialization Optimization

### ❌ Common Problem:

```python
# ❌ LOW: Manual serialization
@router.get("/users")
async def list_users():
    users = db.collection('users').limit(100).get()
    # Slow serialization
    return [
        {
            "id": u.id,
            "email": u.get('email'),
            "name": u.get('name'),
            # ... many fields
        }
        for u in users
    ]
```

### ✅ Solution with response_model:

```python
@router.get("/users", response_model=List[UserModel])
async def list_users():
    users = db.collection('users').limit(100).get()
    # Pydantic serializes efficiently
    return [UserModel(id=u.id, **u.to_dict()) for u in users]
```
