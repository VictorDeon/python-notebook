## Lazy Loading of Related Data

### ❌ Common Problem:

```python
# ❌ MEDIUM: Always loading related data
@router.get("/users/{user_id}")
async def get_user(user_id: str) -> UserModel:
    user = db.collection('users').document(user_id).get()
    posts = db.collection('posts').where('user_id', '==', user_id).get()
    comments = db.collection('comments').where('user_id', '==', user_id).get()

    # Always loads posts and comments, even if not needed
    return UserModel(
        **user.to_dict(),
        posts=[p.to_dict() for p in posts],
        comments=[c.to_dict() for c in comments]
    )
```

### ✅ Solution with Query Params:

```python
@router.get("/users/{user_id}")
async def get_user(
    user_id: str,
    include_posts: bool = Query(default=False),
    include_comments: bool = Query(default=False)
) -> UserModel:
    """Returns user with lazy loading options."""
    loop = asyncio.get_event_loop()

    # Always fetches user
    user_task = loop.run_in_executor(
        None,
        lambda: db.collection('users').document(user_id).get()
    )

    tasks = [user_task]

    # Conditionally fetches posts
    if include_posts:
        posts_task = loop.run_in_executor(
            None,
            lambda: db.collection('posts')
                .where('user_id', '==', user_id)
                .limit(50)
                .get()
        )
        tasks.append(posts_task)

    # Conditionally fetches comments
    if include_comments:
        comments_task = loop.run_in_executor(
            None,
            lambda: db.collection('comments')
                .where('user_id', '==', user_id)
                .limit(50)
                .get()
        )
        tasks.append(comments_task)

    results = await asyncio.gather(*tasks)

    user_data = results[0].to_dict()
    if include_posts:
        user_data['posts'] = [p.to_dict() for p in results[1]]
    if include_comments:
        offset = 2 if include_posts else 1
        user_data['comments'] = [c.to_dict() for c in results[offset]]

    return UserModel(**user_data)
```
