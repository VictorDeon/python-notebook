## Pagination for Large Lists

### ❌ Common Problem:

```python
# ❌ MEDIUM: Returning complete list without pagination
@router.get("/users")
async def list_users() -> List[UserModel]:
    users = db.collection('users').get()  # Could have thousands!
    return [UserModel(**u.to_dict()) for u in users]
```

### ✅ Solution with Pagination:

```python
from typing import Optional

class PaginatedResponse(BaseModel):
    items: List[UserModel]
    total: int
    page: int
    page_size: int
    has_next: bool

@router.get("/users", response_model=PaginatedResponse)
async def list_users(
    page: int = Query(default=1, ge=1, description="Page number"),
    page_size: int = Query(default=20, ge=1, le=100, description="Items per page")
):
    """List users with pagination."""
    offset = (page - 1) * page_size

    loop = asyncio.get_event_loop()

    # Paginated query
    users_task = loop.run_in_executor(
        None,
        lambda: db.collection('users')
            .order_by('created_at')
            .limit(page_size)
            .offset(offset)
            .get()
    )

    # Total count (can be cached)
    total_task = loop.run_in_executor(
        None,
        lambda: db.collection('users').count().get()
    )

    users, total_result = await asyncio.gather(users_task, total_task)
    total = total_result[0][0].value

    return PaginatedResponse(
        items=[UserModel(**u.to_dict()) for u in users],
        total=total,
        page=page,
        page_size=page_size,
        has_next=(offset + page_size) < total
    )
```
