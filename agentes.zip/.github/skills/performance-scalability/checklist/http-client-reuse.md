## HTTP Client Reuse

### ❌ Common Problem:

```python
# ❌ LOW: HTTP client created on every request
@router.get("/external-data")
async def get_external_data():
    # New client with each request!
    client = httpx.AsyncClient()
    response = await client.get("https://api.example.com")
    await client.aclose()
    return response.json()
```

### ✅ Solution with Singleton Client:

```python
# api/utils.py
from httpx import AsyncClient
from typing import Optional

_http_client: Optional[AsyncClient] = None

def get_http_client() -> AsyncClient:
    """Returns singleton HTTP client."""
    global _http_client
    if _http_client is None:
        _http_client = AsyncClient(
            timeout=10.0,
            limits=httpx.Limits(
                max_connections=100,
                max_keepalive_connections=20
            )
        )
    return _http_client

# routes/endpoints.py
@router.get("/external-data")
async def get_external_data():
    client = get_http_client()  # Reuses connections
    response = await client.get("https://api.example.com")
    return response.json()
```

### ✅ Benefit:

Reuses connection pool, avoids creation overhead
