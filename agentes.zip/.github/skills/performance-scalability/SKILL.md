---
name: performance-scalability
description: Essential skill for ensuring application responsiveness and scalability. Covers I/O operation optimizations, resource management, and concurrency patterns in FastAPI. Use during code reviews with I/O-intensive operations, when implementing new endpoints that consume external services, when analyzing high-latency endpoints, or when validating resource usage (memory, connections). Includes best practices such as appropriate async/await, HTTP client reuse, pagination of large lists, lazy loading of related data, file streaming, response compression, connection pooling, strategic caching, and configured timeouts. Performance is important, but generally does not block merging in PRs (low-medium severity).
---

# Skill: Performance and Scalability

## Objective

Ensure the application is responsive and scalable by optimizing I/O operations, resource management, and concurrency patterns.

## When to Use

- During code reviews with intensive I/O operations
- When implementing new endpoints that interact with external services
- When analyzing endpoints with high latency
- When reviewing resource usage (memory, connections)
- When validating concurrency patterns

## Severity

🟢 **LOW-MEDIUM** — Performance is important, but doesn't usually block merge

---

## Performance Checklist

* [Async/Await for I/O Operations](./checklist/asyncawait-for-io-operations.md)
* [HTTP Client Reuse](./checklist/http-client-reuse.md)
* [Pagination for Large Lists](./checklist/pagination-for-large-lists.md)
* [Lazy Loading of Related Data](./checklist/lazy-loading-of-related-data.md)
* [Streaming for Large Files](./checklist/streaming-for-large-files.md)
* [Response Compression](./checklist/response-compression.md)
* [Connection Pooling](./checklist/connection-pooling.md)
* [Strategic Caching](./checklist/strategic-caching.md)
* [Serialization Optimization](./checklist/serialization-optimization.md)
* [Appropriate Timeouts](./checklist/appropriate-timeouts.md)

---

## Performance Monitoring

* [Integrate Performance Logging Middleware](./monitoring/performance-logging-middleware.md)
* [Set Up Performance Alerts](./monitoring/performance-alerts.md)

---

## Concurrency Patterns

* [Multiple Queries in Parallel](./patterns/multiple-queries-in-parallel.md)
* [Fallback for External Services](./patterns/fallback-for-external-services.md)

---

## Finding Template

You can find the complete performance and scalability skill template [here](./template.md).

---

## References

- [FastAPI Async](https://fastapi.tiangolo.com/async/)
- [Python asyncio](https://docs.python.org/3/library/asyncio.html)
- [HTTPX AsyncClient](https://www.python-httpx.org/async/)
- [Performance Best Practices](https://fastapi.tiangolo.com/deployment/concepts/)
