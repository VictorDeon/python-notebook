## Performance Alerts

```python
# Alert if request takes too long
if process_time > 5.0:
    logger.warning(
        "Slow request detected",
        json_data={
            "url": str(request.url),
            "process_time": process_time,
            "method": request.method
        }
    )
```
