## Performance Logging Middleware

```python
import time
from fastapi import Request
from engines.logger import logger

@app.middleware("http")
async def log_requests(request: Request, call_next):
    start_time = time.time()

    response = await call_next(request)

    process_time = time.time() - start_time

    logger.info(
        "Request completed",
        json_data={
            "method": request.method,
            "url": str(request.url),
            "status_code": response.status_code,
            "process_time": round(process_time, 3),
            "client_ip": request.client.host
        }
    )

    # Header para debugging
    response.headers["X-Process-Time"] = str(process_time)

    return response
```
