## Pattern: Multiple Queries in Parallel

```python
async def fetch_dashboard_data(user_id: str):
    """Fetches all dashboard data in parallel."""
    loop = asyncio.get_event_loop()

    # All queries in parallel
    user_task = loop.run_in_executor(
        None,
        lambda: db.collection('users').document(user_id).get()
    )
    posts_task = loop.run_in_executor(
        None,
        lambda: db.collection('posts')
            .where('user_id', '==', user_id)
            .limit(10)
            .get()
    )
    stats_task = loop.run_in_executor(
        None,
        lambda: db.collection('stats').document(user_id).get()
    )

    user, posts, stats = await asyncio.gather(
        user_task,
        posts_task,
        stats_task
    )

    return {
        "user": user.to_dict(),
        "recent_posts": [p.to_dict() for p in posts],
        "stats": stats.to_dict()
    }
```
