## Pattern: Fallback for External Services

```python
async def fetch_with_fallback(url: str, fallback_value=None):
    """Tries external service with fallback."""
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            response = await client.get(url)
            return response.json()
    except (httpx.TimeoutException, httpx.RequestError) as e:
        logger.warning(f"External service failed: {e}")
        return fallback_value
```
