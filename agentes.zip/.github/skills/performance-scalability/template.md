### [Title] — `file.py:line`

**Category:** Performance and Scalability

**Location:** `api/users/routes/users.py:45` (endpoint `list_users`)

**Description:**

Complete user list returned without pagination, potentially causing high latency and excessive memory usage.

**Evidence:**

```python
@router.get("/users")
async def list_users():
    users = db.collection('users').get()  # No limit!
    return [UserModel(**u.to_dict()) for u in users]
```

**Impact:**

- High latency for large datasets
- High memory usage
- Timeout on collections with thousands of documents
- **Estimated risk:** Medium - May cause production issues

**Suggested Solution:**

```python
class PaginatedResponse(BaseModel):
    items: List[UserModel]
    page: int
    page_size: int
    has_next: bool

@router.get("/users", response_model=PaginatedResponse)
async def list_users(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100)
):
    offset = (page - 1) * page_size
    users = db.collection('users').limit(page_size).offset(offset).get()

    return PaginatedResponse(
        items=[UserModel(**u.to_dict()) for u in users],
        page=page,
        page_size=page_size,
        has_next=len(users) == page_size
    )
```

**References:**

- [FastAPI Performance Tips](https://fastapi.tiangolo.com/deployment/concepts/)
