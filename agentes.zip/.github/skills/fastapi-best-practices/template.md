### [Title] — `file.py:line`

**Category:** FastAPI - Best Practices

**Location:** `api/users/routes/users.py:25` (endpoint `create_user`)

**Description:**

Endpoint without proper OpenAPI documentation and business logic mixed with route.

**Evidence:**

```python
@router.post("/users")
async def create_user(data: dict):
    # Inline business logic
    if db.collection('users').where('email', '==', data['email']).get():
        raise HTTPException(409, "Email already exists")
    return await db.collection('users').add(data)
```

**Impact:**

- Incomplete automatic documentation in /docs
- Code difficult to test and reuse
- Weak validation (accepts any dict)
- **Estimated risk:** Medium - Hampers maintenance

**Suggested Solution:**

```python
# routes/users.py
@router.post(
    "/users",
    response_model=UserModel,
    status_code=status.HTTP_201_CREATED,
    summary="Create new user"
)
async def create_user(data: CreateUserDTO) -> UserModel:
    """Creates new user in the system."""
    return await user_controller.create_user(data)

# controllers/user.py
class UserController:
    async def create_user(self, data: CreateUserDTO) -> UserModel:
        # Isolated business logic
        ...
```

**References:**
- [FastAPI Best Practices](https://fastapi.tiangolo.com/tutorial/)
- [Bigger Applications](https://fastapi.tiangolo.com/tutorial/bigger-applications/)

