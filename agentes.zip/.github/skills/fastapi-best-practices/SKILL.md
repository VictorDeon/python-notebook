---
name: fastapi-best-practices
description: This skill provides practical guidelines to ensure FastAPI applications are clean, secure, and maintainable — covering complete OpenAPI documentation, dependency injection, separation of concerns (routes → controllers), proper use of async/await, centralized error handling, CORS/headers configuration, and versioning and module organization patterns. Use it when reviewing endpoints, creating new modules/DTOs, validating integrations with Firestore or external services, and when configuring middlewares and handlers to ensure performance, security, and a good API experience.
---

# Skill: FastAPI Best Practices

## Purpose

Ensure clean, maintainable, and well-documented FastAPI code, following modern async/await and dependency injection patterns.

## When to Use

- During endpoint and route reviews
- When creating new FastAPI modules
- When validating OpenAPI documentation
- When reviewing exception handling
- When validating separation of concerns architecture

## Severity

🟡 **MEDIUM** — Best practices improve long-term maintainability

---

## Best Practices Checklist

* [1. Complete OpenAPI Documentation](./examples/complete-openapi-documentation.md)
* [2. Explicit Response Model and Status Code](./examples/explicit-response-model-and-status-code.md)
* [3. Dependency Injection for Authentication](./examples/dependency-injection-for-authentication.md)
* [4. Separation of Concerns (Routes → Controllers)](./examples/separation-of-concerns.md)
* [5. Centralized Exception Handlers](./examples/centralized-exception-handlers.md)
* [6. Proper Async/Await Usage](./examples/proper-async-await-usage.md)
* [7. Background Tasks for Long Operations](./examples/background-tasks-for-long-operations.md)
* [8. Path and Query Params Validation](./examples/path-and-query-params-validation.md)
* [9. CORS and Security Headers](./examples/cors-and-security-headers.md)
* [10. API Versioning](./examples/api-versioning.md)

---

## Recommended Module Structure

```
api/module/
├── __init__.py
├── enums.py                # Enums
├── routes/
│   └── __init__.py         # FastAPI APIRouter definition
│   └── endpoints.py        # FastAPI routes
├── controllers/
│   └── __init__.py         # Controller definitions
│   └── business_logic.py   # Business logic
├── dtos/
│   └── __init__.py         # DTOs definitions
│   └── schemas.py          # Pydantic DTOs
├── models/
│   └── __init__.py         # Models DB definitions
│   └── model.py            # Database models
└── tests/
    └── __init__.py         # Tests package
    └── test_endpoints.py   # Tests
```

---

## Router Patterns

* [Pattern 1: Router with Prefix and Tags](./patterns/router-with-prefix-and-tags.md)
* [Pattern 2: Multiple Routers per Module](./patterns/multiple-routers-per-module.md)

---

## Finding Template

When reviewing FastAPI code, use this [template](./template.md) to identify common issues and suggest improvements.

---

## References

- [FastAPI Documentation](https://fastapi.tiangolo.com/)
- [FastAPI Best Practices](https://github.com/zhanymkanov/fastapi-best-practices)
- [Dependency Injection](https://fastapi.tiangolo.com/tutorial/dependencies/)
- [Background Tasks](https://fastapi.tiangolo.com/tutorial/background-tasks/)
- [CORS Middleware](https://fastapi.tiangolo.com/tutorial/cors/)
