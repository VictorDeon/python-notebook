## Path and Query Params Validation

### ❌ Common Problem:

```python
# ❌ LOW: No parameter validation
@router.get("/users/{user_id}")
async def get_user(user_id: str, include_posts: bool = False):
    ...
```

### ✅ Solution with validation:

```python
from fastapi import Path, Query

@router.get("/users/{user_id}")
async def get_user(
    user_id: str = Path(
        ...,
        min_length=20,
        max_length=20,
        description="User ID in Firestore format"
    ),
    include_posts: bool = Query(
        default=False,
        description="Include user posts in response"
    ),
    limit: int = Query(
        default=10,
        ge=1,
        le=100,
        description="Number of posts to return (if include_posts=true)"
    )
) -> UserModel:
    ...
```
