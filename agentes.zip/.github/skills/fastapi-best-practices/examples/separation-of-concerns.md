## Separation of Concerns (Routes → Controllers)

### ❌ Common Problem:

```python
# ❌ MEDIUM: Business logic in route
@router.post("/users")
async def create_user(data: CreateUserDTO):
    # Business logic mixed with route
    if db.collection('users').where('email', '==', data.email).get():
        raise HTTPException(409, "Email already exists")

    hashed_pwd = hash_password(data.password.get_secret_value())
    user_data = {
        'email': data.email,
        'password': hashed_pwd,
        'created_at': datetime.now()
    }

    doc_ref = db.collection('users').add(user_data)
    return {"id": doc_ref.id, **user_data}
```

### ✅ Solution with Controller:

```python
# routes/users.py
@router.post(
    "/users",
    response_model=UserModel,
    status_code=status.HTTP_201_CREATED
)
async def create_user(data: CreateUserDTO) -> UserModel:
    """Creates new user."""
    return await user_controller.create_user(data)

# controllers/user.py
class UserController:
    async def create_user(self, data: CreateUserDTO) -> UserModel:
        """Business logic for user creation."""
        # Check duplicate email
        if await self._email_exists(data.email):
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=_("user.email_already_exists")
            )

        # Hash password
        hashed_pwd = hash_password(data.password.get_secret_value())

        # Create user
        user_data = {
            'email': data.email,
            'password': hashed_pwd,
            'name': data.name,
            'created_at': datetime.now()
        }

        doc_ref = db.collection('users').add(user_data)

        return UserModel(id=doc_ref.id, **user_data)
```

### Benefits:

- Simple and readable routes
- Logic testable in isolation
- Code reusability
