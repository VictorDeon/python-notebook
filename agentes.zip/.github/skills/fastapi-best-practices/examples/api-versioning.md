## API Versioning

### ✅ Versioning pattern:

```python
from fastapi import APIRouter

# Version in route
router_v1 = APIRouter(prefix="/api/v1")
router_v2 = APIRouter(prefix="/api/v2")

@router_v1.get("/users")
async def get_users_v1():
    """API version 1."""
    ...

@router_v2.get("/users")
async def get_users_v2():
    """API version 2 with pagination."""
    ...

app.include_router(router_v1)
app.include_router(router_v2)
```
