## Proper Async/Await Usage

### ❌ Common Problems:

```python
# ❌ LOW: async without await (unnecessary)
@router.get("/hello")
async def hello():
    return {"message": "Hello"}  # No I/O, doesn't need to be async

# ❌ MEDIUM: Blocking call in async function
@router.get("/users")
async def get_users():
    users = db.collection('users').get()  # Blocking!
    return users
```

### ✅ Solutions:

```python
# ✅ No async if there's no I/O
@router.get("/hello")
def hello():
    return {"message": "Hello"}

# ✅ async + await for I/O operations
@router.get("/users")
async def get_users():
    # If Firestore client is not async, use run_in_executor
    loop = asyncio.get_event_loop()
    users = await loop.run_in_executor(
        None,
        lambda: db.collection('users').get()
    )
    return users

# ✅ Or use native async client if available
@router.get("/external-api")
async def get_external_data():
    async with httpx.AsyncClient() as client:
        response = await client.get("https://api.example.com/data")
        return response.json()
```
