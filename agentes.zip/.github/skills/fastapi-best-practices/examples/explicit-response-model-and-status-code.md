## Explicit Response Model and Status Code

### ❌ Common Problem:

```python
# ❌ MEDIUM: Without response_model and implicit status_code
@router.get("/users/{user_id}")
async def get_user(user_id: str):
    user = await controller.get(user_id)
    return user  # Can return anything
```

### ✅ Solution:

```python
from fastapi import status, HTTPException

@router.get(
    "/users/{user_id}",
    response_model=UserModel,
    status_code=status.HTTP_200_OK,
    summary="Get user by ID"
)
async def get_user(user_id: str) -> UserModel:
    """Returns data of a specific user."""
    user = await user_controller.get_user(user_id)

    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=_("user.not_found")
        )

    return user
```

### Benefits:

- Type safety
- Automatic output validation
- Precise documentation
- Automatic serialization
