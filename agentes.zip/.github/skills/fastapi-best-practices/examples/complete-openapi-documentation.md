## Complete OpenAPI Documentation

### ❌ Common Problem:

```python
# ❌ MEDIUM: Endpoint without documentation
@router.post("/users")
async def create_user(data: dict):
    return await controller.create(data)
```

### ✅ Solution:

```python
from fastapi import status, APIRouter
from pydantic import BaseModel

router = APIRouter(prefix="/users", tags=["Users"])

@router.post(
    "",
    response_model=UserModel,
    status_code=status.HTTP_201_CREATED,
    summary="Create new user",
    responses={
        201: {
            "description": "User created",
            "content": {
                "application/json": {
                    "example": {
                        "id": "123",
                        "email": "user@example.com",
                        "name": "John Doe"
                    }
                }
            }
        },
        422: {"description": "Invalid input data"},
        409: {"description": "Email already registered"}
    }
)
async def create_user(
    data: CreateUserDTO
) -> UserModel:
    """
    Creates a new user in the system.

    - **email**: Unique user email
    - **name**: Full name
    - **password**: Password with minimum 8 characters
    """
    return await user_controller.create_user(data)
```

### Benefits:

- Clear automatic documentation in `/docs`
- Better experience for API consumers
- Request/response examples
