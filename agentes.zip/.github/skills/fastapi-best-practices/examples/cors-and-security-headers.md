## CORS and Security Headers

### ✅ Proper Configuration:

```python
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

# ❌ Avoid in production:
# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=["*"],  # Too permissive!
#     allow_credentials=True,
# )

# ✅ Secure configuration:
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "https://app.example.com",
        "https://dashboard.example.com"
    ],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE"],
    allow_headers=["*"],
    max_age=3600
)

# Security headers
@app.middleware("http")
async def add_security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    return response
```
