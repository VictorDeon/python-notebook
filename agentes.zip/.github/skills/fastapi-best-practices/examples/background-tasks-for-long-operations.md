## Background Tasks for Long Operations

### ❌ Common Problem:

```python
# ❌ MEDIUM: Long operation blocking response
@router.post("/users")
async def create_user(data: CreateUserDTO):
    user = await controller.create(data)

    # Send email (takes ~2s)
    send_welcome_email(user.email)

    return user  # Client waits 2s+ for response
```

### ✅ Solution with Background Tasks:

```python
from fastapi import BackgroundTasks

@router.post(
    "/users",
    response_model=UserModel,
    status_code=status.HTTP_201_CREATED
)
async def create_user(
    data: CreateUserDTO,
    background_tasks: BackgroundTasks
):
    """Creates user and schedules email sending."""
    user = await user_controller.create_user(data)

    # Email sent in background
    background_tasks.add_task(
        send_welcome_email,
        email=user.email,
        name=user.name
    )

    return user  # Immediate response
```

### Benefits:

- Faster response
- Better user experience
- Long operations don't block
