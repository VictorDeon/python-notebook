## 5. Centralized Exception Handlers

### ❌ Common Problem:

```python
# ❌ LOW: Exception handling in each endpoint
@router.get("/users/{user_id}")
async def get_user(user_id: str):
    try:
        user = await controller.get(user_id)
        return user
    except NotFoundError:
        raise HTTPException(404, "User not found")
    except ValidationError as e:
        raise HTTPException(422, str(e))
    except Exception as e:
        logger.error(f"Error: {e}")
        raise HTTPException(500, "Internal error")
```

### ✅ Solution with Global Exception Handler:

```python
# main.py
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

app = FastAPI()

class NotFoundError(Exception):
    """Resource not found."""
    pass

@app.exception_handler(NotFoundError)
async def not_found_handler(request: Request, exc: NotFoundError):
    return JSONResponse(
        status_code=status.HTTP_404_NOT_FOUND,
        content={"message": str(exc)}
    )

@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    logger.error(f"Unhandled error: {exc}")
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={"message": _("errors.internal_server_error")}
    )

# routes/users.py
@router.get("/users/{user_id}")
async def get_user(user_id: str) -> UserModel:
    """Clean endpoint - exceptions handled globally."""
    return await user_controller.get_user(user_id)
```
