## Dependency Injection for Authentication

### ❌ Common Problem:

```python
# ❌ MEDIUM: Inline authentication
@router.delete("/users/{user_id}")
async def delete_user(user_id: str, token: str = Header(...)):
    # Manual token validation
    user = verify_token(token)
    if not user or not user.is_admin:
        raise HTTPException(403)

    await controller.delete(user_id)
```

### ✅ Solution with Dependency Injection:

```python
from fastapi import Depends
from engines.security import get_current_user, get_current_admin_user
from api.models import User

@router.delete(
    "/users/{user_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete user"
)
async def delete_user(
    user_id: str,
    current_user: User = Depends(get_current_admin_user)
):
    """Deletes a user from the system (admins only)."""
    await user_controller.delete_user(user_id, current_user)
```

### Benefits:

- Cleaner code
- Reusable
- Testable (easy to mock)
- Automatic security documentation
