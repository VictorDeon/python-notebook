## Pattern: Router with Prefix and Tags

```python
from fastapi import APIRouter

router = APIRouter(
    prefix="/users",
    tags=["Users"],
    dependencies=[Depends(rate_limiter)],  # Applied to all routes
    responses={
        404: {"description": "User not found"},
        500: {"description": "Internal server error"}
    }
)
```
