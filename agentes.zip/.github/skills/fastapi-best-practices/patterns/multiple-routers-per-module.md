## Pattern: Multiple Routers per Module

```python
# api/users/routes/public.py
public_router = APIRouter(prefix="/users/public", tags=["Users - Public"])

@public_router.post("/register")
async def register(...):
    ...

# api/users/routes/admin.py
admin_router = APIRouter(
    prefix="/users/admin",
    tags=["Users - Admin"],
    dependencies=[Depends(get_current_admin_user)]
)

@admin_router.delete("/{user_id}")
async def delete_user(...):
    ...

# main.py
app.include_router(public_router)
app.include_router(admin_router)
```
