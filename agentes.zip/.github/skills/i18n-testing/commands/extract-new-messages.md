## Extract New Messages

```bash
# Extract strings `_("...")` into messages.pot
make extraction
```
