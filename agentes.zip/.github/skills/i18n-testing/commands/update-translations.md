## Update Translations

```bash
# Update messages.po with new strings from messages.pot
make translation
```
