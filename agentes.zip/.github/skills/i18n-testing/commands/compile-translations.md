## Compile Translations

```bash
# Compile messages.po into messages.mo (used at runtime)
make translate
```
