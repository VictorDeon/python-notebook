## Step 2: Check messages.pot

```bash
# Search in i18n/messages.pot
grep -A 2 "Usuário não encontrado" i18n/messages.pot
```

### Result:

```pot
#: api/authentication/controllers/users.py:45
msgid "Usuário não encontrado."
msgstr ""
```
