## Step 1: Identify the Message in Code

```python
# In api/authentication/controllers/users.py
if not user:
    raise HTTPException(
        status_code=404,
        detail=_("Usuário não encontrado.")
    )
```
