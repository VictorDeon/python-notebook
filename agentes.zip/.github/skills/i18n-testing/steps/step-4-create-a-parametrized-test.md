## Step 4: Create a Parametrized Test

```python
@pytest.mark.parametrize("lang,expected_message", [
    ("pt-BR", "Usuário não encontrado."),
    ("en-US", "User not found."),
])
async def test_user_not_found_i18n(lang: str, expected_message: str):
    # ... implementation
```
