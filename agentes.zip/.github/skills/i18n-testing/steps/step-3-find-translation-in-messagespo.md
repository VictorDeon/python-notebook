## Step 3: Find Translation in messages.po

```bash
# Search in i18n/en_US/LC_MESSAGES/messages.po
grep -A 2 "Usuário não encontrado" i18n/en_US/LC_MESSAGES/messages.po
```

### Result:

```po
#: api/authentication/controllers/users.py:45
msgid "Usuário não encontrado."
msgstr "User not found."
```
