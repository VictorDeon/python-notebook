import pytest
from httpx import AsyncClient
from fastapi import status
from api.main import app


@pytest.mark.parametrize("product_id,lang,expected_status,expected_message", [
    # Product not found
    ("non-existent", "pt-BR", status.HTTP_404_NOT_FOUND, "Produto não encontrado."),
    ("non-existent", "en-US", status.HTTP_404_NOT_FOUND, "Product not found."),
    # Insufficient stock
    ("out-of-stock", "pt-BR", status.HTTP_400_BAD_REQUEST, "Estoque insuficiente."),
    ("out-of-stock", "en-US", status.HTTP_400_BAD_REQUEST, "Insufficient stock."),
], ids=[
    "not_found_pt",
    "not_found_en",
    "insufficient_stock_pt",
    "insufficient_stock_en"
])
async def test_purchase_validation_i18n(
    product_id: str,
    lang: str,
    expected_status: int,
    expected_message: str
):
    """
    Tests purchase validation messages in multiple languages.

    Scenarios:
    - Product not found (pt-BR and en-US)
    - Insufficient stock (pt-BR and en-US)

    Assertions:
    - Correct status code
    - Message translated correctly
    """

    # Arrange
    payload = {"product_id": product_id, "quantity": 1}

    # Act
    async with AsyncClient(app=app, base_url="http://test") as client:
        response = await client.post(
            "/api/v1/purchases",
            json=payload,
            headers={"Accept-Language": lang}
        )

    # Assert
    assert response.status_code == expected_status
    response_data = response.json()
    assert response_data["message"] == expected_message
