## Issue: Translation is not working

### Diagnosis:

1. Check if the message exists in `messages.pot`
2. Check if the translation exists in `messages.po`
3. Run `make translate` to compile
