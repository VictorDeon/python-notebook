## Issue: i18n test fails for en-US

### Cause:

The translation might be missing or incorrect

### Fix:

1. Run `make extraction`
2. Check `i18n/en_US/LC_MESSAGES/messages.po`
3. Add or correct the translation manually
4. Run `make translate`
5. Run tests again
