## Issue: Message appears in English for pt-BR

### Cause:

The message was added directly in English in the code

```python
# ❌ Wrong
raise HTTPException(detail="User not found")

# ✅ Correct
raise HTTPException(detail=_("Usuário não encontrado."))
```
