## Pattern: Combined Parametrized Test

Combine multiple validations in a parametrized test:

```python
@pytest.mark.parametrize("scenario,payload,lang,expected_status,expected_message", [
    # Scenario 1: Missing required field (pt-BR)
    (
        "missing_email_pt",
        {"password": "123456"},
        "pt-BR",
        status.HTTP_422_UNPROCESSABLE_ENTITY,
        "O campo 'email' é obrigatório."
    ),
    # Scenario 2: Missing required field (en-US)
    (
        "missing_email_en",
        {"password": "123456"},
        "en-US",
        status.HTTP_422_UNPROCESSABLE_ENTITY,
        "The field 'email' is required."
    ),
    # Scenario 3: Invalid email (pt-BR)
    (
        "invalid_email_pt",
        {"email": "invalid", "password": "123456"},
        "pt-BR",
        status.HTTP_422_UNPROCESSABLE_ENTITY,
        "Email inválido."
    ),
    # Scenario 4: Invalid email (en-US)
    (
        "invalid_email_en",
        {"email": "invalid", "password": "123456"},
        "en-US",
        status.HTTP_422_UNPROCESSABLE_ENTITY,
        "Invalid email."
    ),
], ids=lambda x: x if isinstance(x, str) else "")
async def test_user_validation_i18n(
    http_client: AsyncClient,
    scenario: str,
    payload: dict,
    lang: str,
    expected_status: int,
    expected_message: str
):
    """Tests user validations in multiple languages."""

    # Act
    async with http_client as client:
        response = await client.post(
            "/api/v1/users",
            json=payload,
            headers={"Accept-Language": lang}
        )

    # Assert
    assert response.status_code == expected_status
    response_data = response.json()
    assert expected_message in response_data["message"]
```
