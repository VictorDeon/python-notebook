## Pattern: Simple Message Test

```python
import pytest
from httpx import AsyncClient
from fastapi import status

@pytest.mark.parametrize("lang,expected_message", [
    ("pt-BR", "Produto não encontrado."),
    ("en-US", "Product not found."),
])
async def test_product_not_found_i18n(
    http_client: AsyncClient,
    lang: str,
    expected_message: str
):
    """
    Tests the product-not-found error message in multiple languages.

    Scenario:
    - Request a non-existent product
    - `Accept-Language` header sets the language

    Assertions:
    - Status 404
    - Message is translated correctly
    """

    # Arrange
    product_id = "non-existent-id"

    # Act
    async with http_client as client:
        response = await client.get(
            f"/api/v1/products/{product_id}",
            headers={"Accept-Language": lang}
        )

    # Assert
    assert response.status_code == status.HTTP_404_NOT_FOUND
    response_data = response.json()
    assert response_data["message"] == expected_message
```
