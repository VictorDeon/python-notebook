## Pattern: Test Multiple Different Messages

When an endpoint may return several different messages:

```python
@pytest.mark.parametrize("error_type,lang,expected_message", [
    ("not_found", "pt-BR", "Produto não encontrado."),
    ("not_found", "en-US", "Product not found."),
    ("insufficient_stock", "pt-BR", "Estoque insuficiente."),
    ("insufficient_stock", "en-US", "Insufficient stock."),
    ("insufficient_coins", "pt-BR", "Tico Coins insuficientes."),
    ("insufficient_coins", "en-US", "Insufficient Tico Coins."),
])
async def test_purchase_errors_i18n(
    http_client: AsyncClient,
    error_type: str,
    lang: str,
    expected_message: str
):
    """Tests different purchase errors in multiple languages."""

    # Arrange
    if error_type == "not_found":
        product_id = "non-existent"
    elif error_type == "insufficient_stock":
        product_id = "out-of-stock"
    elif error_type == "insufficient_coins":
        product_id = "expensive-product"

    payload = {"product_id": product_id, "quantity": 1}

    # Act
    async with http_client as client:
        response = await client.post(
            "/api/v1/purchases",
            json=payload,
            headers={"Accept-Language": lang}
        )

    # Assert
    response_data = response.json()
    assert expected_message in response_data["message"]
```
