## Pattern: Message with Variable Interpolation

Some messages include dynamic variables:

```python
# In code
_("O campo '{field}' é obrigatório.").format(field="email")
```

**Test**:

```python
@pytest.mark.parametrize("field,lang,expected_pattern", [
    ("email", "pt-BR", "O campo 'email' é obrigatório."),
    ("email", "en-US", "The field 'email' is required."),
    ("password", "pt-BR", "O campo 'password' é obrigatório."),
    ("password", "en-US", "The field 'password' is required."),
])
async def test_required_field_i18n(
    http_client: AsyncClient,
    field: str,
    lang: str,
    expected_pattern: str
):
    """Tests required field message with interpolation."""

    # Arrange
    payload = {}  # Missing the required field

    # Act
    async with http_client as client:
        response = await client.post(
            "/api/v1/users",
            json=payload,
            headers={"Accept-Language": lang}
        )

    # Assert
    assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY
    response_data = response.json()
    assert expected_pattern in response_data["message"]
```
