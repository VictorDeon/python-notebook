---
name: i18n-testing
description: This skill brings together practical strategies for testing internationalization (pt-BR and en-US) in FastAPI applications that use fastapi_babel, explaining what to check (user-facing messages and validations), how to locate strings in the code and translation files (messages.pot / messages.po / .mo), how to compile translations, assemble fixtures and clients with Accept-Language or user language, create parameterized tests that validate exact messages and variable interpolation, and when to use it: whenever adding/changing messages, supporting a new language, or preventing translation regressions in critical endpoints.
---

# Skill: Internationalization Testing (i18n)

This skill provides patterns and strategies for testing translated messages in FastAPI applications.

## When to Use This Skill

* When testing endpoints that return translatable messages
* When validating errors in multiple languages
* When ensuring consistency across translations
* When adding support for a new language

---

## Translation System

### Overview

This project uses `fastapi_babel` for internationalization:

* **Default language**: pt-BR (Portuguese - Brazil)
* **Translated language**: en-US (English - United States)
* **Translation function**: `from fastapi_babel import _`
* **Usage pattern**: `_("Mensagem em português aqui")`

### Translation Files

| File | Purpose |
|------|---------|
| `i18n/messages.pot` | Extracted message catalog (pt-BR) |
| `i18n/en_US/LC_MESSAGES/messages.po` | Translations for en-US (editable) |
| `i18n/en_US/LC_MESSAGES/messages.mo` | Compiled translations (binary) |

### Translation Flow

1. Python code: `_("Usuário não encontrado.")`
2. Extraction: `make extraction`
3. `messages.pot`: `msgid "Usuário não encontrado."`
4. Translation: `messages.po`: `msgstr "User not found."`
5. Compilation: `make translate`
6. Usage: `messages.mo` (used at runtime)

---

## How to Locate Translations

1. [Identify the message in code](./steps/step-1-identify-the-message-in-code.md)
2. [Check messages.pot](./steps/step-2-check-messagespot.md)
3. [Find translation in messages.po](./steps/step-3-find-translation-in-messagespo.md)
4. [Create a parametrized test](./steps/step-4-create-a-parametrized-test.md)

---

## i18n Testing Patterns

1. [Pattern 1: Simple Message Test](./patterns/simple-message-test.md)
2. [Pattern 2: Message with Variable Interpolation](./patterns/message-with-variable-interpolation.md)
3. [Pattern 3: Combined Parametrized Test](./patterns/combined-parametrized-test.md)
4. [Pattern 4: Test Multiple Different Messages](./patterns/test-multiple-different-messages.md)

---

## Common Messages and Translations

### Generic Error Messages

| Portuguese (pt-BR) | English (en-US) |
|--------------------|-----------------|
| `Erro interno do servidor.` | `Internal server error.` |
| `Não autorizado.` | `Unauthorized.` |
| `Acesso negado.` | `Access denied.` |
| `Token inválido.` | `Invalid token.` |
| `Token expirado.` | `Expired token.` |

### Validation Messages

| Portuguese (pt-BR) | English (en-US) |
|--------------------|-----------------|
| `O campo '{field}' é obrigatório.` | `The field '{field}' is required.` |
| `Email inválido.` | `Invalid email.` |
| `Senha muito curta.` | `Password too short.` |
| `CPF inválido.` | `Invalid CPF.` |
| `Telefone inválido.` | `Invalid phone number.` |
| `CEP inválido.` | `Invalid ZIP code.` |

### Business Messages

| Portuguese (pt-BR) | English (en-US) |
|--------------------|-----------------|
| `Usuário não encontrado.` | `User not found.` |
| `Produto não encontrado.` | `Product not found.` |
| `Estoque insuficiente.` | `Insufficient stock.` |
| `Tico Coins (TC) insuficientes.` | `Insufficient Tico Coins (TC).` |
| `Compra realizada com sucesso.` | `Purchase completed successfully.` |
| `Assinatura cancelada.` | `Subscription canceled.` |

---

## Accept-Language Header Structure

FastAPI with `fastapi_babel` detects the language from the HTTP header:

```python
headers = {"Accept-Language": "pt-BR"}  # Portuguese
headers = {"Accept-Language": "en-US"}  # English
```

```python
from httpx import AsyncClient

# Default client (pt-BR)
async with AsyncClient(app=app, base_url="http://test") as client:
    response = await client.get("/endpoint")

# Client with specific language
async with AsyncClient(app=app, base_url="http://test") as client:
    response = await client.get(
        "/endpoint",
        headers={"Accept-Language": "en-US"}
    )
```

---

## Method That Pulls Language From Authenticated User

For some endpoints where we don't control the header, we can pull the language from the authenticated user:

Any endpoint that uses the `change_language` method defined in `api/utils.py` will pick the user's language.

---

## i18n Test Checklist

For each translatable message in an endpoint:

- [ ] I identified the message in the code (`_("...")`)
- [ ] I found the translation in `messages.po`
- [ ] I created a parametrized test with pt-BR and en-US
- [ ] I tested the scenario where the message appears
- [ ] I validated exactness of the message (not just substring)
- [ ] I tested variable interpolation (if applicable)
- [ ] I documented the scenario in the test docstring

---

## Useful Translation Commands

* [Extract New Messages](./commands/extract-new-messages.md)
* [Update Translations](./commands/update-translations.md)
* [Compile Translations](./commands/compile-translations.md)

---

## Troubleshooting

* [Translation Not Working](./troubleshooting/translation-not-working.md)
* [Message Appears in English for pt-BR](./troubleshooting/message-appears-in-english-for-ptbr.md)
* [i18n Test Fails for en-US](./troubleshooting/i18n-test-fails-for-enus.md)

---

## Best Practices

### ✅ Do

* Always test both pt-BR AND en-US for each message
* Use parametrized tests to avoid duplication
* Validate the exact message, not just a substring
* Document which message is being tested
* Use descriptive ids in `@pytest.mark.parametrize`

### ❌ Don't

* Don't assume translations are correct without testing
* Don't test only one language
* Don't use `in` to validate messages when `==` is possible
* Don't ignore log messages (test only user-facing messages)
* Don't hardcode messages in tests (use the translation files)

---

## Complete Example

There is a complete example of an i18n test in [example.py](./example.py).
