## 1. Run Tests

```bash
make coverage path=api/store/tests/test_purchase.py
```

### Output:

```
PASSED api/store/tests/test_purchase.py::test_purchase_success
FAILED api/store/tests/test_purchase.py::test_invalid_quantity

Coverage: 67%
```
