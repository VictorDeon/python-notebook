## 3. Add Missing Tests

```python
# Test for line 45
async def test_purchase_zero_quantity():
    # Tests quantity=0 and quantity<0
    pass

# Test for line 67
async def test_purchase_database_error():
    # Mocks DatabaseEngine to raise an exception
    pass
```
