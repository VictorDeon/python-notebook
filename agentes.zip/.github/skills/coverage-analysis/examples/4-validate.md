## 4. Validate

```bash
make coverage path=api/store/tests/test_purchase.py
make report
```

### Output:

```
Coverage: 100%
```
