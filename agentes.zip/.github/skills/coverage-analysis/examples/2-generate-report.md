## 2. Generate Report

```bash
make report
```
