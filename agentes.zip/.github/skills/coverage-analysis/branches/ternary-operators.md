## Ternary Operators

```python
# Original code
result = value if condition else default

# Required tests:
# - test_condition_true (returns value)
# - test_condition_false (returns default)
```
