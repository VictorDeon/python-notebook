## Exceptions (try/except)

```python
# Original code
try:
    result = await external_api()
except Exception as e:
    log_error(e)
    raise HTTPException(500)

# Required tests:
# - test_external_api_success
# - test_external_api_failure
```
