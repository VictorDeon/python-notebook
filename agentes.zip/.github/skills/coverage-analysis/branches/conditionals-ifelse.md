## Conditionals (if/else)

Conditional branches (if/else) are decision points in the code where the execution flow splits into two or more paths based on a Boolean condition. Each path represents a different behavior of the program.

```python
# Original code
if user.is_premium:
    apply_discount()
else:
    full_price()

# Required tests:
# - test_with_premium_user
# - test_with_non_premium_user
```
