## Early Returns

```python
# Original code
def process_items(items):
    if not items:
        return []

    # Processing...
    return processed

# Required tests:
# - test_process_empty_list
# - test_process_with_items
```
