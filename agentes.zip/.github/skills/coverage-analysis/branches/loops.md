## Loops

```python
# Original code
for item in items:
    validate(item)
    process(item)

# Required tests:
# - test_with_empty_list (loop does not run)
# - test_with_single_item (loop runs once)
# - test_with_multiple_items (loop runs N times)
```
