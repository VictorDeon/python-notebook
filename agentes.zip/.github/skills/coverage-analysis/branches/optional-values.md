## Optional Values

```python
# Original code
def create_user(name: str, email: str, phone: Optional[str] = None):
    data = {"name": name, "email": email}
    if phone:
        data["phone"] = phone

    return data

# Required tests:
# - test_create_user_with_phone
# - test_create_user_without_phone
```
