## Phase 1: First Run

```bash
make coverage path=api/store/tests/test_purchase.py
```

### Expected result:

Some tests pass, coverage ~30-50%
