## Systematic Mapping

Before writing tests, list ALL branches:

```markdown
## Endpoint Branches

### Function: create_purchase

1. **if not user**: return 404
   - [ ] Test: test_user_not_found

2. **if product.stock < quantity**: raise exception
   - [ ] Test: test_insufficient_stock

3. **try/except Firestore transaction**:
   - [ ] Test: test_transaction_success
   - [ ] Test: test_transaction_failure

4. **if user.tico_coins >= total**: complete purchase
   - [ ] Test: test_sufficient_coins
   - [ ] Test: test_insufficient_coins

5. **for item in cart**: validate each
   - [ ] Test: test_empty_cart
   - [ ] Test: test_single_item
   - [ ] Test: test_multiple_items
```
