## Negation Testing

For each condition, test:
- Condition true
- Condition false

```python
# Code
if user.subscription and user.subscription.status == "active":
    grant_premium_feature()

# Required tests:
# - test_user_with_active_subscription (both true)
# - test_user_without_subscription (first false)
# - test_user_with_inactive_subscription (second false)
```
