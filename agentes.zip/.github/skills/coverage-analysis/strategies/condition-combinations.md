## Condition Combinations

For multiple conditions, test all combinations:

```python
# Code
if user.is_premium and product.requires_premium:
    allow_purchase()
elif user.is_premium:
    apply_discount()
elif product.requires_premium:
    deny_purchase()
else:
    normal_purchase()

# Required tests (4 combinations):
# - premium=True, requires=True → allow_purchase
# - premium=True, requires=False → apply_discount
# - premium=False, requires=True → deny_purchase
# - premium=False, requires=False → normal_purchase
```
