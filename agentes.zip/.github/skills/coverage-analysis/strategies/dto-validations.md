## DTO Validations

For each field on a DTO, test:

```python
class PurchaseRequest(BaseModel):
    product_id: str  # required
    quantity: int = Field(gt=0)  # greater than 0
    coupon_code: Optional[str] = None  # optional

# Required tests:
# - test_valid_request (all valid)
# - test_missing_product_id (required missing)
# - test_invalid_quantity_type (wrong type)
# - test_quantity_zero (gt=0 validation)
# - test_negative_quantity (gt=0 validation)
# - test_with_coupon (optional present)
# - test_without_coupon (optional absent)
```
