---
name: coverage-analysis
description: This skill describes practical methods for analyzing and validating test coverage to achieve 100% coverage; use it after implementing or modifying tests to identify untested branches, guide the creation of test cases (conditions, exceptions, early returns, loops, optional values, and DTO validations), and validate the results with the make coverage, make html, and make flake8 commands.
---

# Skill: Coverage Analysis

This skill provides methodologies to analyze test coverage and identify untested code.

## When to Use This Skill

- When validating coverage after implementing tests
- When identifying untested branches
- When ensuring 100% coverage before finalizing a change
- When analyzing coverage reports

---

## Coverage Commands

1. [Run Tests with Coverage](./commands/run-tests-with-coverage.md)
2. [Generate Coverage Report](./commands/generate-coverage-report.md)
3. [Validate Formatting](./commands/validate-formatting.md)

---

## Branch Analysis

### Identify Untested Branches

After running `make html`, open the module's HTML report. Red lines indicate code that was not executed.

#### Common Branch Types

1. [Conditionals (if/else)](./branches/conditionals-ifelse.md)
2. [Exceptions (try/except)](./branches/exceptions-tryexcept.md)
3. [Early Returns](./branches/early-returns.md)
4. [Loops](./branches/loops.md)
5. [Ternary Operators](./branches/ternary-operators.md)
6. [Optional Values](./branches/optional-values.md)

---

## Strategies for 100% Coverage

1. [Systematic Mapping](./strategies/systematic-mapping.md)
2. [Negation Testing](./strategies/negation-testing.md)
3. [Condition Combinations](./strategies/condition-combinations.md)
4. [DTO Validations](./strategies/dto-validations.md)

---

## Interpreting the Report

The `make report` command generates a visual text report lines

### Example of a Partial Branch

```python
# Code
if condition:
    return True  # Green (tested)
else:
    return False  # Red (not tested)
```

This indicates you tested only `condition=True` and still need to test `condition=False`.

---

## Validation Checklist

Before considering tests complete:

- [ ] I ran `make coverage path=<file>` and all tests passed
- [ ] I ran `make report` and verify lines to cover
- [ ] All conditional branches have tests
- [ ] All try/except blocks have tests
- [ ] All early returns have tests
- [ ] All loop variations are tested
- [ ] All optional fields are tested (present and absent)
- [ ] All DTO validations have tests
- [ ] I ran `make flake8` with no errors
- [ ] I ran `make coverage` (regression) and all passed

---

## Troubleshooting

1. [Coverage does not reach 100%](./issues/coverage-not-100.md)
2. [Branch impossible to test](./issues/branch-impossible-to-test.md)
3. [Mock not being called](./issues/mock-not-called.md)

---

## Progressive Analysis

* [Phase 1: First Run](./phases/phase-1-first-run.md)
* [Phase 2: Report Analysis](./phases/phase-2-report-analysis.md)
* [Phase 3: Iterative Implementation](./phases/phase-3-iterative-implementation.md)
* [Phase 4: Final Validation](./phases/phase-4-final-validation.md)

---

## Quality Metrics

A good test suite should have:

- **Line coverage**: 100%
- **Branch coverage**: 100%
- **Assertions per test**: Average 3-5
- **Execution time**: < 1 second per test
- **Parameterized tests**: To avoid duplication

---

## Full Analysis Example

1. [Run Tests](./examples/1-run-tests.md)
2. [Generate Report](./examples/2-generate-report.md)
3. [Add Missing Tests](./examples/4-add-missing-tests.md)
4. [Validate](./examples/5-validate.md)

✅ Complete!
