## Issue: Coverage does not reach 100%

### Solution:

1. Run `make report`
2. Identify lines
3. For each line, identify which branch is untested
4. Add a test to cover that branch
5. Run tests again and validate
