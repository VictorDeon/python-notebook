## Issue: Mock not being called

### Diagnosis:

```python
# If assert_called_once() fails, check:
print(mock.method.called)  # Was it called?
print(mock.method.call_count)  # How many times?
print(mock.method.call_args_list)  # With which arguments?
```

### Solution:

Ensure the patch target is the location where the object is used, not where it is defined.

```python
# ❌ Wrong - patch where it is defined
with patch("engines.database.DatabaseEngine"):
    pass

# ✅ Correct - patch where it is used
with patch("api.store.controllers.purchase.DatabaseEngine"):
    pass
```
