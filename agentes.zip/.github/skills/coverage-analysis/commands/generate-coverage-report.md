## Generate Coverage Report

### Generate text coverage report:

```bash
make report
```

**Report location**: `htmlcov/index.html`

