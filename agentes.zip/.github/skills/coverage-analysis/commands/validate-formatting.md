## Validate Formatting

Run linter to ensure code formatting adheres to standards.

```bash
make flake8
```
