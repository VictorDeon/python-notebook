## Run Tests with Coverage

### Run a specific test file

```bash
make coverage path=api/store/tests/test_purchase.py
```

### Run all tests (regression)

```bash
make coverage
```
