---
name: implement
description: This prompt is used to implement FastAPI/Python code files based on provided specifications, ensuring adherence to best practices, project standards, and overall code quality.
argument-hint: Provide the FastAPI/Python code files to implement along with any specific requirements or specifications.
agent: SoftwareEngineer
---

Perform complete and systematic implementation of FastAPI/Python code according to the provided specifications.
