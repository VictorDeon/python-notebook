---
name: create-tests
description: Create tests for the provided FastAPI/Python files.
argument-hint: Provide the FastAPI/Python code files for which tests should be generated.
agent: TestEngineer
---

Create new tests for the provided FastAPI/Python code files.
