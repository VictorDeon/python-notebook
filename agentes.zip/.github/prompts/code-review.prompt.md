---
name: code-review
description: Performs comprehensive FastAPI/Python code review by systematically applying all available skills (fastapi-best-practices, security-review, firestore-optimization, pydantic-validation, testing-review, observability, performance-scalability, and others).
argument-hint: Provide the FastAPI/Python code files to review, and optionally specific focus areas.
agent: QAEngineer
---

You must perform a comprehensive and systematic FastAPI/Python code review.
