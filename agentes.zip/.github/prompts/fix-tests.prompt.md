---
name: fix-tests
description: Diagnostique e corrija testes quebrados de integração FastAPI, restaurando 100% de cobertura
argument-hint: Forneça os testes quebrados ou output de erro para diagnóstico e correção
agent: TestEngineer
---

Fix failing tests for the provided FastAPI/Python code files.
