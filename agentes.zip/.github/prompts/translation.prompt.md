---
name: translate
description: Traduz strings em português para inglês americano natural no arquivo messages.po
argument-hint: "Forneça o conteúdo do arquivo messages.po ou indique o caminho do arquivo."
agent: TicoTranslationAgent
---

Update the project translations.
